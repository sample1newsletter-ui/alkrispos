# SariSariPOS (AlKris POS) 🇵🇭

> **A modern, offline-first Point of Sale (POS), Utang Ledger, and E-Cash Management System built natively for Android using Kotlin & Jetpack Compose.**

SariSariPOS is designed specifically for Philippine sari-sari stores, mini-marts, and hardware shops. It provides an intuitive, high-performance solution for handling fast cash checkouts, credit/utang agreements, inventory tracking, financial analytics, and Bluetooth ESC/POS receipt printing—completely offline without requiring cloud subscriptions or an internet connection.

---

## ✨ Key Features

### 🛒 Point of Sale & Checkout
- **Fast Cart Checkout:** Cash, GCash/E-Wallet, and Utang (Credit) payment options.
- **Customizable Product Grid:** Adjustable 1 to 6 column product layout that remembers preferences for both Portrait and Landscape orientations.
- **Weighed & Unit Sales:** Full support for `pcs`, `grams`, `kg`, and `meters`.
- **Live Digital Clock:** Ticking live clock (`HH:MM:SS`) in landscape mode.

### 📱 Dual Operating Modes
- **Mart Mode:** General retail sales, stock management, and sales reporting.
- **E-Cash Mode:** Specialized module for digital services (GCash Cash-In/Cash-Out, Buy Load, Bills Payment, and Printing fees) with automatic float tracking and service fee calculation.

### 📝 Customer Profile & Utang Ledger
- **One-Time Signature Capture:** Customers sign a legally binding 10-day payment agreement during profile creation.
- **Instant Utang Checkout:** Automatically applies signed agreements on file without re-signing.
- **Receivables & Credit Limits:** Tracks outstanding debts, payment history, and credit limits per customer.
- **Utang Cash Collections:** Automatically logged into cash movements and shift history.

### 📦 Inventory & Stock Management
- **Camera Barcode Scanner:** High-speed barcode scanning powered by Google ML Kit with Tap-to-Scan and Continuous scanning modes.
- **Automatic Image Compression:** Product photos are automatically resized (800px) and compressed (JPEG) upon selection.
- **Expiration & Bulk Restocking:** Expiration date tracking with multi-item batch restock wizard.
- **Excel Spreadsheet Import/Export:** Import and export inventory via `.xlsx` spreadsheets using Storage Access Framework.

### 💵 Cash Drawer & Shift Audit History
- **Drawer Balance Protection:** Enforces withdrawal validation to prevent negative cash balances.
- **Shift Auditing:** Shift opening/closing totals, cash count variance tracking (Short/Over), and historical shift audit logs.
- **Cash Movements:** Detailed log of manual cash additions, expenses, pullouts, and utang collections.

### 📊 Financial Reports & Analytics
- **Summary Metrics:** Real-time Gross Sales, Cost of Goods Sold (COGS), Discounts, and Est. Net Profit.
- **Quick Date Range Presets:** One-tap filtering for *Today*, *Yesterday*, *This Week*, *This Month*, *Last Month*, *Last 30 Days*, *All Time*, or *Custom Date Range*.
- **Top 20 Selling Products:** Centered rank badges (`#1` to `#20`) with revenue breakdown.
- **Multi-Format Export:** Export reports to PDF, Excel Spreadsheet, or save E-Receipt PNG images to the Android Gallery.

### 🖨️ Thermal Printing & Digital E-Receipts
- **58mm Bluetooth ESC/POS Thermal Printing:** One-tap wireless receipt and report printing.
- **Gallery E-Receipts:** Renders high-resolution PNG receipt images saved directly to the device gallery.

### 🔐 Security & Data Protection
- **PIN & Biometric Authentication:** 4-digit PIN protection and Android Biometrics (Fingerprint) sign-in.
- **Auto-Logout:** Configurable inactivity timeout.
- **Offline SQLite Storage:** Secure on-device database storage with automated background backup/restore.

---

## 🛠️ Tech Stack & Architecture

- **Language:** Kotlin 2.2.10
- **UI Framework:** Jetpack Compose (Material 3)
- **Architecture:** MVVM (Model-View-ViewModel) + Coroutines + StateFlow
- **Database:** Local SQLite (`pos_mart.db` and `pos_ecash.db`)
- **Barcode Scanning:** Google ML Kit Barcode Scanning
- **Thermal Printing:** ESC/POS Thermal Printer Library
- **Target SDK:** Android 15 (API Level 35)
- **Minimum SDK:** Android 8.0 (API Level 26)

---

## 🚀 Getting Started

### Prerequisites
- Android Studio Ladybug (2024.2.1) or newer
- JDK 17
- Android SDK 35
- Physical Android device or Emulator (Android 8.0+)

### Setup Instructions
1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/SariSariPOS.git
   ```
2. Open the project in Android Studio.
3. Allow Gradle to sync dependencies.
4. Run the app on your Android device or tablet.
5. **Default Login PIN:** `1234`
