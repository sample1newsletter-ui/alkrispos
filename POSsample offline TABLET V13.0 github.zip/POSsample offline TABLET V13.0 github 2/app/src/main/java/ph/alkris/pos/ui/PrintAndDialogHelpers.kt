package ph.alkris.pos.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ph.alkris.pos.data.CashCapital
import ph.alkris.pos.data.CashWithdrawal
import ph.alkris.pos.data.DebtPayment
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.InventoryItem
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.SalesSummary
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Green
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.ui.components.SkyBlue
import java.time.LocalDate

@Composable
fun OpenShiftModalDialog(
    onDismiss: () -> Unit,
    onConfirmed: (Double) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }
    val hasHadPreviousShift = remember { prefs.getBoolean("shift_has_had_previous", false) }
    val customStartingFloat = remember { prefs.getFloat("shift_starting_float", 2000f) }
    val lastClosingCash = remember { prefs.getFloat("shift_last_closing_cash", -1f) }

    val titleText = if (hasHadPreviousShift) "Reopen Cash Shift" else "Open Cash Shift"
    val confirmBtnText = if (hasHadPreviousShift) "Confirm Reopen Shift" else "Confirm Open Shift"

    var startingInputText by remember {
        mutableStateOf(
            if (lastClosingCash >= 0f) lastClosingCash.toInt().toString()
            else customStartingFloat.toInt().toString()
        )
    }
    val newStartingAmt = startingInputText.toDoubleOrNull() ?: customStartingFloat.toDouble()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(titleText, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Enter starting cash for this shift:", style = MaterialTheme.typography.bodyMedium)

                if (lastClosingCash >= 0f) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    OutlinedButton(
                        onClick = { startingInputText = lastClosingCash.toInt().toString() },
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        shape = ControlShape,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text(
                            text = "Use Last Closing Cash: ${Peso.format(lastClosingCash.toDouble())}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                        )
                    }
                }

                OutlinedTextField(
                    value = startingInputText,
                    onValueChange = { startingInputText = it },
                    label = { Text("Starting Money (₱)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(1000.0, 2000.0, 3000.0, 5000.0).forEach { preset ->
                        OutlinedButton(
                            onClick = { startingInputText = preset.toInt().toString() },
                            modifier = Modifier.weight(1f).height(34.dp),
                            shape = ControlShape,
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                        ) {
                            Text(
                                text = "₱${preset.toInt()}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                Button(
                    onClick = {
                        prefs.edit()
                            .putBoolean("shift_is_open", true)
                            .putBoolean("shift_has_had_previous", true)
                            .putFloat("shift_starting_float", newStartingAmt.toFloat())
                            .apply()
                        val toastText = if (hasHadPreviousShift) "Shift reopened successfully" else "Shift opened successfully"
                        Toast.makeText(context, "$toastText (${Peso.format(newStartingAmt)})", Toast.LENGTH_SHORT).show()
                        onConfirmed(newStartingAmt)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = ControlShape
                ) { Text(confirmBtnText) }
            }
        }
    )
}

@Composable
fun DatabasePinDialog(
    title: String,
    message: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(message)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text("PIN") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    shape = ControlShape
                )
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                TextButton(onClick = { onConfirm(pin) }, enabled = pin.isNotBlank()) { Text("Confirm") }
            }
        }
    )
}

fun printDebtPayment(context: Context, payment: DebtPayment, storeName: String, viewModel: PosViewModel) {
    runCatching {
        ThermalPrinterManager.printDebtPayment(context, payment, storeName)
        viewModel.logActivity("PRINT", "Printed utang payment receipt for ${payment.debtorName} (₱${payment.amount})")
    }
}

fun printReport(context: Context, start: LocalDate, end: LocalDate, summary: SalesSummary, storeName: String, viewModel: PosViewModel) {
    runCatching {
        ThermalPrinterManager.printReport(context, start, end, summary, storeName)
        viewModel.logActivity("PRINT", "Printed sales report for $start to $end")
    }
}

fun printInventory(context: Context, inventory: List<InventoryItem>, storeName: String, title: String, viewModel: PosViewModel) {
    runCatching {
        ThermalPrinterManager.printInventory(context, inventory, storeName, title)
        viewModel.logActivity("PRINT", "Printed inventory report ($title)")
    }
}

fun printSkippedBarcodes(context: Context, barcodes: List<String>, storeName: String, viewModel: PosViewModel) {
    runCatching {
        ThermalPrinterManager.printSkippedBarcodes(context, barcodes, storeName)
        viewModel.logActivity("PRINT", "Printed ${barcodes.size} skipped inventory barcodes")
    }
}

fun printItemizedReport(
    context: Context,
    start: LocalDate,
    end: LocalDate,
    sales: List<Sale>,
    storeName: String,
    title: String = "ITEMIZED SALES",
    viewModel: PosViewModel
) {
    runCatching {
        ThermalPrinterManager.printItemizedReport(context, start, end, sales, storeName, title)
        viewModel.logActivity("PRINT", "Printed itemized sales report for $start to $end")
    }
}

fun printReceivablesReport(context: Context, start: LocalDate, end: LocalDate, debtors: List<Debtor>, storeName: String, viewModel: PosViewModel) {
    runCatching {
        ThermalPrinterManager.printReceivablesReport(context, start, end, debtors, storeName)
        viewModel.logActivity("PRINT", "Printed receivables report for $start to $end")
    }
}

fun printDiscountsReport(context: Context, start: LocalDate, end: LocalDate, sales: List<Sale>, storeName: String, viewModel: PosViewModel) {
    runCatching {
        ThermalPrinterManager.printDiscountsReport(context, start, end, sales, storeName)
        viewModel.logActivity("PRINT", "Printed discounts report for $start to $end")
    }
}

fun printCashHistory(
    context: Context,
    start: LocalDate,
    end: LocalDate,
    withdrawals: List<CashWithdrawal>,
    capitals: List<CashCapital>,
    sales: List<Sale>,
    debtPayments: List<DebtPayment>,
    startingCash: Double,
    endingCash: Double,
    storeName: String,
    viewModel: PosViewModel
) {
    runCatching {
        ThermalPrinterManager.printCashHistory(context, start, end, withdrawals, capitals, sales, debtPayments, startingCash, endingCash, storeName)
        viewModel.logActivity("PRINT", "Printed cash history report for $start to $end")
    }
}
