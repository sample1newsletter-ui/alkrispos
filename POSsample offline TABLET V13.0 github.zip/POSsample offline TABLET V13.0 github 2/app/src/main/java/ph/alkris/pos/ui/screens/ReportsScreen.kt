package ph.alkris.pos.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.formattedReceiptCode
import ph.alkris.pos.ui.PdfExporter
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.ReceiptImageExporter
import ph.alkris.pos.ui.ThermalPrinterManager
import ph.alkris.pos.ui.components.*
import ph.alkris.pos.ui.printDiscountsReport
import ph.alkris.pos.ui.printItemizedReport
import ph.alkris.pos.ui.printReport
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private data class TopProduct(
    val name: String,
    val barcode: String,
    val quantitySold: Int,
    val revenue: Double,
    val unit: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier,
    onDebtorClick: ((Debtor) -> Unit)? = null
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var start by remember { mutableStateOf(LocalDate.now()) }
    var end by remember { mutableStateOf(LocalDate.now()) }
    var showCustomDateRangeDialog by remember { mutableStateOf(false) }
    var selectedReceiptForDetail by remember { mutableStateOf<Sale?>(null) }
    var receiptQuery by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                PdfExporter.exportSalesReport(stream, state.storeName, start, end, state.currentReportSales)
                Toast.makeText(context, "Sales PDF exported", Toast.LENGTH_SHORT).show()
            }
            viewModel.logActivity("PRINT", "Saved/Exported Sales Report PDF for $start to $end")
        }
    }

    val exportHistoryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                PdfExporter.exportSalesHistory(stream, state.storeName, start, end, state.currentReportSales)
                Toast.makeText(context, "Sales History PDF exported", Toast.LENGTH_SHORT).show()
            }
            viewModel.logActivity("PRINT", "Saved/Exported Sales History PDF report for $start to $end")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            printReport(context, start, end, state.summary, state.storeName, viewModel)
        }
    }

    val discountsExportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                PdfExporter.exportDiscountsReport(stream, state.storeName, start, end, state.currentReportSales)
                Toast.makeText(context, "Discounts PDF exported", Toast.LENGTH_SHORT).show()
            }
            viewModel.logActivity("PRINT", "Saved/Exported Discounts PDF report for $start to $end")
        }
    }
    val discountsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            printDiscountsReport(context, start, end, state.currentReportSales, state.storeName, viewModel)
        }
    }

    LaunchedEffect(Unit) { viewModel.loadSummary(LocalDate.now(), LocalDate.now()) }

    var pdfMenuExpanded by remember { mutableStateOf(false) }
    var printMenuExpanded by remember { mutableStateOf(false) }
    var presetMenuExpanded by remember { mutableStateOf(false) }

    val dateRangeText = remember(start, end) {
        val dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy")
        if (start == end) {
            if (start == LocalDate.now()) "Today (${start.format(dtf)})"
            else if (start == LocalDate.now().minusDays(1)) "Yesterday (${start.format(dtf)})"
            else start.format(dtf)
        } else {
            "${start.format(dtf)} – ${end.format(dtf)}"
        }
    }

    // FINANCIAL CALCULATIONS FROM CURRENT REPORT SALES
    val reportSales = state.currentReportSales
    val grossSales = remember(reportSales) {
        reportSales.sumOf { it.total + it.discount }
    }
    val totalDiscounts = remember(reportSales) {
        reportSales.sumOf { it.discount }
    }
    val cogs = remember(reportSales) {
        reportSales.flatMap { it.lines }.sumOf { it.unitCost * it.quantity }
    }
    val estNetProfit = remember(reportSales) {
        reportSales.sumOf { it.profit }
    }

    val topSellingProducts = remember(reportSales) {
        reportSales.flatMap { sale ->
            sale.lines.map { line ->
                Triple(line.barcode.ifBlank { line.itemName }, line, line.itemName)
            }
        }
        .groupBy { it.first }
        .map { (_, group) ->
            val sampleLine = group.first().second
            val name = group.first().third
            val totalQty = group.sumOf { it.second.quantity }
            val totalRev = group.sumOf { it.second.subtotal }
            TopProduct(
                name = name,
                barcode = sampleLine.barcode,
                quantitySold = totalQty,
                revenue = totalRev,
                unit = if (sampleLine.itemName.contains("(kg)", ignoreCase = true) || sampleLine.barcode.startsWith("KG_")) "kg" else "pcs"
            )
        }
        .sortedByDescending { it.quantitySold }
        .take(20)
    }

    val filteredReceiptsHistory = remember(reportSales, receiptQuery) {
        val q = receiptQuery.trim()
        val sorted = reportSales.sortedByDescending { it.purchasedAt }
        if (q.isEmpty()) sorted
        else sorted.filter { sale ->
            val code = sale.formattedReceiptCode(state.storeName)
            code.contains(q, ignoreCase = true) ||
            sale.customerName.contains(q, ignoreCase = true) ||
            sale.lines.any { it.itemName.contains(q, ignoreCase = true) }
        }
    }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    var showTopSellingList by remember { mutableStateOf(true) }
    var showReceiptsList by remember { mutableStateOf(true) }

    val financialSummaryHeader = @Composable {
        Text("Financial Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }

    val financialCardsContent = @Composable {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FinancialStatCard(
                    title = "Gross Sales",
                    value = Peso.format(grossSales),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                FinancialStatCard(
                    title = "Cost of Goods (COGS)",
                    value = Peso.format(cogs),
                    color = Pink,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FinancialStatCard(
                    title = "Discounts Given",
                    value = Peso.format(totalDiscounts),
                    color = Pink,
                    modifier = Modifier.weight(1f)
                )
                FinancialStatCard(
                    title = "Est. Net Profit",
                    value = Peso.format(estNetProfit),
                    color = Green,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    val topSellingProductsHeader = @Composable {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { if (!isLandscape) showTopSellingList = !showTopSellingList },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Top Selling Products", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${topSellingProducts.size} items", fontSize = 12.sp, color = Color.Gray)
            }

            if (!isLandscape) {
                IconButton(
                    onClick = { showTopSellingList = !showTopSellingList },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (showTopSellingList) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Toggle Top Selling Products List"
                    )
                }
            }
        }
    }

    val topSellingProductsListOnly = @Composable {
        if (topSellingProducts.isEmpty()) {
            Text("No products sold in selected period.", color = Color.Gray, fontSize = 12.sp)
        } else {
            topSellingProducts.forEachIndexed { index, topProd ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f).padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (index < 3) Blue else Color.LightGray.copy(alpha = 0.5f),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Text(
                                    text = "#${index + 1}",
                                    fontSize = 10.sp,
                                    lineHeight = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    color = if (index < 3) Color.White else Color.Black
                                )
                            }
                        }
                        Text(
                            text = topProd.name,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                        Text(
                            text = "${topProd.quantitySold} ${topProd.unit}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isDark) Color.White else MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = Peso.format(topProd.revenue),
                            fontSize = 10.sp,
                            color = Green,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                if (index < topSellingProducts.size - 1) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), color = Color.LightGray.copy(alpha = 0.4f))
                }
            }
        }
    }

    val receiptsHeaderAndSearch = @Composable {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f, fill = false)) {
                Text("Receipts History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${filteredReceiptsHistory.size} receipts", fontSize = 11.sp, color = Color.Gray)
            }

            Spacer(Modifier.width(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .widthIn(max = 160.dp)
                        .height(36.dp),
                    shape = ControlShape,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (receiptQuery.isEmpty()) {
                                Text(
                                    text = "Search receipt...",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                            BasicTextField(
                                value = receiptQuery,
                                onValueChange = { receiptQuery = it },
                                singleLine = true,
                                textStyle = TextStyle(
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Medium
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        if (receiptQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { receiptQuery = "" },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear search",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }

                if (!isLandscape) {
                    IconButton(
                        onClick = { showReceiptsList = !showReceiptsList },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (showReceiptsList) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Toggle Receipts History List"
                        )
                    }
                }
            }
        }
    }

    val receiptsListOnlyContent = @Composable {
        if (filteredReceiptsHistory.isEmpty()) {
            Text("No receipts found.", color = Color.Gray, fontSize = 12.sp)
        } else {
            filteredReceiptsHistory.forEach { sale ->
                val code = sale.formattedReceiptCode(state.storeName)
                val totalQty = sale.lines.sumOf { it.quantity }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { selectedReceiptForDetail = sale },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.5.dp, Color.LightGray),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(code, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = when (sale.paymentType) {
                                        "CREDIT" -> Pink.copy(alpha = 0.2f)
                                        "ECASH" -> Blue.copy(alpha = 0.2f)
                                        else -> Green.copy(alpha = 0.2f)
                                    }
                                ) {
                                    Text(
                                        text = if (sale.paymentType == "CREDIT") "UTANG" else sale.paymentType,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (sale.paymentType) {
                                            "CREDIT" -> Pink
                                            "ECASH" -> Blue
                                            else -> Green
                                        },
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(Modifier.height(2.dp))

                            Text(
                                text = "${sale.purchasedAt.format(DateTimeFormatter.ofPattern("MM/dd/yyyy, hh:mm a"))} • $totalQty items",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }

                        Text(
                            text = Peso.format(sale.total),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Green
                        )
                    }
                }
            }
        }
    }

    Column(modifier = modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        // FIXED TOP ACTION & DATE FILTER BAR
        Row(
            Modifier.fillMaxWidth().padding(top = 0.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Top) {
                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                Box {
                    InventoryAction(Icons.Default.PictureAsPdf, "Save PDF", if (isDark) Color.White else Blue) {
                        pdfMenuExpanded = true
                    }
                    DropdownMenu(
                        expanded = pdfMenuExpanded,
                        onDismissRequest = { pdfMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Sales Report PDF") },
                            onClick = {
                                pdfMenuExpanded = false
                                exportLauncher.launch("Sales_Report_${start}_to_${end}.pdf")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Sales History PDF") },
                            onClick = {
                                pdfMenuExpanded = false
                                exportHistoryLauncher.launch("Sales_History_${start}_to_${end}.pdf")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Discounts Report PDF") },
                            onClick = {
                                pdfMenuExpanded = false
                                discountsExportLauncher.launch("Discounts_Report_${start}_to_${end}.pdf")
                            }
                        )
                    }
                }
                Box {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    InventoryAction(Icons.Default.Print, "Print", if (isDark) Color.White else Color.Unspecified) {
                        printMenuExpanded = true
                    }
                    DropdownMenu(
                        expanded = printMenuExpanded,
                        onDismissRequest = { printMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Sales Report") },
                            onClick = {
                                printMenuExpanded = false
                                val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
                                } else {
                                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                                }
                                val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                                if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
                                else printReport(context, start, end, state.summary, state.storeName, viewModel)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Sales Itemized Report") },
                            onClick = {
                                printMenuExpanded = false
                                val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
                                } else {
                                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                                }
                                val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                                if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
                                else printItemizedReport(context, start, end, state.currentReportSales, state.storeName, viewModel = viewModel)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Discounts Report") },
                            onClick = {
                                printMenuExpanded = false
                                val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
                                } else {
                                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                                }
                                val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                                if (missing.isNotEmpty()) discountsPermissionLauncher.launch(missing.toTypedArray())
                                else printDiscountsReport(context, start, end, state.currentReportSales, state.storeName, viewModel)
                            }
                        )
                    }
                }

                Box {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    InventoryAction(Icons.Default.DateRange, "Date Range", if (isDark) Color.White else Color.Unspecified) {
                        presetMenuExpanded = true
                    }
                    DropdownMenu(
                        expanded = presetMenuExpanded,
                        onDismissRequest = { presetMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Today", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now()
                                end = start
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Yesterday", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().minusDays(1)
                                end = start
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("This Week", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().minusDays((LocalDate.now().dayOfWeek.value - 1).toLong())
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("This Month", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().withDayOfMonth(1)
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Last Month", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                val currentMonth = LocalDate.now().withDayOfMonth(1)
                                end = currentMonth.minusDays(1)
                                start = end.withDayOfMonth(1)
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Last 30 Days", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().minusDays(30)
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("All Time", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.of(2000, 1, 1)
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Custom Date Range...", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
                            onClick = {
                                presetMenuExpanded = false
                                showCustomDateRangeDialog = true
                            }
                        )
                    }
                }
            }

            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            val dateTextColor = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface

            OutlinedButton(
                onClick = { showCustomDateRangeDialog = true },
                modifier = Modifier.weight(1f).height(40.dp),
                shape = ControlShape,
                contentPadding = PaddingValues(horizontal = 10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date Range", tint = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Text(
                        text = dateRangeText,
                        color = dateTextColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        // SCROLLABLE REPORT BODY
        if (isLandscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.Top
            ) {
                // COLUMN 1 (LEFT): FIXED FINANCIAL SUMMARY + COMPRESSED STAT CARDS + TOP SELLING HEADER, SCROLLABLE PRODUCT LIST
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    financialSummaryHeader()
                    financialCardsContent()

                    Card(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        shape = ControlShape
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            topSellingProductsHeader()
                            Spacer(Modifier.height(8.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                topSellingProductsListOnly()
                            }
                        }
                    }
                }

                // COLUMN 2 (RIGHT): FIXED "Receipts History" HEADER & SEARCH BAR, SCROLLABLE RECEIPTS LIST
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        shape = ControlShape
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            receiptsHeaderAndSearch()
                            Spacer(Modifier.height(8.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                receiptsListOnlyContent()
                            }
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                financialSummaryHeader()
                financialCardsContent()
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = ControlShape
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        receiptsHeaderAndSearch()
                        if (showReceiptsList) {
                            Spacer(Modifier.height(8.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 280.dp)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                receiptsListOnlyContent()
                            }
                        }
                    }
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = ControlShape
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        topSellingProductsHeader()
                        if (showTopSellingList) {
                            Spacer(Modifier.height(8.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 240.dp)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                topSellingProductsListOnly()
                            }
                        }
                    }
                }
            }
        }

        if (showCustomDateRangeDialog) {
            CustomDateRangeDialog(
                initialStart = start,
                initialEnd = end,
                onConfirm = { newStart, newEnd ->
                    start = newStart
                    end = newEnd
                    viewModel.loadSummary(start, end)
                },
                onDismiss = { showCustomDateRangeDialog = false }
            )
        }

        if (selectedReceiptForDetail != null) {
            val sale = selectedReceiptForDetail!!
            AlertDialog(
                onDismissRequest = { selectedReceiptForDetail = null },
                title = {
                    Text(
                        text = "Receipt Details",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Receipt #: ${sale.formattedReceiptCode(state.storeName)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Date: ${sale.purchasedAt.format(DateTimeFormatter.ofPattern("MM/dd/yyyy, hh:mm a"))}", fontSize = 12.sp, color = Color.Gray)
                        Text("Payment Type: ${if (sale.paymentType == "CREDIT") "UTANG" else sale.paymentType}", fontSize = 12.sp, color = Color.Gray)

                        if (sale.customerName.isNotBlank()) {
                            Text("Customer: ${sale.customerName}", fontSize = 12.sp, color = Color.Gray)
                        }

                        HorizontalDivider()

                        sale.lines.forEach { line ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(line.itemName, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                Text("${line.quantity} x ${Peso.format(line.unitPrice)}", fontSize = 12.sp)
                                Spacer(Modifier.width(8.dp))
                                Text(Peso.format(line.subtotal), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        HorizontalDivider()

                        if (sale.discount > 0.0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Discount:", fontSize = 12.sp, color = Pink)
                                Text("-${Peso.format(sale.discount)}", fontSize = 12.sp, color = Pink, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Amount:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(Peso.format(sale.total), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Green)
                        }
                    }
                },
                confirmButton = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                        TextButton(onClick = { selectedReceiptForDetail = null }) {
                            Text("Close", color = if (isDark) Color.White else MaterialTheme.colorScheme.primary)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(
                                onClick = {
                                    ThermalPrinterManager.print(context, sale, state.storeName)
                                }
                            ) {
                                Icon(Icons.Default.Print, contentDescription = "Print Thermal", tint = if (isDark) Color.White else Blue)
                            }
                            IconButton(
                                onClick = {
                                    ReceiptImageExporter.saveReceiptToGallery(context, sale, state.storeName)
                                }
                            ) {
                                Icon(Icons.Default.Download, contentDescription = "Save E-Receipt", tint = Green)
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun FinancialStatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        shape = ControlShape
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(title, fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(1.dp))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}