package ph.alkris.pos.ui.screens

import ph.alkris.pos.ui.components.ProductImageThumbnail
import android.content.Context
import android.net.Uri
import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ph.alkris.pos.data.InventoryItem
import ph.alkris.pos.ui.DatabasePinDialog
import ph.alkris.pos.ui.PdfExporter
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.components.*
import ph.alkris.pos.ui.printInventory
import ph.alkris.pos.ui.printSkippedBarcodes
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun InventoryAction(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    val formattedLabel = label.split(" ").filter { it.isNotBlank() }.joinToString("\n")
    Column(
        modifier = Modifier.widthIn(min = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Surface(
            onClick = onClick,
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = formattedLabel,
            fontSize = 9.sp,
            lineHeight = 10.sp,
            textAlign = TextAlign.Center,
            softWrap = true
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun InventoryScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier,
    onScanRequested: ((String) -> Unit) -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var editingBarcode by rememberSaveable { mutableStateOf<String?>(null) }
    val editing = state.inventory.firstOrNull { it.barcode == editingBarcode }
    var deletingBarcode by rememberSaveable { mutableStateOf<String?>(null) }
    val deleting = state.inventory.firstOrNull { it.barcode == deletingBarcode }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var showPrintAllPinDialog by rememberSaveable { mutableStateOf(false) }
    var pickingExportDate by rememberSaveable { mutableStateOf(false) }
    var exportDate by remember { mutableStateOf(LocalDate.now()) }
    var inventoryQuery by remember { mutableStateOf("") }
    var downloadMenuExpanded by remember { mutableStateOf(false) }
    var printMenuExpanded by remember { mutableStateOf(false) }
    var categoryMenuExpanded by remember { mutableStateOf(false) }
    var selectedCategory by rememberSaveable { mutableStateOf("All Categories") }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var sortMode by remember { mutableIntStateOf(0) }
    var isSelectionMode by rememberSaveable { mutableStateOf(false) }
    var selectedBarcodes by rememberSaveable { mutableStateOf<Set<String>>(emptySet()) }
    var showBatchDeleteDialog by remember { mutableStateOf(false) }
    var addMenuExpanded by remember { mutableStateOf(false) }
    var showBulkAddDialog by rememberSaveable { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }
    var invColsPortrait by remember { mutableIntStateOf(prefs.getInt("inventory_cols_portrait", 2)) }
    var invColsLandscape by remember { mutableIntStateOf(prefs.getInt("inventory_cols_landscape", 4)) }
    var colMenuExpanded by remember { mutableStateOf(false) }

    val availableCategories = remember(state.inventory) {
        (listOf("All Categories") + state.inventory.map { it.effectiveCategory }.distinct().sorted()).distinct()
    }
    val inventoryExportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        uri?.let { context.contentResolver.openOutputStream(it)?.let(viewModel::exportInventorySpreadsheet) }
    }
    val inventoryImportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { context.contentResolver.openInputStream(it)?.let(viewModel::importInventorySpreadsheet) }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                PdfExporter.exportInventory(stream, state.storeName, exportDate, state.inventory)
                Toast.makeText(context, "Inventory PDF exported", Toast.LENGTH_SHORT).show()
            }
            viewModel.logActivity("PRINT", "Saved/Exported inventory PDF report")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            // Re-trigger print if needed
        }
    }

    fun checkAndPrint(items: List<InventoryItem>, title: String) {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
        else printInventory(context, items, state.storeName, title, viewModel)
    }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val searchBarContent = @Composable { modifier: Modifier ->
        Surface(
            modifier = modifier.height(38.dp),
            shape = ControlShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (inventoryQuery.isEmpty()) {
                        Text(
                            text = "Search Inventory",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                    BasicTextField(
                        value = inventoryQuery,
                        onValueChange = { inventoryQuery = it },
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (inventoryQuery.isNotEmpty()) {
                    IconButton(
                        onClick = { inventoryQuery = "" },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear search",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }

    val scanButtonContent = @Composable {
        Surface(
            onClick = { onScanRequested { inventoryQuery = it } },
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.size(38.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                val scanTint = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) SkyBlue else Blue
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = "Scan barcode",
                    tint = scanTint,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }

    val addButtonContent = @Composable {
        Box {
            Button(
                onClick = { addMenuExpanded = true },
                shape = ControlShape,
                modifier = Modifier.height(38.dp)
            ) {
                Icon(Icons.Default.Add, null)
                Text(" Add", fontWeight = FontWeight.Bold)
            }
            DropdownMenu(
                expanded = addMenuExpanded,
                onDismissRequest = { addMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Item", fontWeight = FontWeight.SemiBold) },
                    onClick = {
                        addMenuExpanded = false
                        showAdd = true
                    },
                    leadingIcon = { Icon(Icons.Default.Add, contentDescription = "Individual Item", tint = Blue) }
                )
                DropdownMenuItem(
                    text = { Text("Bulk", fontWeight = FontWeight.SemiBold) },
                    onClick = {
                        addMenuExpanded = false
                        showBulkAddDialog = true
                    },
                    leadingIcon = { Icon(Icons.Default.PostAdd, contentDescription = "Bulk Inventory", tint = Green) }
                )
            }
        }
    }

    val columnControlButtonContent = @Composable {
        Box {
            Surface(
                onClick = { colMenuExpanded = true },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    val colIconTint = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) SkyBlue else MaterialTheme.colorScheme.primary
                    Icon(
                        Icons.Default.ViewColumn,
                        contentDescription = "Grid Columns",
                        tint = colIconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = colMenuExpanded,
                onDismissRequest = { colMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Grid Columns (${if (isLandscape) invColsLandscape else invColsPortrait})", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    onClick = {}
                )
                HorizontalDivider()
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val curCols = if (isLandscape) invColsLandscape else invColsPortrait
                    OutlinedButton(
                        onClick = {
                            val newCols = (curCols - 1).coerceAtLeast(1)
                            if (isLandscape) {
                                invColsLandscape = newCols
                                prefs.edit().putInt("inventory_cols_landscape", newCols).apply()
                            } else {
                                invColsPortrait = newCols
                                prefs.edit().putInt("inventory_cols_portrait", newCols).apply()
                            }
                        },
                        enabled = curCols > 1,
                        modifier = Modifier.size(36.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("—", fontWeight = FontWeight.Bold)
                    }

                    Text("$curCols", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                    OutlinedButton(
                        onClick = {
                            val newCols = (curCols + 1).coerceAtMost(6)
                            if (isLandscape) {
                                invColsLandscape = newCols
                                prefs.edit().putInt("inventory_cols_landscape", newCols).apply()
                            } else {
                                invColsPortrait = newCols
                                prefs.edit().putInt("inventory_cols_portrait", newCols).apply()
                            }
                        },
                        enabled = curCols < 6,
                        modifier = Modifier.size(36.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+", fontWeight = FontWeight.Bold)
                    }
                }
                HorizontalDivider()
                (1..6).forEach { num ->
                    DropdownMenuItem(
                        text = { Text("$num Column${if (num > 1) "s" else ""}") },
                        onClick = {
                            if (isLandscape) {
                                invColsLandscape = num
                                prefs.edit().putInt("inventory_cols_landscape", num).apply()
                            } else {
                                invColsPortrait = num
                                prefs.edit().putInt("inventory_cols_portrait", num).apply()
                            }
                            colMenuExpanded = false
                        }
                    )
                }
            }
        }
    }

    val downloadAction = @Composable {
        Box {
            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            InventoryAction(Icons.Default.FileDownload, "Download", if (isDark) Color.White else Blue) {
                downloadMenuExpanded = true
            }
            DropdownMenu(
                expanded = downloadMenuExpanded,
                onDismissRequest = { downloadMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Save PDF") },
                    onClick = {
                        downloadMenuExpanded = false
                        pickingExportDate = true
                    },
                    leadingIcon = { Icon(Icons.Default.PictureAsPdf, "Save PDF", tint = if (isDark) SkyBlue else Blue) }
                )
                DropdownMenuItem(
                    text = { Text("Excel Export") },
                    onClick = {
                        downloadMenuExpanded = false
                        inventoryExportLauncher.launch("inventory_${LocalDate.now()}.xlsx")
                    },
                    leadingIcon = { Icon(Icons.Default.FileDownload, "Excel Export", tint = if (isDark) SkyBlue else Blue) }
                )
                DropdownMenuItem(
                    text = { Text("Excel Import") },
                    onClick = {
                        downloadMenuExpanded = false
                        inventoryImportLauncher.launch(
                            arrayOf(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/vnd.ms-excel",
                                "*/*"
                            )
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.FileUpload, "Excel Import", tint = Green) }
                )
            }
        }
    }

    val printAction = @Composable {
        Box {
            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            InventoryAction(Icons.Default.Print, "Print", if (isDark) Color.White else Color.Unspecified) {
                printMenuExpanded = true
            }
            DropdownMenu(
                expanded = printMenuExpanded,
                onDismissRequest = { printMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Print All Items") },
                    onClick = {
                        printMenuExpanded = false
                        showPrintAllPinDialog = true
                    },
                    leadingIcon = { Icon(Icons.Default.Print, "Print All Items") }
                )
                DropdownMenuItem(
                    text = { Text("Needed Restock") },
                    onClick = {
                        printMenuExpanded = false
                        val neededRestock = state.inventory.filter { it.stockQuantity <= it.lowStockLimit && it.recommendedStock > it.stockQuantity }
                        checkAndPrint(neededRestock, "NEEDED RESTOCK REPORT")
                    },
                    leadingIcon = { Icon(Icons.Default.Print, "Needed Restock", tint = Pink) }
                )
                DropdownMenuItem(
                    text = { Text("Expired & Expiring Soon") },
                    onClick = {
                        printMenuExpanded = false
                        val expiringItems = state.inventory.filter { it.isExpired || it.isExpiringSoon }
                            .sortedBy { it.expiryDate }
                        checkAndPrint(expiringItems, "EXPIRED & EXPIRING SOON REPORT")
                    },
                    leadingIcon = { Icon(Icons.Default.EventBusy, "Expired & Expiring Soon", tint = Pink) }
                )
            }
        }
    }

    val categoryAction = @Composable {
        Box {
            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            val categoryTint = when {
                isDark -> SkyBlue
                selectedCategory == "All Categories" -> Color.Unspecified
                else -> Blue
            }
            InventoryAction(
                Icons.Default.Category,
                if (selectedCategory == "All Categories") "All Categories" else selectedCategory,
                categoryTint
            ) {
                categoryMenuExpanded = true
            }
            DropdownMenu(
                expanded = categoryMenuExpanded,
                onDismissRequest = { categoryMenuExpanded = false }
            ) {
                availableCategories.forEach { categoryName ->
                    DropdownMenuItem(
                        text = {
                            val catTextColor = if (isDark) Color.White else (if (categoryName == selectedCategory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                            Text(
                                categoryName,
                                fontWeight = if (categoryName == selectedCategory) FontWeight.Bold else FontWeight.Normal,
                                color = catTextColor
                            )
                        },
                        onClick = {
                            selectedCategory = categoryName
                            categoryMenuExpanded = false
                        },
                        leadingIcon = {
                            val catIconTint = if (isDark) Color.White else (if (categoryName == "All Categories") Blue else MaterialTheme.colorScheme.primary)
                            if (categoryName == "All Categories") {
                                Icon(Icons.Default.Category, contentDescription = null, tint = catIconTint)
                            } else {
                                Icon(Icons.AutoMirrored.Filled.Label, contentDescription = null, tint = catIconTint)
                            }
                        }
                    )
                }
            }
        }
    }

    val sortAction = @Composable {
        Box {
            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            InventoryAction(Icons.AutoMirrored.Filled.Sort, "Sort", if (isDark) SkyBlue else Color.Unspecified) {
                sortMenuExpanded = true
            }
            DropdownMenu(
                expanded = sortMenuExpanded,
                onDismissRequest = { sortMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Name A-Z") },
                    onClick = { sortMode = 0; sortMenuExpanded = false }
                )
                DropdownMenuItem(
                    text = { Text("Expiration Date") },
                    onClick = { sortMode = 3; sortMenuExpanded = false }
                )
                DropdownMenuItem(
                    text = { Text("Lowest Inventory") },
                    onClick = { sortMode = 1; sortMenuExpanded = false }
                )
                DropdownMenuItem(
                    text = { Text("Below Low Stock Limit") },
                    onClick = { sortMode = 2; sortMenuExpanded = false }
                )
            }
        }
    }

    val topInventoryHeaderControls = @Composable {
        if (isLandscape) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Top) {
                    downloadAction()
                    printAction()
                    categoryAction()
                }

                searchBarContent(Modifier.weight(1f))
                scanButtonContent()
                columnControlButtonContent()
                addButtonContent()
                sortAction()
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.Top) {
                        downloadAction()
                        printAction()
                        categoryAction()
                    }
                    sortAction()
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    searchBarContent(Modifier.weight(1f))
                    scanButtonContent()
                    columnControlButtonContent()
                    addButtonContent()
                }
            }
        }
    }

    val categoryFilteredInventory = remember(state.inventory, selectedCategory) {
        if (selectedCategory == "All Categories") {
            state.inventory
        } else {
            state.inventory.filter { it.effectiveCategory == selectedCategory }
        }
    }
    val searchedInventory = categoryFilteredInventory.filter {
        val query = inventoryQuery.trim()
        query.isEmpty() ||
            it.name.contains(query, ignoreCase = true) ||
            it.barcode.contains(query, ignoreCase = true)
    }
    val displayedInventory = when (sortMode) {
        1 -> searchedInventory.sortedWith(compareBy<InventoryItem> { it.stockQuantity }.thenBy { it.name.lowercase() })
        2 -> searchedInventory.filter { it.stockQuantity <= it.lowStockLimit }
            .sortedWith(compareBy<InventoryItem> { it.stockQuantity }.thenBy { it.name.lowercase() })
        3 -> searchedInventory.sortedWith(compareBy<InventoryItem> { it.expiryDate }.thenBy { it.name.lowercase() })
        else -> searchedInventory.sortedBy { it.name.lowercase() }
    }
    val columnsCount = if (isLandscape) invColsLandscape else invColsPortrait
    val topPaddingVal = if (isLandscape) 68.dp else 116.dp

    Box(modifier = modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = if (isLandscape) 4.dp else 8.dp)) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(columnsCount),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = topPaddingVal, bottom = 80.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(displayedInventory.size, key = { index -> displayedInventory[index].barcode }) { index ->
                val item = displayedInventory[index]
                val isSelected = selectedBarcodes.contains(item.barcode)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = {
                                if (isSelectionMode) {
                                    selectedBarcodes = if (isSelected) {
                                        selectedBarcodes - item.barcode
                                    } else {
                                        selectedBarcodes + item.barcode
                                    }
                                }
                            },
                            onLongClick = {
                                isSelectionMode = true
                                selectedBarcodes = selectedBarcodes + item.barcode
                            }
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelectionMode && isSelected) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // TOP SECTION: STOCK BADGE & EXP DATE BELOW IT (LEFT COLUMN) + SELECTION CHECKBOX (RIGHT)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            val unitStr = if (item.isKg) "kg" else if (item.isGrams) "grm" else if (item.isMeters) "m" else item.unit.ifBlank { "pcs" }

                            Column(
                                horizontalAlignment = Alignment.Start,
                                verticalArrangement = Arrangement.spacedBy(0.dp)
                            ) {
                                Text(
                                    text = "${item.displayStock} $unitStr left",
                                    color = if (item.isLowStock || item.isOutOfStock) Pink else Green,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    lineHeight = 11.sp
                                )

                                Text(
                                    text = "EXP ${item.displayExpiryDate}",
                                    fontSize = 10.sp,
                                    lineHeight = 10.sp,
                                    fontWeight = if (item.isExpired || item.isExpiringSoon) FontWeight.Bold else FontWeight.Medium,
                                    color = when {
                                        item.isExpired -> Pink
                                        item.isExpiringSoon -> Color(0xFFFFD600)
                                        else -> Color.Gray
                                    }
                                )
                            }

                            if (isSelectionMode) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .background(
                                            color = if (isSelected) Pink else Color.White,
                                            shape = CircleShape
                                        )
                                        .border(width = 1.5.dp, color = Pink, shape = CircleShape)
                                        .clickable {
                                            selectedBarcodes = if (isSelected) {
                                                selectedBarcodes - item.barcode
                                            } else {
                                                selectedBarcodes + item.barcode
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 1.5 INCH x 1.5 INCH PRODUCT THUMBNAIL PHOTO
                        ProductImageThumbnail(
                            imagePath = item.imagePath,
                            fallbackText = item.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(95.dp)
                        )

                        // PRODUCT NAME
                        Text(
                            item.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 2,
                            lineHeight = 14.sp,
                            textAlign = TextAlign.Center,
                            overflow = TextOverflow.Ellipsis
                        )

                        // PRICE INLINE WITH AND PLACED BEFORE EDIT & DELETE ICONS
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Peso.format(item.sellingPrice),
                                color = Green,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )

                            if (!isSelectionMode) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    IconButton(
                                        onClick = { editingBarcode = item.barcode },
                                        modifier = Modifier.size(26.dp)
                                    ) {
                                        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                        Icon(Icons.Default.Edit, "Edit item", tint = if (isDark) SkyBlue else Blue, modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        onClick = { deletingBarcode = item.barcode },
                                        modifier = Modifier.size(26.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, "Delete item", tint = Pink, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (!isLandscape || isSelectionMode) {
            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = if (isSelectionMode) Arrangement.SpaceBetween else Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isSelectionMode) {
                    IconButton(
                        onClick = {
                            isSelectionMode = false
                            selectedBarcodes = emptySet()
                        }
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Exit selection mode",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(Modifier.weight(1f))

                    Button(
                        onClick = {
                            if (selectedBarcodes.isNotEmpty()) {
                                showBatchDeleteDialog = true
                            }
                        },
                        enabled = selectedBarcodes.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = Pink),
                        shape = ControlShape
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Delete (${selectedBarcodes.size})")
                    }
                }
            }
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            color = MaterialTheme.colorScheme.surface
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp, top = 2.dp)
            ) {
                topInventoryHeaderControls()
            }
        }
    }
    if (showBulkAddDialog) {
        BulkRestockDialog(
            viewModel = viewModel,
            inventory = state.inventory,
            onDismiss = { showBulkAddDialog = false }
        )
    }
    if (showBatchDeleteDialog) {
        val selectedItems = state.inventory.filter { selectedBarcodes.contains(it.barcode) }
        DeleteItemsDialog(
            viewModel = viewModel,
            items = selectedItems,
            onDismiss = {
                showBatchDeleteDialog = false
                isSelectionMode = false
                selectedBarcodes = emptySet()
            }
        )
    }
    if (showPrintAllPinDialog) {
        DatabasePinDialog(
            title = "Print Full Inventory",
            message = "Enter your PIN to print all inventory items.",
            onConfirm = { pin ->
                viewModel.verifyPin(pin) { valid ->
                    if (valid) {
                        showPrintAllPinDialog = false
                        checkAndPrint(state.inventory, "FULL INVENTORY REPORT")
                    } else {
                        viewModel.logActivity("PIN_FAILED", "Incorrect PIN entered when printing full inventory report")
                        viewModel.setMessage("Incorrect PIN")
                    }
                }
            },
            onDismiss = { showPrintAllPinDialog = false }
        )
    }
    if (showAdd) AddItemDialog(viewModel, null, onScanRequested) { showAdd = false }
    editing?.let { item -> AddItemDialog(viewModel, item, onScanRequested) { editingBarcode = null } }
    deleting?.let { item ->
        DeleteItemDialog(viewModel, item) {
            deletingBarcode = null
        }
    }
    if (state.skippedInventoryBarcodes.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = viewModel::clearSkippedInventoryBarcodes,
            title = { Text("Skipped Inventory Barcodes") },
            text = {
                Column {
                    Text("These barcodes already exist or were duplicated in the uploaded file:")
                    ScrollbarLazyColumn(Modifier.height(180.dp)) {
                        items(state.skippedInventoryBarcodes.size, key = { index -> state.skippedInventoryBarcodes[index] }) { index ->
                            val barcode = state.skippedInventoryBarcodes[index]
                            Text(barcode, modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = viewModel::clearSkippedInventoryBarcodes) { Text("Close") }
                    TextButton(onClick = {
                        printSkippedBarcodes(context, state.skippedInventoryBarcodes, state.storeName, viewModel)
                    }) {
                        Icon(Icons.Default.Print, contentDescription = "Print skipped barcodes")
                        Text(" Print")
                    }
                }
            }
        )
    }
    
    if (pickingExportDate) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = exportDate.toEpochDay() * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { pickingExportDate = false },
            confirmButton = {
                TextButton({
                    pickerState.selectedDateMillis?.let { exportDate = LocalDate.ofEpochDay(it / 86_400_000L) }
                    pickingExportDate = false
                    exportLauncher.launch("Inventory_${exportDate}.pdf")
                }) { Text("Export") }
            }
        ) { DatePicker(pickerState, showModeToggle = false) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkRestockDialog(
    viewModel: PosViewModel,
    inventory: List<InventoryItem>,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val quantities = remember { mutableStateMapOf<String, String>() }
    val expDates = remember { mutableStateMapOf<String, String>() }
    var activeItemForDatePicker by remember { mutableStateOf<InventoryItem?>(null) }
    var showConfirmationDialog by remember { mutableStateOf(false) }

    val filteredList = remember(inventory, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) inventory.sortedBy { it.name.lowercase() }
        else inventory.filter {
            it.name.contains(q, ignoreCase = true) || it.barcode.contains(q, ignoreCase = true)
        }.sortedBy { it.name.lowercase() }
    }

    val activeAdjustments = remember(quantities.toMap(), inventory) {
        quantities.mapNotNull { (barcode, qtyStr) ->
            val qtyVal = qtyStr.toDoubleOrNull() ?: 0.0
            if (qtyVal > 0.0) {
                val item = inventory.find { it.barcode == barcode }
                if (item != null) Triple(item, qtyVal, qtyStr) else null
            } else null
        }
    }

    val activeItemCount = activeAdjustments.size

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Bulk Inventory Restock",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (activeItemCount > 0) {
                    Text(
                        text = "$activeItemCount item(s)",
                        color = Green,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Enter purchased quantity to automatically add to current stock:",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search item or barcode...", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = ControlShape,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Blue) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    }
                )

                HorizontalDivider()

                ScrollbarLazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    items(filteredList.size, key = { index -> filteredList[index].barcode }) { index ->
                        val item = filteredList[index]
                        val qtyInput = quantities[item.barcode] ?: ""

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if ((qtyInput.toDoubleOrNull() ?: 0.0) > 0.0)
                                    MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f).padding(end = 4.dp)) {
                                    Text(
                                        text = item.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Current: ${item.displayStock} ${if (item.isKg) "kg" else if (item.isGrams) "grm" else "pcs"}",
                                        fontSize = 11.sp,
                                        color = if (item.isLowStock || item.isOutOfStock) Pink else Color.Gray,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    val currentExpStr = expDates[item.barcode] ?: item.expiryDate.toString()
                                    OutlinedTextField(
                                        value = currentExpStr,
                                        onValueChange = { expDates[item.barcode] = it },
                                        label = { Text("Exp Date", fontSize = 10.sp) },
                                        singleLine = true,
                                        modifier = Modifier.width(110.dp),
                                        shape = ControlShape,
                                        trailingIcon = {
                                            IconButton(
                                                onClick = { activeItemForDatePicker = item },
                                                modifier = Modifier.size(20.dp)
                                            ) {
                                                Icon(Icons.Default.DateRange, contentDescription = "Pick Expiration Date", tint = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                    )

                                    OutlinedTextField(
                                        value = qtyInput,
                                        onValueChange = { input ->
                                            if (input.isBlank() || input.matches(Regex("^\\d*\\.?\\d*$"))) {
                                                quantities[item.barcode] = input
                                            }
                                        },
                                        placeholder = { Text("0", fontSize = 12.sp) },
                                        label = { Text("+ Add (${if (item.isKg) "kg" else if (item.isGrams) "grm" else if (item.isMeters) "m" else "pcs"})", fontSize = 10.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.width(95.dp),
                                        shape = ControlShape
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                Button(
                    onClick = {
                        if (activeItemCount > 0) {
                            showConfirmationDialog = true
                        }
                    },
                    enabled = activeItemCount > 0,
                    shape = ControlShape
                ) {
                    Text("Save Bulk Inventory")
                }
            }
        }
    )

    if (showConfirmationDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmationDialog = false },
            title = {
                Text(
                    text = "Confirm Bulk Restock (${activeItemCount} item${if (activeItemCount > 1) "s" else ""})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Are you sure you want to add stock for the following items?",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    HorizontalDivider()

                    ScrollbarLazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(activeAdjustments.size, key = { index -> activeAdjustments[index].first.barcode }) { index ->
                            val (item, qtyVal, _) = activeAdjustments[index]
                            val unitLabel = if (item.isKg) "kg" else if (item.isGrams) "grm" else "pcs"
                            val addedGramsOrPcs = if (item.isKg) (qtyVal * 1000.0).toInt() else qtyVal.toInt()
                            val newStockQuantity = item.stockQuantity + addedGramsOrPcs
                            val newStockDisplay = if (item.isKg) {
                                val newKg = newStockQuantity / 1000.0
                                if (newKg % 1.0 == 0.0) "${newKg.toInt()} kg" else "$newKg kg"
                            } else {
                                "$newStockQuantity $unitLabel"
                            }
                            val addedQtyDisplay = if (item.isKg) "$qtyVal kg" else if (item.isGrams) "${qtyVal.toInt()} grm" else "${qtyVal.toInt()} pcs"

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = item.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Current: ${item.displayStock} $unitLabel",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                        Text(
                                            text = "+$addedQtyDisplay",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Green
                                        )
                                        Text(
                                            text = "New: $newStockDisplay",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val restockData = activeAdjustments.map { (item, qtyVal, _) ->
                            val expStr = expDates[item.barcode] ?: item.expiryDate.toString()
                            val parsedExp = runCatching { LocalDate.parse(expStr.trim()) }.getOrDefault(item.expiryDate)
                            Triple(item.barcode, qtyVal, parsedExp)
                        }
                        viewModel.addBulkStock(restockData)
                        showConfirmationDialog = false
                        onDismiss()
                    },
                    shape = ControlShape
                ) {
                    Text("Confirm & Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmationDialog = false }) {
                    Text("Back to Edit")
                }
            }
        )
    }

    if (activeItemForDatePicker != null) {
        val targetItem = activeItemForDatePicker!!
        val currentStr = expDates[targetItem.barcode] ?: targetItem.expiryDate.toString()
        val parsedMillis = runCatching { LocalDate.parse(currentStr).toEpochDay() * 86_400_000L }.getOrDefault(LocalDate.now().plusYears(1).toEpochDay() * 86_400_000L)
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = parsedMillis)

        DatePickerDialog(
            onDismissRequest = { activeItemForDatePicker = null },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickerState.selectedDateMillis?.let {
                            expDates[targetItem.barcode] = LocalDate.ofEpochDay(it / 86_400_000L).toString()
                        }
                        activeItemForDatePicker = null
                    }
                ) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { activeItemForDatePicker = null }) { Text("Cancel") }
            }
        ) {
            DatePicker(pickerState, showModeToggle = false)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddItemDialog(
    viewModel: PosViewModel,
    initial: InventoryItem?,
    onScanRequested: ((String) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var barcode by remember { mutableStateOf(initial?.barcode ?: "") }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var unit by remember {
        mutableStateOf(
            when {
                initial?.isKg == true -> "kg"
                initial?.isGrams == true -> "grm"
                else -> "pcs"
            }
        )
    }
    var price by remember { mutableStateOf(initial?.sellingPrice?.toString() ?: "") }
    var cost by remember { mutableStateOf(initial?.purchaseCost?.toString() ?: "") }
    var stock by remember {
        mutableStateOf(
            if (initial?.isKg == true) (initial.stockQuantity / 1000.0).toString().removeSuffix(".0")
            else initial?.stockQuantity?.toString() ?: ""
        )
    }
    var lowLimit by remember {
        mutableStateOf(
            if (initial?.isKg == true) (initial.lowStockLimit / 1000.0).toString().removeSuffix(".0")
            else initial?.lowStockLimit?.toString() ?: "5"
        )
    }
    var recommended by remember {
        mutableStateOf(
            if (initial?.isKg == true) (initial.recommendedStock / 1000.0).toString().removeSuffix(".0")
            else initial?.recommendedStock?.toString() ?: "10"
        )
    }
    var category by remember { mutableStateOf(initial?.effectiveCategory ?: "General") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }
    var addedAt by remember { mutableStateOf(initial?.addedAt?.format(InventoryDateTimeFormat) ?: LocalDateTime.now().format(InventoryDateTimeFormat)) }
    var expiryDateText by remember { mutableStateOf(initial?.expiryDate?.toString() ?: LocalDate.now().plusYears(1).toString()) }
    var showExpiryPicker by remember { mutableStateOf(false) }

    val context = LocalContext.current
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var currentImagePath by remember { mutableStateOf(initial?.imagePath) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            currentImagePath = uri.toString()
        }
    }

    val defaultCategoryList = remember {
        listOf(
            "General",
            "Noodles & Pasta",
            "Canned Goods & Meat",
            "Coffee, Milk & Beverages",
            "Condiments & Seasonings",
            "Snacks, Biscuits & Sweets",
            "Personal Care & Hygiene",
            "Laundry & Household",
            "Cooking Ingredients & Dairy",
            "Frozen & Chilled"
        )
    }

    val allCategories = remember(state.inventory) {
        (defaultCategoryList + state.inventory.map { it.effectiveCategory }.distinct()).distinct()
    }

    val cleanBarcode = barcode.trim().lowercase()
    val isDuplicateBarcode = cleanBarcode.isNotBlank() &&
            state.inventory.any { it.barcode.trim().equals(cleanBarcode, ignoreCase = true) && it.barcode.trim() != initial?.barcode?.trim() }

    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "Add inventory item" else "Edit inventory item") }, text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) { 
            // PRODUCT PHOTO PICKER & UNIFORM THUMBNAIL PREVIEW
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                ProductImageThumbnail(
                    imagePath = currentImagePath,
                    fallbackText = name.ifBlank { "Product" },
                    modifier = Modifier.size(52.dp)
                )

                OutlinedButton(
                    onClick = { photoPickerLauncher.launch("image/*") },
                    shape = ControlShape,
                    modifier = Modifier.weight(1f)
                ) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    val editPhotoTint = if (isDark) Color.White else Blue
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = editPhotoTint)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (currentImagePath.isNullOrBlank()) "Add Product Photo" else "Replace Product Photo",
                        fontSize = 12.sp,
                        color = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = barcode,
                    onValueChange = { barcode = it },
                    label = { Text("Barcode") },
                    isError = isDuplicateBarcode,
                    supportingText = if (isDuplicateBarcode) {
                        { Text("Code exists", color = Pink, fontWeight = FontWeight.Bold) }
                    } else null,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = ControlShape
                )
                IconButton({ onScanRequested { barcode = it } }) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    Icon(Icons.Default.QrCodeScanner, "Scan", tint = if (isDark) Color.White else Blue)
                }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Item name") }, singleLine = true, shape = ControlShape)
            Spacer(Modifier.height(4.dp))
            Box(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { categoryDropdownExpanded = !categoryDropdownExpanded }) {
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Select Category")
                        }
                    }
                )
                DropdownMenu(
                    expanded = categoryDropdownExpanded,
                    onDismissRequest = { categoryDropdownExpanded = false }
                ) {
                    allCategories.forEach { catOption ->
                        DropdownMenuItem(
                            text = { Text(catOption) },
                            onClick = {
                                category = catOption
                                categoryDropdownExpanded = false
                            },
                            leadingIcon = {
                                Icon(Icons.AutoMirrored.Filled.Label, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text("Unit Qty:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                FilterChip(
                    selected = unit == "pcs",
                    onClick = { unit = "pcs" },
                    label = { Text("pcs") }
                )
                FilterChip(
                    selected = unit == "grm",
                    onClick = { unit = "grm" },
                    label = { Text("grm") }
                )
                FilterChip(
                    selected = unit == "kg",
                    onClick = { unit = "kg" },
                    label = { Text("kg") }
                )
                FilterChip(
                    selected = unit == "m",
                    onClick = { unit = "m" },
                    label = { Text("m") }
                )
            }
            OutlinedTextField(
                cost,
                { cost = it },
                label = { Text(when (unit) { "kg" -> "Purchase cost (per kg)"; "grm" -> "Purchase cost (per 1000g)"; "m" -> "Purchase cost (per meter)"; else -> "Purchase cost" }) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = ControlShape
            )
            OutlinedTextField(
                price,
                { price = it },
                label = { Text(when (unit) { "kg" -> "Selling price (per kg)"; "grm" -> "Selling price (per 1000g)"; "m" -> "Selling price (per meter)"; else -> "Selling price" }) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = ControlShape
            )
            OutlinedTextField(
                stock,
                { stock = it },
                label = { Text(when (unit) { "kg" -> "Stock quantity (in kg)"; "grm" -> "Stock quantity (in grams)"; "m" -> "Stock quantity (in meters)"; else -> "Stock quantity" }) },
                keyboardOptions = KeyboardOptions(keyboardType = if (unit == "pcs" || unit == "m") KeyboardType.Number else KeyboardType.Decimal),
                singleLine = true,
                shape = ControlShape
            )
            OutlinedTextField(
                lowLimit,
                { lowLimit = it },
                label = { Text(when (unit) { "kg" -> "Low stock limit (in kg)"; "grm" -> "Low stock limit (in grams)"; "m" -> "Low stock limit (in meters)"; else -> "Low stock limit" }) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = ControlShape
            )
            OutlinedTextField(
                recommended,
                { recommended = it },
                label = { Text(when (unit) { "kg" -> "Recommended stock (in kg)"; "grm" -> "Recommended stock (in grams)"; "m" -> "Recommended stock (in meters)"; else -> "Recommended stock" }) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = ControlShape
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                OutlinedTextField(
                    value = expiryDateText,
                    onValueChange = { expiryDateText = it },
                    label = { Text("Expiration Date (YYYY-MM-DD) *") },
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { showExpiryPicker = true }) {
                    Icon(Icons.Default.DateRange, contentDescription = "Pick Expiration Date", tint = MaterialTheme.colorScheme.primary)
                }
            }
            OutlinedTextField(addedAt, { addedAt = it }, label = { Text("Date and time added") }, singleLine = true, shape = ControlShape)
        } 
    }, confirmButton = {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onDismiss) {
                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                Text("Cancel", color = if (isDark) Color.White else MaterialTheme.colorScheme.primary)
            }
            TextButton(
                onClick = {
                    val parsedExpiry = runCatching { LocalDate.parse(expiryDateText.trim()) }.getOrNull()
                    if (parsedExpiry == null) {
                        Toast.makeText(context, "Please enter or pick a valid Expiration Date (YYYY-MM-DD)", Toast.LENGTH_SHORT).show()
                        return@TextButton
                    }

                    val rawStock = stock.toDoubleOrNull() ?: 0.0
                    val rawLowLimit = lowLimit.toDoubleOrNull() ?: 5.0
                    val rawRecommended = recommended.toDoubleOrNull() ?: 10.0

                    val finalStock = if (unit == "kg") (rawStock * 1000.0).toInt() else rawStock.toInt()
                    val finalLowLimit = if (unit == "kg") (rawLowLimit * 1000.0).toInt() else rawLowLimit.toInt()
                    val finalRecommended = if (unit == "kg") (rawRecommended * 1000.0).toInt() else rawRecommended.toInt()

                    val finalBarcode = barcode.trim()
                    viewModel.saveItem(
                        item = InventoryItem(
                            barcode = finalBarcode, 
                            name = name, 
                            purchaseCost = cost.toDoubleOrNull() ?: 0.0, 
                            sellingPrice = price.toDoubleOrNull() ?: 0.0, 
                            stockQuantity = finalStock, 
                            lowStockLimit = finalLowLimit,
                            recommendedStock = finalRecommended,
                            unit = unit,
                            category = category.trim().ifBlank { "General" },
                            imagePath = currentImagePath,
                            expiryDate = parsedExpiry,
                            addedAt = runCatching {
                                if (initial == null) LocalDateTime.parse(addedAt, InventoryDateTimeFormat)
                                else LocalDateTime.now()
                            }
                                .getOrElse { LocalDateTime.now() }
                        ),
                        imageUri = selectedImageUri,
                        context = context
                    )
                    onDismiss()
                },
                enabled = barcode.isNotBlank() && name.isNotBlank() && !isDuplicateBarcode
            ) {
                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                Text("Save", color = if (isDark) Color.White else MaterialTheme.colorScheme.primary)
            }
        }
    })

    if (showExpiryPicker) {
        val parsedInitialMillis = runCatching {
            LocalDate.parse(expiryDateText).toEpochDay() * 86_400_000L
        }.getOrDefault(LocalDate.now().plusYears(1).toEpochDay() * 86_400_000L)

        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = parsedInitialMillis)
        DatePickerDialog(
            onDismissRequest = { showExpiryPicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            expiryDateText = LocalDate.ofEpochDay(it / 86_400_000L).toString()
                        }
                        showExpiryPicker = false
                    }
                ) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showExpiryPicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(datePickerState, showModeToggle = false)
        }
    }
}

@Composable
fun DeleteItemDialog(viewModel: PosViewModel, item: InventoryItem, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete inventory item?") },
        text = {
            Column {
                Text("This will permanently remove ${item.name} from the inventory sheet.")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(pin, { pin = it }, label = { Text("PIN confirmation") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = ControlShape)
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                TextButton(onClick = { viewModel.deleteItem(item, pin); onDismiss() }, enabled = pin.isNotBlank()) {
                    Text("Delete", color = Pink)
                }
            }
        }
    )
}

@Composable
fun DeleteItemsDialog(
    viewModel: PosViewModel,
    items: List<InventoryItem>,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete selected items?") },
        text = {
            Column {
                Text("This will permanently remove ${items.size} selected inventory item(s).")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    pin,
                    { pin = it },
                    label = { Text("PIN confirmation") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    shape = ControlShape
                )
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                TextButton(
                    onClick = { viewModel.deleteItems(items, pin); onDismiss() },
                    enabled = pin.isNotBlank() && items.isNotEmpty()
                ) {
                    Text("Delete", color = Pink)
                }
            }
        }
    )
}