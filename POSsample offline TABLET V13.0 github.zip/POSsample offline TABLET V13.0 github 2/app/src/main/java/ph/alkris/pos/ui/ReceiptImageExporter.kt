package ph.alkris.pos.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import ph.alkris.pos.data.DebtPayment
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.extractEcashDetails
import ph.alkris.pos.data.formattedReceiptCode
import java.io.File
import java.text.NumberFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object ReceiptImageExporter {

    private val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))

    private sealed class ReceiptLine {
        data class Text(
            val text: String,
            val isBold: Boolean = false,
            val isCenter: Boolean = false,
            val fontSize: Float = 20f
        ) : ReceiptLine()

        data class Row(
            val left: String,
            val right: String,
            val isBold: Boolean = false,
            val fontSize: Float = 20f
        ) : ReceiptLine()

        object Divider : ReceiptLine()

        data class Signature(val bytes: ByteArray) : ReceiptLine() {
            override fun equals(other: Any?): Boolean {
                if (this === other) return true
                if (javaClass != other?.javaClass) return false
                other as Signature
                return bytes.contentEquals(other.bytes)
            }

            override fun hashCode(): Int {
                return bytes.contentHashCode()
            }
        }
    }

    fun generateReceiptBitmap(context: Context, sale: Sale, storeName: String): Bitmap {
        val width = 576 // Standard 58mm thermal width in pixels
        val padding = 28f

        val isEcash = sale.lines.any { it.barcode.startsWith("ECASH_") }

        val linesToDraw = mutableListOf<ReceiptLine>()

        val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
        val storeAddr = prefs.getString("store_location", "Poblacion, Philippines") ?: "Poblacion, Philippines"
        val storeContact = prefs.getString("store_contact", "0912-345-6789") ?: "0912-345-6789"

        // Store Header
        linesToDraw.add(ReceiptLine.Text(storeName.uppercase(), isBold = true, isCenter = true, fontSize = 28f))
        if (storeAddr.isNotBlank()) {
            linesToDraw.add(ReceiptLine.Text(storeAddr, isCenter = true, fontSize = 18f))
        }
        if (storeContact.isNotBlank()) {
            linesToDraw.add(ReceiptLine.Text("Contact: $storeContact", isCenter = true, fontSize = 18f))
        }

        val ecashDetails = sale.extractEcashDetails()

        val headerTitle = if (isEcash && ecashDetails != null) {
            when {
                ecashDetails.isCashOut -> "E-RECEIPT - CASH-OUT"
                ecashDetails.isPrinting -> "E-RECEIPT - PRINTING"
                else -> "E-RECEIPT - ${ecashDetails.serviceType.uppercase()}"
            }
        } else if (sale.paymentType == "CREDIT") {
            "E-RECEIPT (UTANG)"
        } else {
            "E-RECEIPT"
        }
        linesToDraw.add(ReceiptLine.Text(headerTitle, isBold = true, isCenter = true, fontSize = 22f))
        linesToDraw.add(ReceiptLine.Text(sale.purchasedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")), isCenter = false, fontSize = 18f))

        val codename = sale.formattedReceiptCode(storeName)
        linesToDraw.add(ReceiptLine.Text("Receipt #: $codename", isCenter = false, fontSize = 18f))
        linesToDraw.add(ReceiptLine.Divider)

        if (isEcash && ecashDetails != null) {
            val (serviceType, customerName, address, contactNo, refNo, serviceDetails, principal, serviceFee, isPrinting, isCashOut) = ecashDetails

            var hasCustomerSection = false
            if (customerName.isNotBlank() && !customerName.equals("Walkin", ignoreCase = true)) {
                linesToDraw.add(ReceiptLine.Text("Customer: $customerName", isBold = true, fontSize = 18f))
                hasCustomerSection = true
            }
            if (address.isNotBlank()) {
                linesToDraw.add(ReceiptLine.Text("Address: $address", fontSize = 18f))
                hasCustomerSection = true
            }
            if (contactNo.isNotBlank()) {
                linesToDraw.add(ReceiptLine.Text("Contact #: $contactNo", fontSize = 18f))
                hasCustomerSection = true
            }
            if (refNo.isNotBlank() && refNo != sale.id) {
                linesToDraw.add(ReceiptLine.Text("Ref #: $refNo", fontSize = 18f))
                hasCustomerSection = true
            }
            if (serviceDetails.isNotBlank()) {
                linesToDraw.add(ReceiptLine.Text("Details: $serviceDetails", fontSize = 18f))
                hasCustomerSection = true
            }

            if (hasCustomerSection) {
                linesToDraw.add(ReceiptLine.Divider)
            }

            if (isCashOut) {
                val customerCash = sale.cashReceived
                val cashToGiveCustomer = sale.change
                linesToDraw.add(ReceiptLine.Row("Principal Amount", peso.format(principal)))
                linesToDraw.add(ReceiptLine.Row("Service Fee", peso.format(serviceFee)))
                linesToDraw.add(ReceiptLine.Row("Customer Cash (Fee)", peso.format(customerCash)))
                linesToDraw.add(ReceiptLine.Divider)
                linesToDraw.add(ReceiptLine.Row("CASH TO GIVE CUSTOMER", peso.format(cashToGiveCustomer), isBold = true, fontSize = 22f))
            } else if (isPrinting) {
                linesToDraw.add(ReceiptLine.Row("Service Fee / Charge", peso.format(sale.total)))
                linesToDraw.add(ReceiptLine.Divider)
                linesToDraw.add(ReceiptLine.Row("TOTAL AMOUNT", peso.format(sale.total), isBold = true, fontSize = 22f))
                linesToDraw.add(ReceiptLine.Row("Cash Received", peso.format(sale.cashReceived)))
                linesToDraw.add(ReceiptLine.Row("Change", peso.format(sale.change)))
            } else {
                linesToDraw.add(ReceiptLine.Row("Principal Amount", peso.format(principal)))
                linesToDraw.add(ReceiptLine.Row("Service Fee", peso.format(serviceFee)))
                linesToDraw.add(ReceiptLine.Divider)
                linesToDraw.add(ReceiptLine.Row("TOTAL AMOUNT", peso.format(sale.total), isBold = true, fontSize = 22f))
                linesToDraw.add(ReceiptLine.Row("Cash Received", peso.format(sale.cashReceived)))
                linesToDraw.add(ReceiptLine.Row("Change", peso.format(sale.change)))
            }

            if (sale.paymentType == "CREDIT") {
                linesToDraw.add(ReceiptLine.Divider)
                linesToDraw.add(ReceiptLine.Text("UTANG (Credit Transaction)", isBold = true, fontSize = 20f))
                val displayName = customerName.ifBlank { sale.customerName }
                val displayContact = if (contactNo.isNotBlank()) contactNo else refNo
                linesToDraw.add(ReceiptLine.Text("Name: $displayName", fontSize = 18f))
                if (displayContact.isNotBlank()) {
                    linesToDraw.add(ReceiptLine.Text("Contact: $displayContact", fontSize = 18f))
                }
                val partialCash = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                val remainingOwed = (sale.total - partialCash).coerceAtLeast(0.0)
                if (partialCash > 0.0) {
                    linesToDraw.add(ReceiptLine.Row("Partial Cash", peso.format(partialCash)))
                    linesToDraw.add(ReceiptLine.Row("Remaining Owed", peso.format(remainingOwed)))
                }
                linesToDraw.add(ReceiptLine.Text("Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.", fontSize = 16f))
                if (sale.signature != null && sale.signature.isNotEmpty()) {
                    linesToDraw.add(ReceiptLine.Signature(sale.signature))
                }
            }
        } else {
            // Mart mode
            sale.lines.forEach { line ->
                linesToDraw.add(ReceiptLine.Row("${line.itemName} x${line.quantity}", peso.format(line.subtotal)))
            }
            linesToDraw.add(ReceiptLine.Divider)

            if (sale.discount > 0.0) {
                linesToDraw.add(ReceiptLine.Row("Less Discount", "-${peso.format(sale.discount)}"))
            }
            linesToDraw.add(ReceiptLine.Row("TOTAL", peso.format(sale.total), isBold = true, fontSize = 24f))
            linesToDraw.add(ReceiptLine.Divider)

            if (sale.paymentType == "CREDIT") {
                val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                val remainingOwed = (sale.total - downPayment).coerceAtLeast(0.0)
                linesToDraw.add(ReceiptLine.Text("UTANG (Credit Transaction)", isBold = true, fontSize = 20f))
                linesToDraw.add(ReceiptLine.Text("Name: ${sale.customerName}", fontSize = 18f))
                if (sale.customerContact.isNotBlank()) {
                    linesToDraw.add(ReceiptLine.Text("Contact: ${sale.customerContact}", fontSize = 18f))
                }
                if (downPayment > 0.0) {
                    linesToDraw.add(ReceiptLine.Row("Partial Cash", peso.format(downPayment)))
                    linesToDraw.add(ReceiptLine.Row("Remaining Owed", peso.format(remainingOwed)))
                }
                linesToDraw.add(ReceiptLine.Text("Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.", fontSize = 16f))
                if (sale.signature != null && sale.signature.isNotEmpty()) {
                    linesToDraw.add(ReceiptLine.Signature(sale.signature))
                }
            } else if (sale.paymentType.equals("GCASH", ignoreCase = true) || sale.paymentType.equals("EWALLET", ignoreCase = true)) {
                linesToDraw.add(ReceiptLine.Row("Payment Method", "GCash", isBold = true))
                if (sale.customerContact.isNotBlank()) {
                    linesToDraw.add(ReceiptLine.Row("GCash Ref / Trace #", sale.customerContact))
                }
                linesToDraw.add(ReceiptLine.Row("Amount Paid (GCash)", peso.format(sale.total)))
            } else {
                linesToDraw.add(ReceiptLine.Row("Payment Method", "Cash"))
                linesToDraw.add(ReceiptLine.Row("Cash Received", peso.format(sale.cashReceived)))
                linesToDraw.add(ReceiptLine.Row("Change", peso.format(sale.change)))
            }
        }

        // Footer
        linesToDraw.add(ReceiptLine.Divider)
        val customFooter = prefs.getString("receipt_footer", if (isEcash) "Thank you!" else "Thank you for shopping!") ?: "Thank you for shopping!"
        linesToDraw.add(ReceiptLine.Text(customFooter, isCenter = true, fontSize = 20f))
        linesToDraw.add(ReceiptLine.Text("NOT VALID FOR BIR CLAIMING TAX", isBold = true, isCenter = true, fontSize = 15f))
        linesToDraw.add(ReceiptLine.Text("INTERNAL STORE MONITORING PURPOSES ONLY", isCenter = true, fontSize = 14f))
        linesToDraw.add(ReceiptLine.Text(codename, isCenter = true, fontSize = 16f))

        // Calculate height
        var totalHeight = padding * 2
        linesToDraw.forEach { line ->
            totalHeight += when (line) {
                is ReceiptLine.Text -> line.fontSize * 1.5f
                is ReceiptLine.Row -> line.fontSize * 1.5f
                is ReceiptLine.Divider -> 16f
                is ReceiptLine.Signature -> 110f
            }
        }

        val bitmap = Bitmap.createBitmap(width, totalHeight.toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
        }

        var currentY = padding
        linesToDraw.forEach { line ->
            when (line) {
                is ReceiptLine.Text -> {
                    paint.textSize = line.fontSize
                    paint.typeface = if (line.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    currentY += line.fontSize
                    if (line.isCenter) {
                        paint.textAlign = Paint.Align.CENTER
                        canvas.drawText(line.text, width / 2f, currentY, paint)
                    } else {
                        paint.textAlign = Paint.Align.LEFT
                        canvas.drawText(line.text, padding, currentY, paint)
                    }
                    currentY += line.fontSize * 0.4f
                }
                is ReceiptLine.Row -> {
                    paint.textSize = line.fontSize
                    paint.typeface = if (line.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    currentY += line.fontSize

                    val rightWidth = paint.measureText(line.right)
                    val maxLeftWidth = (width - padding * 2) - rightWidth - 16f
                    var leftText = line.left
                    if (paint.measureText(leftText) > maxLeftWidth) {
                        while (leftText.length > 3 && paint.measureText("$leftText...") > maxLeftWidth) {
                            leftText = leftText.dropLast(1)
                        }
                        leftText = "$leftText..."
                    }

                    paint.textAlign = Paint.Align.LEFT
                    canvas.drawText(leftText, padding, currentY, paint)
                    paint.textAlign = Paint.Align.RIGHT
                    canvas.drawText(line.right, width - padding, currentY, paint)
                    currentY += line.fontSize * 0.4f
                }
                is ReceiptLine.Divider -> {
                    currentY += 6f
                    paint.strokeWidth = 2f
                    canvas.drawLine(padding, currentY, width - padding, currentY, paint)
                    currentY += 10f
                }
                is ReceiptLine.Signature -> {
                    runCatching {
                        val sigBmp = BitmapFactory.decodeByteArray(line.bytes, 0, line.bytes.size)
                        if (sigBmp != null) {
                            val targetW = (width - padding * 2).toInt()
                            val targetH = (targetW * sigBmp.height.toDouble() / sigBmp.width.toDouble()).toInt().coerceAtMost(90)
                            val scaledSig = Bitmap.createScaledBitmap(sigBmp, targetW, targetH, true)
                            canvas.drawBitmap(scaledSig, padding, currentY, paint)
                            currentY += targetH + 10f
                        }
                    }
                }
            }
        }

        return bitmap
    }

    fun generateDebtPaymentReceiptBitmap(context: Context, payment: DebtPayment, storeName: String): Bitmap {
        val width = 576
        val padding = 28f
        val linesToDraw = mutableListOf<ReceiptLine>()

        val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
        val storeAddr = prefs.getString("store_location", "Poblacion, Philippines") ?: "Poblacion, Philippines"
        val storeContact = prefs.getString("store_contact", "0912-345-6789") ?: "0912-345-6789"

        linesToDraw.add(ReceiptLine.Text(storeName.uppercase(), isBold = true, isCenter = true, fontSize = 28f))
        if (storeAddr.isNotBlank()) {
            linesToDraw.add(ReceiptLine.Text(storeAddr, isCenter = true, fontSize = 18f))
        }
        if (storeContact.isNotBlank()) {
            linesToDraw.add(ReceiptLine.Text("Contact: $storeContact", isCenter = true, fontSize = 18f))
        }
        linesToDraw.add(ReceiptLine.Text("E-RECEIPT (UTANG PAYMENT)", isBold = true, isCenter = true, fontSize = 22f))
        linesToDraw.add(ReceiptLine.Text(payment.paidAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")), isCenter = false, fontSize = 18f))

        val codename = payment.formattedReceiptCode(storeName)
        linesToDraw.add(ReceiptLine.Text("Receipt #: $codename", isCenter = false, fontSize = 18f))
        linesToDraw.add(ReceiptLine.Divider)

        linesToDraw.add(ReceiptLine.Text("Debtor: ${payment.debtorName}", isBold = true, fontSize = 20f))
        if (payment.contact.isNotBlank()) {
            linesToDraw.add(ReceiptLine.Text("Contact: ${payment.contact}", fontSize = 18f))
        }
        linesToDraw.add(ReceiptLine.Row("Previous Balance", peso.format(payment.previousBalance)))
        linesToDraw.add(ReceiptLine.Row("Cash Payment", peso.format(payment.amount), isBold = true, fontSize = 22f))
        linesToDraw.add(ReceiptLine.Row("Cash Received", peso.format(payment.cashReceived)))
        linesToDraw.add(ReceiptLine.Row("Change", peso.format(payment.change)))
        linesToDraw.add(ReceiptLine.Row("Remaining Balance", peso.format(payment.remainingBalance), isBold = true))

        linesToDraw.add(ReceiptLine.Divider)
        linesToDraw.add(ReceiptLine.Text("Thank you!", isCenter = true, fontSize = 20f))
        linesToDraw.add(ReceiptLine.Text("E-RECEIPT", isBold = true, isCenter = true, fontSize = 18f))
        linesToDraw.add(ReceiptLine.Text(codename, isCenter = true, fontSize = 16f))

        var totalHeight = padding * 2
        linesToDraw.forEach { line ->
            totalHeight += when (line) {
                is ReceiptLine.Text -> line.fontSize * 1.5f
                is ReceiptLine.Row -> line.fontSize * 1.5f
                is ReceiptLine.Divider -> 16f
                is ReceiptLine.Signature -> 110f
            }
        }

        val bitmap = Bitmap.createBitmap(width, totalHeight.toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
        }

        var currentY = padding
        linesToDraw.forEach { line ->
            when (line) {
                is ReceiptLine.Text -> {
                    paint.textSize = line.fontSize
                    paint.typeface = if (line.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    currentY += line.fontSize
                    if (line.isCenter) {
                        paint.textAlign = Paint.Align.CENTER
                        canvas.drawText(line.text, width / 2f, currentY, paint)
                    } else {
                        paint.textAlign = Paint.Align.LEFT
                        canvas.drawText(line.text, padding, currentY, paint)
                    }
                    currentY += line.fontSize * 0.4f
                }
                is ReceiptLine.Row -> {
                    paint.textSize = line.fontSize
                    paint.typeface = if (line.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    currentY += line.fontSize

                    val rightWidth = paint.measureText(line.right)
                    val maxLeftWidth = (width - padding * 2) - rightWidth - 16f
                    var leftText = line.left
                    if (paint.measureText(leftText) > maxLeftWidth) {
                        while (leftText.length > 3 && paint.measureText("$leftText...") > maxLeftWidth) {
                            leftText = leftText.dropLast(1)
                        }
                        leftText = "$leftText..."
                    }

                    paint.textAlign = Paint.Align.LEFT
                    canvas.drawText(leftText, padding, currentY, paint)
                    paint.textAlign = Paint.Align.RIGHT
                    canvas.drawText(line.right, width - padding, currentY, paint)
                    currentY += line.fontSize * 0.4f
                }
                is ReceiptLine.Divider -> {
                    currentY += 6f
                    paint.strokeWidth = 2f
                    canvas.drawLine(padding, currentY, width - padding, currentY, paint)
                    currentY += 10f
                }
                is ReceiptLine.Signature -> {}
            }
        }

        return bitmap
    }

    fun saveReceiptToGallery(context: Context, sale: Sale, storeName: String): Boolean {
        return try {
            val bitmap = generateReceiptBitmap(context, sale, storeName)
            val code = sale.formattedReceiptCode(storeName).replace("/", "_").replace("\\", "_")
            val filename = "Receipt_${code}_${System.currentTimeMillis()}.jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Receipt")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                } else {
                    val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    val receiptFolder = File(picturesDir, "Receipt")
                    if (!receiptFolder.exists()) {
                        receiptFolder.mkdirs()
                    }
                    val imageFile = File(receiptFolder, filename)
                    put(MediaStore.Images.Media.DATA, imageFile.absolutePath)
                }
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                Toast.makeText(context, "E-Receipt image saved to Gallery (Receipt folder)", Toast.LENGTH_SHORT).show()
                true
            } else {
                Toast.makeText(context, "Failed to save E-Receipt image", Toast.LENGTH_SHORT).show()
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving E-Receipt: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun saveDebtPaymentReceiptToGallery(context: Context, payment: DebtPayment, storeName: String): Boolean {
        return try {
            val bitmap = generateDebtPaymentReceiptBitmap(context, payment, storeName)
            val code = payment.formattedReceiptCode(storeName).replace("/", "_").replace("\\", "_")
            val filename = "Receipt_${code}_${System.currentTimeMillis()}.jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Receipt")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                } else {
                    val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    val receiptFolder = File(picturesDir, "Receipt")
                    if (!receiptFolder.exists()) {
                        receiptFolder.mkdirs()
                    }
                    val imageFile = File(receiptFolder, filename)
                    put(MediaStore.Images.Media.DATA, imageFile.absolutePath)
                }
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                Toast.makeText(context, "E-Receipt image saved to Gallery (Receipt folder)", Toast.LENGTH_SHORT).show()
                true
            } else {
                Toast.makeText(context, "Failed to save E-Receipt image", Toast.LENGTH_SHORT).show()
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving E-Receipt: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun saveDebtorStatementToGallery(context: Context, debtor: Debtor, sales: List<Sale>, debtPayments: List<DebtPayment>, storeName: String): Boolean {
        return try {
            val bitmap = generateDebtorStatementBitmap(context, debtor, sales, debtPayments, storeName)
            val cleanName = debtor.name.replace(" ", "_").replace("/", "_")
            val filename = "Utang_Statement_${cleanName}_${System.currentTimeMillis()}.jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Receipt")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                } else {
                    val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    val receiptFolder = File(picturesDir, "Receipt")
                    if (!receiptFolder.exists()) {
                        receiptFolder.mkdirs()
                    }
                    val imageFile = File(receiptFolder, filename)
                    put(MediaStore.Images.Media.DATA, imageFile.absolutePath)
                }
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
                Toast.makeText(context, "Utang Statement PNG saved to Gallery (Receipt folder)", Toast.LENGTH_SHORT).show()
                true
            } else {
                Toast.makeText(context, "Failed to save Utang Statement image", Toast.LENGTH_SHORT).show()
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving Utang Statement image: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun generateDebtorStatementBitmap(context: Context, debtor: Debtor, sales: List<Sale>, debtPayments: List<DebtPayment>, storeName: String): Bitmap {
        val width = 576
        val padding = 28f
        val linesToDraw = mutableListOf<ReceiptLine>()

        val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
        val storeAddr = prefs.getString("store_location", "Poblacion, Philippines") ?: "Poblacion, Philippines"
        val storeContact = prefs.getString("store_contact", "0912-345-6789") ?: "0912-345-6789"

        linesToDraw.add(ReceiptLine.Text(storeName.ifBlank { "ALKRIS POS" }, isBold = true, isCenter = true, fontSize = 24f))
        if (storeAddr.isNotBlank()) linesToDraw.add(ReceiptLine.Text(storeAddr, isCenter = true, fontSize = 18f))
        if (storeContact.isNotBlank()) linesToDraw.add(ReceiptLine.Text("Contact: $storeContact", isCenter = true, fontSize = 18f))
        
        linesToDraw.add(ReceiptLine.Text("UTANG STATEMENT REPORT", isBold = true, isCenter = true, fontSize = 22f))
        linesToDraw.add(ReceiptLine.Text(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")), isCenter = false, fontSize = 18f))
        linesToDraw.add(ReceiptLine.Divider)

        linesToDraw.add(ReceiptLine.Text("Debtor: ${debtor.name}", isBold = true, fontSize = 20f))
        if (debtor.contact.isNotBlank()) linesToDraw.add(ReceiptLine.Text("Contact: ${debtor.contact}", fontSize = 18f))
        linesToDraw.add(ReceiptLine.Row("Total Owed Balance", peso.format(debtor.totalOwed), isBold = true, fontSize = 22f))
        linesToDraw.add(ReceiptLine.Divider)

        if (sales.isNotEmpty()) {
            linesToDraw.add(ReceiptLine.Text("CREDIT TRANSACTIONS (UNPAID ITEMS)", isBold = true, fontSize = 18f))
            sales.forEach { sale ->
                linesToDraw.add(ReceiptLine.Text("Txn: ${sale.formattedReceiptCode(storeName)} • ${sale.purchasedAt.toLocalDate()}", isBold = true, fontSize = 16f))
                sale.lines.forEach { line ->
                    linesToDraw.add(ReceiptLine.Row("  ${line.itemName} x${line.quantity}", peso.format(line.subtotal)))
                }
                linesToDraw.add(ReceiptLine.Row("  Subtotal", peso.format(sale.total)))
            }
            linesToDraw.add(ReceiptLine.Divider)
        }

        if (debtPayments.isNotEmpty()) {
            linesToDraw.add(ReceiptLine.Text("RECENT PAYMENTS HISTORY", isBold = true, fontSize = 18f))
            debtPayments.forEach { p ->
                linesToDraw.add(ReceiptLine.Row("  Payment (${p.paidAt.toLocalDate()})", "-${peso.format(p.amount)}"))
            }
            linesToDraw.add(ReceiptLine.Divider)
        }

        val customFooter = prefs.getString("receipt_footer", "Thank you!") ?: "Thank you!"
        linesToDraw.add(ReceiptLine.Text(customFooter, isCenter = true, fontSize = 20f))

        var totalHeight = padding * 2
        linesToDraw.forEach { line ->
            totalHeight += when (line) {
                is ReceiptLine.Text -> line.fontSize * 1.5f
                is ReceiptLine.Row -> line.fontSize * 1.5f
                is ReceiptLine.Divider -> 16f
                is ReceiptLine.Signature -> 110f
            }
        }

        val bitmap = Bitmap.createBitmap(width, totalHeight.toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
        }

        var currentY = padding
        linesToDraw.forEach { line ->
            when (line) {
                is ReceiptLine.Text -> {
                    paint.textSize = line.fontSize
                    paint.typeface = if (line.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    currentY += line.fontSize
                    if (line.isCenter) {
                        paint.textAlign = Paint.Align.CENTER
                        canvas.drawText(line.text, width / 2f, currentY, paint)
                    } else {
                        paint.textAlign = Paint.Align.LEFT
                        canvas.drawText(line.text, padding, currentY, paint)
                    }
                    currentY += line.fontSize * 0.4f
                }
                is ReceiptLine.Row -> {
                    paint.textSize = line.fontSize
                    paint.typeface = if (line.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    currentY += line.fontSize

                    val rightWidth = paint.measureText(line.right)
                    val maxLeftWidth = (width - padding * 2) - rightWidth - 16f
                    var leftText = line.left
                    if (paint.measureText(leftText) > maxLeftWidth) {
                        while (leftText.length > 3 && paint.measureText("$leftText...") > maxLeftWidth) {
                            leftText = leftText.dropLast(1)
                        }
                        leftText = "$leftText..."
                    }

                    paint.textAlign = Paint.Align.LEFT
                    canvas.drawText(leftText, padding, currentY, paint)
                    paint.textAlign = Paint.Align.RIGHT
                    canvas.drawText(line.right, width - padding, currentY, paint)
                    currentY += line.fontSize * 0.4f
                }
                is ReceiptLine.Divider -> {
                    currentY += 6f
                    paint.strokeWidth = 2f
                    canvas.drawLine(padding, currentY, width - padding, currentY, paint)
                    currentY += 10f
                }
                is ReceiptLine.Signature -> {}
            }
        }

        return bitmap
    }
}
