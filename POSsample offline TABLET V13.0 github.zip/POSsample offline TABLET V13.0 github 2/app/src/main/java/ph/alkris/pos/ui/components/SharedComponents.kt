package ph.alkris.pos.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.MutableState
import java.io.ByteArrayOutputStream
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.time.format.DateTimeFormatter
import java.util.Locale

import androidx.compose.ui.graphics.luminance

val Blue = Color(0xFF10498E)
val SkyBlue = Color(0xFF8BBAFD)

val Green: Color
    @Composable
    get() = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) Color(0xFF66BB6A) else Color(0xFF16803C)

val Pink: Color
    @Composable
    get() = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) Color(0xFFFF7597) else Color(0xFFE91E63)
val Peso: NumberFormat = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
val ControlShape = RoundedCornerShape(14.dp)
val InventoryDateTimeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

val ScrollbarColor = Color(0xFF9E9E9E)

@Composable
fun ScrollbarLazyColumn(
    modifier: Modifier = Modifier,
    content: LazyListScope.() -> Unit
) {
    val state = rememberLazyListState()
    Box(modifier) {
        LazyColumn(Modifier.fillMaxSize(), state = state, content = content)
        LazyScrollbar(state)
    }
}

@Composable
fun LazyScrollbar(state: LazyListState) {
    Box(
        Modifier.fillMaxSize().drawWithContent {
            drawContent()
            val layout = state.layoutInfo
            val viewport = layout.viewportEndOffset - layout.viewportStartOffset
            val totalItems = layout.totalItemsCount
            val visibleItems = layout.visibleItemsInfo.size
            if (totalItems > visibleItems && viewport > 0) {
                val thumbHeight = (viewport * visibleItems.toFloat() / totalItems).coerceAtLeast(24f)
                val maxOffset = (viewport - thumbHeight).coerceAtLeast(0f)
                val progress = state.firstVisibleItemIndex.toFloat() / (totalItems - visibleItems).coerceAtLeast(1)
                drawRoundRect(
                    color = ScrollbarColor,
                    topLeft = Offset(size.width - 4.dp.toPx(), maxOffset * progress),
                    size = Size(3.dp.toPx(), thumbHeight),
                    cornerRadius = CornerRadius(2.dp.toPx())
                )
            }
        }
    )
}

@Composable
fun ProductImageThumbnail(
    imagePath: String?,
    fallbackText: String,
    modifier: Modifier = Modifier.size(36.dp)
) {
    val context = LocalContext.current

    val drawableResId = remember(imagePath) {
        if (!imagePath.isNullOrBlank() && imagePath.startsWith("drawable:")) {
            val resName = imagePath.removePrefix("drawable:")
            val resId = context.resources.getIdentifier(resName, "drawable", context.packageName)
            if (resId != 0) resId else null
        } else null
    }

    var bitmap by remember(imagePath) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(imagePath) {
        if (!imagePath.isNullOrBlank() && !imagePath.startsWith("drawable:")) {
            withContext(Dispatchers.IO) {
                try {
                    val decoded = when {
                        imagePath.startsWith("content://") -> {
                            val uri = Uri.parse(imagePath)
                            context.contentResolver.openInputStream(uri)?.use { stream ->
                                BitmapFactory.decodeStream(stream)
                            }
                        }
                        imagePath.startsWith("http://") || imagePath.startsWith("https://") -> {
                            val url = URL(imagePath)
                            val conn = url.openConnection() as HttpURLConnection
                            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)")
                            conn.connectTimeout = 8000
                            conn.readTimeout = 8000
                            conn.getInputStream().use { stream ->
                                BitmapFactory.decodeStream(stream)
                            }
                        }
                        File(imagePath).exists() -> {
                            BitmapFactory.decodeFile(imagePath)
                        }
                        else -> null
                    }
                    withContext(Dispatchers.Main) {
                        bitmap = decoded
                    }
                } catch (_: Exception) {
                    withContext(Dispatchers.Main) {
                        bitmap = null
                    }
                }
            }
        } else {
            bitmap = null
        }
    }

    Surface(
        modifier = modifier.clip(RoundedCornerShape(6.dp)),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Box(contentAlignment = Alignment.Center) {
            when {
                drawableResId != null -> {
                    Image(
                        painter = painterResource(id = drawableResId),
                        contentDescription = fallbackText,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                bitmap != null -> {
                    Image(
                        bitmap = bitmap!!.asImageBitmap(),
                        contentDescription = fallbackText,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    val initials = fallbackText.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString("").uppercase().ifBlank { "PR" }
                    Surface(
                        color = Blue.copy(alpha = 0.12f),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = initials,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Blue
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SignaturePad(points: MutableState<List<List<Offset>>>) {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(100.dp)
            .border(1.dp, Color.Gray, ControlShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    var currentStroke = listOf(down.position)
                    points.value = points.value + listOf(currentStroke)
                    down.consume()

                    drag(down.id) { change ->
                        change.consume()
                        currentStroke = currentStroke + change.position
                        points.value = points.value.dropLast(1) + listOf(currentStroke)
                    }
                }
            }
    ) {
        points.value.forEach { stroke ->
            if (stroke.size == 1) {
                drawCircle(
                    color = Color.Black,
                    radius = 3f,
                    center = stroke[0]
                )
            } else if (stroke.size > 1) {
                val path = Path()
                stroke.forEachIndexed { index, point ->
                    if (index == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
                }
                drawPath(
                    path = path,
                    color = Color.Black,
                    style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

fun signatureToBytes(strokes: List<List<Offset>>): ByteArray {
    val allPoints = strokes.flatten()
    if (allPoints.isEmpty()) return ByteArray(0)

    val bitmap = Bitmap.createBitmap(600, 200, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)

    val paint = Paint().apply {
        color = android.graphics.Color.BLACK
        strokeWidth = 6f
        style = Paint.Style.STROKE
        isAntiAlias = true
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    val dotPaint = Paint().apply {
        color = android.graphics.Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    val minX = allPoints.minOf { it.x }
    val maxX = allPoints.maxOf { it.x }
    val minY = allPoints.minOf { it.y }
    val maxY = allPoints.maxOf { it.y }
    val padWidth = (maxX - minX).coerceAtLeast(1f)
    val padHeight = (maxY - minY).coerceAtLeast(1f)

    val scaleX = 560f / padWidth
    val scaleY = 160f / padHeight
    val scale = minOf(scaleX, scaleY)

    val offsetX = 20f + (560f - padWidth * scale) / 2f
    val offsetY = 20f + (160f - padHeight * scale) / 2f

    strokes.forEach { stroke ->
        if (stroke.size == 1) {
            val point = stroke[0]
            val mappedX = offsetX + (point.x - minX) * scale
            val mappedY = offsetY + (point.y - minY) * scale
            canvas.drawCircle(mappedX, mappedY, 4f, dotPaint)
        } else if (stroke.size > 1) {
            val path = android.graphics.Path()
            stroke.forEachIndexed { index, point ->
                val mappedX = offsetX + (point.x - minX) * scale
                val mappedY = offsetY + (point.y - minY) * scale
                if (index == 0) path.moveTo(mappedX, mappedY) else path.lineTo(mappedX, mappedY)
            }
            canvas.drawPath(path, paint)
        }
    }

    return ByteArrayOutputStream().use { output ->
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        output.toByteArray()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomDateRangeDialog(
    initialStart: LocalDate,
    initialEnd: LocalDate,
    onConfirm: (LocalDate, LocalDate) -> Unit,
    onDismiss: () -> Unit
) {
    var selStart by remember { mutableStateOf(initialStart) }
    var selEnd by remember { mutableStateOf(initialEnd) }
    var activePicker by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Custom Date Range", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Choose Start Date and End Date:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { activePicker = if (activePicker == "START") null else "START" },
                        modifier = Modifier.weight(1f).height(54.dp),
                        shape = ControlShape,
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                        border = if (activePicker == "START") BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("Start Date", fontSize = 10.sp, color = Color.Gray, lineHeight = 12.sp)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = selStart.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                lineHeight = 14.sp,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1
                            )
                        }
                    }

                    Text("to", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp)

                    OutlinedButton(
                        onClick = { activePicker = if (activePicker == "END") null else "END" },
                        modifier = Modifier.weight(1f).height(54.dp),
                        shape = ControlShape,
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                        border = if (activePicker == "END") BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("End Date", fontSize = 10.sp, color = Color.Gray, lineHeight = 12.sp)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = selEnd.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                lineHeight = 14.sp,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1
                            )
                        }
                    }
                }

                if (activePicker == "START") {
                    Text("Select Start Date:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    val pickerState = rememberDatePickerState(initialSelectedDateMillis = selStart.toEpochDay() * 86_400_000L)
                    DatePicker(pickerState, showModeToggle = false)
                    LaunchedEffect(pickerState.selectedDateMillis) {
                        pickerState.selectedDateMillis?.let {
                            selStart = LocalDate.ofEpochDay(it / 86_400_000L)
                            if (selStart.isAfter(selEnd)) selEnd = selStart
                        }
                    }
                } else if (activePicker == "END") {
                    Text("Select End Date:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    val pickerState = rememberDatePickerState(initialSelectedDateMillis = selEnd.toEpochDay() * 86_400_000L)
                    DatePicker(pickerState, showModeToggle = false)
                    LaunchedEffect(pickerState.selectedDateMillis) {
                        pickerState.selectedDateMillis?.let {
                            val picked = LocalDate.ofEpochDay(it / 86_400_000L)
                            selEnd = if (picked.isBefore(selStart)) selStart else picked
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                Button(
                    onClick = {
                        onConfirm(selStart, selEnd)
                        onDismiss()
                    },
                    shape = ControlShape
                ) {
                    Text("Apply Date Range")
                }
            }
        }
    )
}
