package ph.alkris.pos.ui.screens

import ph.alkris.pos.ui.dialogs.AddCustomerProfileDialog
import ph.alkris.pos.data.roundPosPrice
import ph.alkris.pos.ui.components.*
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.widget.Toast
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ph.alkris.pos.data.CartLine
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.InventoryItem
import ph.alkris.pos.data.formattedReceiptCode
import ph.alkris.pos.ui.CashSoundManager
import ph.alkris.pos.ui.OpenShiftModalDialog
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.ReceiptImageExporter
import ph.alkris.pos.ui.ThermalPrinterManager
import ph.alkris.pos.ui.components.Blue
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Green
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.ui.components.Pink
import ph.alkris.pos.ui.components.ScrollbarLazyColumn
import ph.alkris.pos.ui.dialogs.DebtorsDialog
import java.time.format.DateTimeFormatter
import kotlin.math.ceil

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier,
    onScanRequested: ((String) -> Unit) -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedCategory by rememberSaveable { mutableStateOf("All Categories") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }
    var showActiveCartSheet by rememberSaveable { mutableStateOf(false) }
    var showCheckoutModal by rememberSaveable { mutableStateOf(false) }
    var showReceiptPreviewModal by rememberSaveable { mutableStateOf(false) }
    var showShiftRedirectDialog by remember { mutableStateOf(false) }
    var appliedDiscountAmount by rememberSaveable { mutableDoubleStateOf(0.0) }
    var weighedItemForModal by remember { mutableStateOf<InventoryItem?>(null) }

    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }

    var posColsPortrait by remember { mutableIntStateOf(prefs.getInt("pos_cols_portrait", 2)) }
    var posColsLandscape by remember { mutableIntStateOf(prefs.getInt("pos_cols_landscape", 3)) }
    var colMenuExpanded by remember { mutableStateOf(false) }

    fun triggerCheckoutFlow() {
        val isShiftOpen = prefs.getBoolean("shift_is_open", true)
        if (isShiftOpen) {
            showCheckoutModal = true
        } else {
            showShiftRedirectDialog = true
        }
    }

    fun triggerCartSheetFlow() {
        val isShiftOpen = prefs.getBoolean("shift_is_open", true)
        if (isShiftOpen) {
            showActiveCartSheet = true
        } else {
            showShiftRedirectDialog = true
        }
    }

    val categories = remember(state.inventory) {
        listOf("All Categories") + state.inventory.map { it.effectiveCategory }.distinct().sorted()
    }

    val isTablet = LocalContext.current.resources.configuration.smallestScreenWidthDp >= 600
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val isWideLayout = isTablet || isLandscape

    val salesQtyMap = remember(state.transactions) {
        state.transactions.flatMap { it.lines }
            .groupBy { it.barcode }
            .mapValues { (_, lines) -> lines.sumOf { it.quantity } }
    }

    val top20Barcodes = remember(salesQtyMap) {
        salesQtyMap.entries
            .filter { it.value > 0 }
            .sortedByDescending { it.value }
            .take(20)
            .map { it.key }
            .toSet()
    }

    val filteredProducts = remember(state.inventory, state.query, selectedCategory, salesQtyMap, top20Barcodes, isLandscape) {
        val baseList = state.inventory.filter { item ->
            val matchesCategory = (selectedCategory == "All Categories" || item.effectiveCategory == selectedCategory)
            val search = state.query.trim()
            val matchesQuery = search.isEmpty() ||
                    item.name.contains(search, ignoreCase = true) ||
                    item.barcode.contains(search, ignoreCase = true)
            matchesCategory && matchesQuery
        }

        if (isLandscape) {
            baseList.sortedWith(
                compareByDescending<InventoryItem> { !it.isOutOfStock }
                    .thenByDescending { if (top20Barcodes.contains(it.barcode)) 1 else 0 }
                    .thenByDescending { if (top20Barcodes.contains(it.barcode)) (salesQtyMap[it.barcode] ?: 0) else 0 }
                    .thenBy { it.name.lowercase() }
            )
        } else {
            baseList.sortedWith(
                compareByDescending<InventoryItem> { !it.isOutOfStock }
                    .thenByDescending { salesQtyMap[it.barcode] ?: 0 }
                    .thenBy { it.name.lowercase() }
            )
        }
    }

    fun handleAddToCart(item: InventoryItem) {
        if (item.isWeighed) {
            weighedItemForModal = item
        } else {
            CashSoundManager.playBeepSound()
            viewModel.addToCart(item)
        }
    }

    val effectiveTotal = (state.total - appliedDiscountAmount).coerceAtLeast(0.0)

    val categoryButtonContent = @Composable {
        Box {
            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            val categoryColor = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface
            OutlinedButton(
                onClick = { categoryDropdownExpanded = true },
                shape = ControlShape,
                colors = ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.height(38.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
            ) {
                Text(selectedCategory, color = categoryColor, fontSize = 12.sp, maxLines = 1)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = categoryColor)
            }

            DropdownMenu(
                expanded = categoryDropdownExpanded,
                onDismissRequest = { categoryDropdownExpanded = false }
            ) {
                categories.forEach { cat ->
                    DropdownMenuItem(
                        text = { Text(cat) },
                        onClick = {
                            selectedCategory = cat
                            categoryDropdownExpanded = false
                        }
                    )
                }
            }
        }
    }

    val productCountContent = @Composable {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = ControlShape,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Text(
                "${filteredProducts.size} products",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            )
        }
    }

    val topHeaderControls = @Composable {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp),
                    shape = ControlShape,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (state.query.isEmpty()) {
                                Text(
                                    text = "Search product or barcode...",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                            BasicTextField(
                                value = state.query,
                                onValueChange = viewModel::setQuery,
                                singleLine = true,
                                textStyle = TextStyle(
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Medium
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        if (state.query.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.setQuery("") },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear search",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                Surface(
                    onClick = {
                        onScanRequested { scanned ->
                            val match = state.inventory.firstOrNull { it.barcode.equals(scanned.trim(), ignoreCase = true) }
                            if (match != null) handleAddToCart(match)
                        }
                    },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        val scanIconTint = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) SkyBlue else MaterialTheme.colorScheme.primary
                        Icon(
                            Icons.Default.QrCodeScanner,
                            contentDescription = "Scan product barcode",
                            tint = scanIconTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Box {
                    Surface(
                        onClick = { colMenuExpanded = true },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            val colIconTint = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) SkyBlue else MaterialTheme.colorScheme.primary
                            Icon(
                                Icons.Default.ViewColumn,
                                contentDescription = "Grid Columns",
                                tint = colIconTint,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = colMenuExpanded,
                        onDismissRequest = { colMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Grid Columns (${if (isLandscape) posColsLandscape else posColsPortrait})", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            onClick = {}
                        )
                        HorizontalDivider()
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val curCols = if (isLandscape) posColsLandscape else posColsPortrait
                            OutlinedButton(
                                onClick = {
                                    val newCols = (curCols - 1).coerceAtLeast(1)
                                    if (isLandscape) {
                                        posColsLandscape = newCols
                                        prefs.edit().putInt("pos_cols_landscape", newCols).apply()
                                    } else {
                                        posColsPortrait = newCols
                                        prefs.edit().putInt("pos_cols_portrait", newCols).apply()
                                    }
                                },
                                enabled = curCols > 1,
                                modifier = Modifier.size(36.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("—", fontWeight = FontWeight.Bold)
                            }

                            Text("$curCols", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                            OutlinedButton(
                                onClick = {
                                    val newCols = (curCols + 1).coerceAtMost(6)
                                    if (isLandscape) {
                                        posColsLandscape = newCols
                                        prefs.edit().putInt("pos_cols_landscape", newCols).apply()
                                    } else {
                                        posColsPortrait = newCols
                                        prefs.edit().putInt("pos_cols_portrait", newCols).apply()
                                    }
                                },
                                enabled = curCols < 6,
                                modifier = Modifier.size(36.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("+", fontWeight = FontWeight.Bold)
                            }
                        }
                        HorizontalDivider()
                        (1..6).forEach { num ->
                            DropdownMenuItem(
                                text = { Text("$num Column${if (num > 1) "s" else ""}") },
                                onClick = {
                                    if (isLandscape) {
                                        posColsLandscape = num
                                        prefs.edit().putInt("pos_cols_landscape", num).apply()
                                    } else {
                                        posColsPortrait = num
                                        prefs.edit().putInt("pos_cols_portrait", num).apply()
                                    }
                                    colMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                if (isLandscape) {
                    categoryButtonContent()
                    productCountContent()
                }
            }

            if (!isLandscape) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    categoryButtonContent()
                    productCountContent()
                }
            }
        }
    }

    val productsContent = @Composable {
        val posColumnsCount = if (isLandscape) posColsLandscape else posColsPortrait
        val topPaddingVal = if (isLandscape) 52.dp else 96.dp
        val bottomPaddingVal = if (isLandscape) 8.dp else if (state.cart.isNotEmpty()) 140.dp else 80.dp

        Box(modifier = Modifier.fillMaxSize()) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(posColumnsCount),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = topPaddingVal, bottom = bottomPaddingVal),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredProducts, key = { it.barcode }) { item ->
                    ProductGridCard(item = item, onAdd = { handleAddToCart(item) })
                }
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                color = MaterialTheme.colorScheme.surface
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp, top = 2.dp)
                ) {
                    topHeaderControls()
                }
            }
        }
    }

    if (isWideLayout) {
        // TABLET: 2-PANE LAYOUT (Left = Products, Right = Active Cart)
        val cartBottomPadding = if (isLandscape) 0.dp else 88.dp
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(modifier = Modifier.weight(2f)) {
                productsContent()
            }

            ActiveCartPane(
                viewModel = viewModel,
                currentDiscount = appliedDiscountAmount,
                onDiscountChange = { appliedDiscountAmount = it },
                onCheckout = { triggerCheckoutFlow() },
                modifier = Modifier.weight(1f).padding(bottom = cartBottomPadding)
            )
        }
    } else {
        // PHONE PORTRAIT: SINGLE COLUMN + FLOATING ACTIVE CART BAR
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            productsContent()

            if (state.cart.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(bottom = 78.dp)
                        .clickable { triggerCartSheetFlow() },
                    color = Blue,
                    shape = RoundedCornerShape(12.dp),
                    shadowElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.White)
                            Column {
                                Text(
                                    "${state.cart.sumOf { it.quantity }} Items in Cart",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    "Tap to view & checkout",
                                    color = Color.White.copy(alpha = 0.9f),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                Peso.format(effectiveTotal),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.White)
                        }
                    }
                }
            }
        }
    }

    if (showShiftRedirectDialog) {
        OpenShiftModalDialog(
            onDismiss = { showShiftRedirectDialog = false },
            onConfirmed = { showShiftRedirectDialog = false }
        )
    }

    // ACTIVE CART SHEET
    if (showActiveCartSheet) {
        ActiveCartSheet(
            viewModel = viewModel,
            currentDiscount = appliedDiscountAmount,
            onDiscountChange = { appliedDiscountAmount = it },
            onClose = { showActiveCartSheet = false },
            onCheckout = {
                showActiveCartSheet = false
                showCheckoutModal = true
            }
        )
    }

    // CHECKOUT PAYMENT MODAL
    if (showCheckoutModal) {
        CheckoutModal(
            viewModel = viewModel,
            discountAmount = appliedDiscountAmount,
            onCancel = { showCheckoutModal = false },
            onSuccess = {
                showCheckoutModal = false
                showReceiptPreviewModal = true
            }
        )
    }

    // RECEIPT PREVIEW MODAL
    if (showReceiptPreviewModal) {
        ReceiptPreviewModal(
            viewModel = viewModel,
            onDone = {
                appliedDiscountAmount = 0.0
                showReceiptPreviewModal = false
            }
        )
    }

    if (weighedItemForModal != null) {
        WeightInputDialog(
            item = weighedItemForModal!!,
            onConfirm = { grams, weightKg ->
                CashSoundManager.playBeepSound()
                viewModel.addToCart(weighedItemForModal!!, grams, weightKg)
            },
            onDismiss = { weighedItemForModal = null }
        )
    }
}

@Composable
private fun ProductGridCard(item: InventoryItem, onAdd: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onAdd() },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // STOCK BADGE TOP RIGHT & UNIT WITH CENTER EXPIRATION TRIANGLE
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        item.unit,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }

                // CENTER EXPIRATION WARNING TRIANGLE WITH EXCLAMATION POINT
                if (item.isExpired || item.isExpiringSoon) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = if (item.isExpired) "Expired (${item.displayExpiryDate})" else "Expiring Soon (${item.displayExpiryDate})",
                        tint = if (item.isExpired) Pink else Color(0xFFFFD600),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    "${item.displayStock} left",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (item.isLowStock || item.isOutOfStock) Pink else Green
                )
            }

            // 1.5 INCH x 1.5 INCH LARGE PRODUCT IMAGE PHOTO
            ProductImageThumbnail(
                imagePath = item.imagePath,
                fallbackText = item.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
            )

            // PRODUCT NAME
            Text(
                item.name,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 2,
                lineHeight = 14.sp,
                textAlign = TextAlign.Center,
                overflow = TextOverflow.Ellipsis
            )

            // PRICE & PLUS (+) BUTTON AT LOWER RIGHT
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    Peso.format(item.sellingPrice),
                    color = Green,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Blue)
                        .clickable { onAdd() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = "Add to Cart",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveCartPane(
    viewModel: PosViewModel,
    currentDiscount: Double,
    onDiscountChange: (Double) -> Unit,
    onCheckout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var showDiscountDialog by remember { mutableStateOf(false) }
    var selectedCartLineForQty by remember { mutableStateOf<CartLine?>(null) }

    val subtotal = state.total
    val effectiveTotal = (subtotal - currentDiscount).coerceAtLeast(0.0)

    Card(
        modifier = modifier.fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            // HEADER
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Blue, modifier = Modifier.size(16.dp))
                    Text("Active Cart (${state.cart.sumOf { it.quantity }})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                if (state.cart.isNotEmpty()) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    TextButton(
                        onClick = { viewModel.clearCart() },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Text("Clear", color = if (isDark) Color.White else Pink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

            // CART ITEMS LIST
            if (state.cart.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Cart is empty\nTap products on left to add", color = Color.Gray, textAlign = TextAlign.Center, fontSize = 11.sp)
                }
            } else {
                ScrollbarLazyColumn(modifier = Modifier.weight(1f)) {
                    items(state.cart, key = { it.item.barcode }) { line ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 4.dp)
                                    .clickable { selectedCartLineForQty = line }
                            ) {
                                Text(
                                    text = line.item.name,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 11.sp,
                                    lineHeight = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(Peso.format(line.item.sellingPrice), fontSize = 10.sp, color = Color.Gray)
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                modifier = Modifier.padding(horizontal = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(Color.Gray)
                                        .clickable { viewModel.changeQuantity(line.item, -1) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Remove,
                                        contentDescription = "Decrease",
                                        tint = Color.White,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }

                                Text(
                                    text = when {
                                        line.item.isKg -> "${line.weightKg} kg"
                                        line.item.isGrams -> "${line.grams.toInt()} grm"
                                        else -> "${line.quantity}"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.clickable { selectedCartLineForQty = line }
                                )

                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(Blue)
                                        .clickable {
                                            CashSoundManager.playBeepSound()
                                            viewModel.changeQuantity(line.item, 1)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Increase",
                                        tint = Color.White,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }

                            Text(Peso.format(line.subtotal), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Green)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

            // 3 LINES SUMMARY (UNIFORM CLOSE SPACING)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Discount:", fontSize = 11.sp, color = Pink, fontWeight = FontWeight.Medium, lineHeight = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = { showDiscountDialog = true },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                            modifier = Modifier.height(20.dp)
                        ) {
                            if (currentDiscount > 0) {
                                Text("-${Peso.format(currentDiscount)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Pink, lineHeight = 12.sp)
                            } else {
                                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                Text("Add Discount", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (isDark) Color.White else MaterialTheme.colorScheme.primary, lineHeight = 12.sp)
                            }
                        }

                        if (currentDiscount > 0) {
                            IconButton(
                                onClick = { onDiscountChange(0.0) },
                                modifier = Modifier.size(18.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Remove Discount",
                                    tint = Pink,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Subtotal:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium, lineHeight = 12.sp)
                    Text(Peso.format(subtotal), fontSize = 11.sp, fontWeight = FontWeight.Medium, lineHeight = 12.sp)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(22.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TOTAL:", fontWeight = FontWeight.Bold, fontSize = 13.sp, lineHeight = 14.sp)
                    Text(Peso.format(effectiveTotal), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Green, lineHeight = 15.sp)
                }
            }

            Spacer(Modifier.height(4.dp))

            Button(
                onClick = onCheckout,
                enabled = state.cart.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(36.dp),
                shape = ControlShape,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                contentPadding = PaddingValues(vertical = 0.dp)
            ) {
                Text("CHECKOUT", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }

    if (selectedCartLineForQty != null) {
        CartItemQuantityDialog(
            line = selectedCartLineForQty!!,
            viewModel = viewModel,
            onDismiss = { selectedCartLineForQty = null }
        )
    }

    if (showDiscountDialog) {
        var discountInput by remember { mutableStateOf(if (currentDiscount > 0) currentDiscount.toString() else "") }
        AlertDialog(
            onDismissRequest = { showDiscountDialog = false },
            title = { Text("Input Discount Amount (₱)", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = discountInput,
                        onValueChange = { discountInput = it },
                        label = { Text("Discount Amount (₱)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = discountInput.toDoubleOrNull() ?: 0.0
                        onDiscountChange(amt.coerceIn(0.0, subtotal))
                        showDiscountDialog = false
                    }
                ) { Text("Apply Discount") }
            },
            dismissButton = {
                TextButton(onClick = {
                    onDiscountChange(0.0)
                    showDiscountDialog = false
                }) { Text("Clear Discount") }
            }
        )
    }
}

@Composable
private fun CartItemQuantityDialog(
    line: CartLine,
    viewModel: PosViewModel,
    onDismiss: () -> Unit
) {
    val initialInput = when {
        line.item.isKg -> line.weightKg.toString()
        line.item.isGrams -> line.grams.toInt().toString()
        else -> line.quantity.toString()
    }
    var qtyInput by remember { mutableStateOf(initialInput) }
    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f

    val inputVal = qtyInput.toDoubleOrNull() ?: 0.0
    val computedPrice = when {
        line.item.isKg -> roundPosPrice(inputVal * line.item.sellingPrice)
        line.item.isGrams -> roundPosPrice((inputVal / 1000.0) * line.item.sellingPrice)
        else -> roundPosPrice(inputVal * line.item.sellingPrice)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Edit Item - ${line.item.name}",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = if (line.item.isKg) "Price: ${Peso.format(line.item.sellingPrice)}/kg"
                           else if (line.item.isGrams) "Price: ${Peso.format(line.item.sellingPrice)}/1000g"
                           else "Price: ${Peso.format(line.item.sellingPrice)}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                OutlinedTextField(
                    value = qtyInput,
                    onValueChange = { input ->
                        val sanitized = input.replace(',', '.')
                        if (sanitized.matches(Regex("""\d*([.]\d{0,2})?"""))) qtyInput = sanitized
                    },
                    label = { Text(if (line.item.isKg) "Weight (in kg)" else if (line.item.isGrams) "Weight (in grams)" else "Quantity") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )

                if (inputVal > 0.0) {
                    Text("Subtotal: ${Peso.format(computedPrice)}", fontWeight = FontWeight.Bold, color = Green, fontSize = 13.sp)
                }

                if (!line.item.isWeighed) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1, 5, 10, 100).forEach { add ->
                            OutlinedButton(
                                onClick = {
                                    val current = qtyInput.toIntOrNull() ?: 0
                                    qtyInput = (current + add).toString()
                                },
                                modifier = Modifier.weight(1f).height(34.dp),
                                shape = ControlShape,
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    text = "+$add",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = if (isDark) Color.White else MaterialTheme.colorScheme.primary)
                    }
                    TextButton(
                        onClick = {
                            viewModel.setItemQuantity(line.item, 0)
                            onDismiss()
                        }
                    ) {
                        Text("Remove", color = Pink)
                    }
                }
                Button(
                    onClick = {
                        val numVal = qtyInput.toDoubleOrNull() ?: 0.0
                        if (numVal > 0.0) {
                            when {
                                line.item.isKg -> viewModel.setItemQuantity(line.item, 1, targetKg = numVal)
                                line.item.isGrams -> viewModel.setItemQuantity(line.item, 1, targetGrams = numVal)
                                else -> viewModel.setItemQuantity(line.item, numVal.toInt())
                            }
                        } else {
                            viewModel.setItemQuantity(line.item, 0)
                        }
                        onDismiss()
                    },
                    shape = ControlShape
                ) {
                    Text("Update", fontWeight = FontWeight.Bold)
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ActiveCartSheet(
    viewModel: PosViewModel,
    currentDiscount: Double,
    onDiscountChange: (Double) -> Unit,
    onClose: () -> Unit,
    onCheckout: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var showDiscountDialog by remember { mutableStateOf(false) }
    var selectedCartLineForQty by remember { mutableStateOf<CartLine?>(null) }

    val subtotal = state.total
    val effectiveTotal = (subtotal - currentDiscount).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = onClose,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onClose) { Text("Close") }
                Text("Active Cart (${state.cart.sumOf { it.quantity }})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Button(
                    onClick = onCheckout,
                    enabled = state.cart.isNotEmpty(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) { Text("Checkout", fontSize = 13.sp) }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
            ) {
                ScrollbarLazyColumn(modifier = Modifier.weight(1f)) {
                    items(state.cart, key = { it.item.barcode }) { line ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedCartLineForQty = line }
                            ) {
                                Text(line.item.name, fontWeight = FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(Peso.format(line.item.sellingPrice), style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(Color.Gray)
                                        .clickable { viewModel.changeQuantity(line.item, -1) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Remove,
                                        contentDescription = "Decrease",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }

                                Text(
                                    "${line.quantity}",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 14.sp,
                                    modifier = Modifier.clickable { selectedCartLineForQty = line }
                                )

                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(Blue)
                                        .clickable {
                                            CashSoundManager.playBeepSound()
                                            viewModel.changeQuantity(line.item, 1)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Increase",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }

                            Text(Peso.format(line.subtotal), fontWeight = FontWeight.Bold, color = Green)
                        }
                        HorizontalDivider()
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 3 LINES OF SUMMARY BEFORE CHECKOUT BUTTON
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // LINE 1: DISCOUNT (LEFT) & ADD DISCOUNT BUTTON OR DISCOUNT VALUE WITH REMOVE OPTION (RIGHT)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Discount:", fontSize = 12.sp, color = Pink)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(
                                onClick = { showDiscountDialog = true },
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                modifier = Modifier.height(26.dp)
                            ) {
                                if (currentDiscount > 0) {
                                    Text("-${Peso.format(currentDiscount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Pink)
                                } else {
                                    Text("Add Discount", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            if (currentDiscount > 0) {
                                IconButton(
                                    onClick = { onDiscountChange(0.0) },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Remove Discount",
                                        tint = Pink,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    // LINE 2: SUBTOTAL
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Subtotal:", fontSize = 12.sp, color = Color.Gray)
                        Text(Peso.format(subtotal), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }

                    // LINE 3: TOTAL (SLIGHTLY BIGGER FONT COMPARED TO SUBTOTAL TEXT)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(Peso.format(effectiveTotal), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Green)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onCheckout,
                enabled = state.cart.isNotEmpty(),
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Text("CHECKOUT", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    )

    if (selectedCartLineForQty != null) {
        CartItemQuantityDialog(
            line = selectedCartLineForQty!!,
            viewModel = viewModel,
            onDismiss = { selectedCartLineForQty = null }
        )
    }

    if (showDiscountDialog) {
        var discountInput by remember { mutableStateOf(if (currentDiscount > 0) currentDiscount.toString() else "") }
        AlertDialog(
            onDismissRequest = { showDiscountDialog = false },
            title = { Text("Input Discount Amount (₱)", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = discountInput,
                        onValueChange = { discountInput = it },
                        label = { Text("Discount Amount (₱)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        onDiscountChange(0.0)
                        showDiscountDialog = false
                    }) { Text("Cancel") }
                    Button(
                        onClick = {
                            val amt = discountInput.toDoubleOrNull() ?: 0.0
                            onDiscountChange(amt.coerceIn(0.0, subtotal))
                            showDiscountDialog = false
                        }
                    ) { Text("Apply Discount") }
                }
            }
        )
    }
}

@Composable
private fun CheckoutModal(
    viewModel: PosViewModel,
    discountAmount: Double,
    onCancel: () -> Unit,
    onSuccess: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var paymentMethod by remember { mutableStateOf("Cash") } // Cash, Utang, GCash
    var partialPaymentText by remember { mutableStateOf("") }
    val partialPayment = partialPaymentText.toDoubleOrNull() ?: 0.0

    val subtotalAfterDiscount = (state.total - discountAmount).coerceAtLeast(0.0)
    val amountDue = if (paymentMethod == "Utang") {
        (subtotalAfterDiscount - partialPayment).coerceAtLeast(0.0)
    } else {
        subtotalAfterDiscount
    }

    var cashTenderedText by remember { mutableStateOf(Peso.format(amountDue).removePrefix("₱")) }
    var selectedDebtor by remember { mutableStateOf<Debtor?>(null) }
    var showCustomerPopup by remember { mutableStateOf(false) }
    var customerSearchQuery by remember { mutableStateOf("") }
    var showAddNewCustomerDialog by remember { mutableStateOf(false) }

    var refNumber by remember { mutableStateOf("") }
    var notesRef by remember { mutableStateOf("") }
    val signaturePoints = remember { mutableStateOf<List<List<Offset>>>(emptyList()) }

    val cashTendered = if (paymentMethod == "Utang") partialPayment else (cashTenderedText.toDoubleOrNull() ?: amountDue)
    val changeDue = if (paymentMethod == "Cash") (cashTendered - amountDue).coerceAtLeast(0.0) else 0.0

    LaunchedEffect(Unit) {
        viewModel.loadDebtors()
    }
    LaunchedEffect(paymentMethod) {
        if (paymentMethod == "Utang") {
            viewModel.loadDebtors()
        }
    }
    LaunchedEffect(showCustomerPopup) {
        if (showCustomerPopup) {
            viewModel.loadDebtors()
        }
    }

    val isTablet = LocalContext.current.resources.configuration.smallestScreenWidthDp >= 600
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val isWideLayout = isTablet || isLandscape

    val titleFontSize = if (isWideLayout) 16.sp else 14.sp
    val sectionFontSize = if (isWideLayout) 15.sp else 13.sp
    val bodyFontSize = if (isWideLayout) 14.sp else 12.sp
    val totalFontSize = if (isWideLayout) 22.sp else 20.sp

    AlertDialog(
        onDismissRequest = onCancel,
        title = {
            Text(
                text = "Checkout",
                fontSize = titleFontSize,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // AMOUNT DUE CARD
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal:", fontSize = bodyFontSize)
                            Text(Peso.format(state.total), fontSize = bodyFontSize)
                        }
                        if (discountAmount > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Discount:", fontSize = bodyFontSize, color = Pink)
                                Text("-${Peso.format(discountAmount)}", fontSize = bodyFontSize, color = Pink)
                            }
                        }
                        if (paymentMethod == "Utang" && partialPayment > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Partial Cash Payment:", fontSize = bodyFontSize, color = Blue, fontWeight = FontWeight.SemiBold)
                                Text("-${Peso.format(partialPayment)}", fontSize = bodyFontSize, color = Blue, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (paymentMethod == "Utang") "Total (Debt):" else "Total:", fontWeight = FontWeight.Bold, fontSize = if (isWideLayout) 18.sp else 16.sp)
                            Text(Peso.format(amountDue), fontWeight = FontWeight.Bold, fontSize = totalFontSize, color = Green)
                        }
                    }
                }

                // PAYMENT METHOD SELECTOR BAR
                Text("Payment Method", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, fontSize = sectionFontSize)
                val methods = listOf("Cash", "Utang", "GCash")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    methods.forEach { m ->
                        FilterChip(
                            selected = paymentMethod == m,
                            onClick = { paymentMethod = m },
                            label = { Text(m, fontSize = if (isWideLayout) 15.sp else 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 4.dp)) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // METHOD-SPECIFIC INPUTS
                when (paymentMethod) {
                    "Cash" -> {
                        Text("Cash Received & Change", fontWeight = FontWeight.Bold, fontSize = sectionFontSize)
                        OutlinedTextField(
                            value = cashTenderedText,
                            onValueChange = { cashTenderedText = it },
                            label = { Text("Cash Received (₱)", fontSize = sectionFontSize) },
                            textStyle = TextStyle(fontSize = if (isWideLayout) 18.sp else 16.sp, fontWeight = FontWeight.Bold),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            shape = ControlShape,
                            modifier = Modifier.fillMaxWidth()
                        )

                        val hundredsValue = amountDue % 1000.0
                        val dynamicPresetValue = if (hundredsValue >= 500.0) {
                            (ceil((amountDue + 0.01) / 1000.0) * 1000.0).coerceAtLeast(1000.0)
                        } else {
                            (ceil((amountDue + 0.01) / 100.0) * 100.0).coerceAtLeast(100.0)
                        }

                        val cashPresets = listOf(
                            "Exact" to amountDue,
                            Peso.format(dynamicPresetValue).removeSuffix(".00") to dynamicPresetValue,
                            "₱500" to 500.0,
                            "₱1,000" to 1000.0
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            cashPresets.forEach { (lbl, valAmt) ->
                                OutlinedButton(
                                    onClick = { cashTenderedText = if (valAmt % 1.0 == 0.0) valAmt.toLong().toString() else valAmt.toString() },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                                ) {
                                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                    Text(
                                        lbl,
                                        fontSize = if (isWideLayout) 18.sp else 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color.White else MaterialTheme.colorScheme.primary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Change Due:", fontWeight = FontWeight.Bold, fontSize = sectionFontSize)
                            Text(Peso.format(changeDue), fontWeight = FontWeight.Bold, fontSize = if (isWideLayout) 20.sp else 18.sp, color = Pink)
                        }
                    }

                    "Utang" -> {
                        Text("Select Utang Customer", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        // CUSTOMER SELECTION TRIGGER BUTTON WITH BESIDE MAN ICON + PLUS SIGN
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { showCustomerPopup = true },
                                modifier = Modifier.weight(1f),
                                shape = ControlShape
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        selectedDebtor?.let { "${it.name} (${it.contact})" } ?: "-- Select Customer --",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Expand")
                                }
                            }

                            // MAN ICON WITH PLUS SIGN BESIDE SELECT CUSTOMER BUTTON
                            IconButton(
                                onClick = { showAddNewCustomerDialog = true },
                                modifier = Modifier.size(42.dp)
                            ) {
                                Icon(
                                    Icons.Default.PersonAdd,
                                    contentDescription = "Add Customer Profile",
                                    tint = Blue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        selectedDebtor?.let { d ->
                            Text("Current Debt: ${Peso.format(d.totalOwed)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("New Total Debt: ${Peso.format(d.totalOwed + amountDue)}", fontWeight = FontWeight.Bold, color = Pink)
                        }

                        Spacer(Modifier.height(4.dp))

                        // PARTIAL CASH PAYMENT (DOWNPAYMENT) INPUT
                        Text("Partial Cash Payment (Downpayment)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        OutlinedTextField(
                            value = partialPaymentText,
                            onValueChange = { partialPaymentText = it },
                            label = { Text("Downpayment (₱)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            shape = ControlShape,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(Modifier.height(4.dp))

                        if (selectedDebtor != null) {
                            Surface(
                                color = Green.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text("✓ Agreement Signed & Saved on File (${selectedDebtor?.name})", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                        Text("Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }

                    "GCash" -> {
                        Text("GCash Transaction Reference", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        OutlinedTextField(
                            value = refNumber,
                            onValueChange = { refNumber = it },
                            label = { Text("GCash Reference No. / Trace No.") },
                            singleLine = true,
                            shape = ControlShape,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier.weight(1f),
                    shape = ControlShape
                ) {
                    Text(
                        text = "Cancel",
                        fontSize = titleFontSize,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else MaterialTheme.colorScheme.primary
                    )
                }

                Button(
                    onClick = {
                        val sigBytes = if (paymentMethod == "Utang") selectedDebtor?.signature else null

                        if (paymentMethod == "Utang") {
                            if (selectedDebtor == null) {
                                Toast.makeText(context, "Please select a customer for Utang checkout", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                        }

                        if (paymentMethod == "GCash") {
                            if (refNumber.isBlank()) {
                                Toast.makeText(context, "GCash Reference No. is required", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                        }

                        viewModel.completeSale(
                            discount = discountAmount,
                            paymentType = when (paymentMethod) {
                                "Utang" -> "CREDIT"
                                "GCash" -> "GCASH"
                                else -> "CASH"
                            },
                            customerName = selectedDebtor?.name ?: "Walkin",
                            customerContact = if (paymentMethod == "Utang") selectedDebtor?.contact ?: "" else refNumber.trim(),
                            signature = sigBytes,
                            pin = null,
                            cashReceived = cashTendered,
                            change = changeDue,
                            onSuccess = {
                                CashSoundManager.playChimeSound(context)
                                onSuccess()
                            },
                            onError = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
                        )
                    },
                    enabled = when (paymentMethod) {
                        "GCash" -> refNumber.isNotBlank()
                        "Utang" -> selectedDebtor != null
                        else -> true
                    },
                    modifier = Modifier.weight(1f),
                    shape = ControlShape
                ) {
                    Text(
                        text = "Pay Now",
                        fontSize = titleFontSize,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    )

    if (showCustomerPopup) {
        AlertDialog(
            onDismissRequest = { showCustomerPopup = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Select Customer", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = { showCustomerPopup = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 1. + ADD NEW CUSTOMER PROFILE (TOP)
                    Button(
                        onClick = {
                            showCustomerPopup = false
                            showAddNewCustomerDialog = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = ControlShape,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Blue)
                            Text("+ Add New Customer Profile", fontWeight = FontWeight.Bold, color = Blue, fontSize = 13.sp)
                        }
                    }

                    // 2. LINE SEPARATOR
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // 3. SEARCH BAR
                    OutlinedTextField(
                        value = customerSearchQuery,
                        onValueChange = { customerSearchQuery = it },
                        placeholder = { Text("Search customer name or phone...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // 4. FIRST 5 MATCHING CUSTOMERS SORTED A-Z
                    val top5Customers = remember(state.debtors, customerSearchQuery) {
                        val q = customerSearchQuery.trim()
                        state.debtors
                            .filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) || it.contact.contains(q, ignoreCase = true) }
                            .sortedBy { it.name.lowercase() }
                            .take(5)
                    }

                    if (top5Customers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No matching customers found", color = Color.Gray, fontSize = 12.sp)
                        }
                    } else {
                        ScrollbarLazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 220.dp)
                        ) {
                            items(top5Customers, key = { it.contact }) { debtor ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .clickable {
                                            selectedDebtor = debtor
                                            showCustomerPopup = false
                                        },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (selectedDebtor?.contact == debtor.contact) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                    ),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(debtor.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(debtor.contact, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        }
                                        Text(
                                            "Debt: ${Peso.format(debtor.totalOwed)}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = Pink
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    if (showAddNewCustomerDialog) {
        AddCustomerProfileDialog(
            viewModel = viewModel,
            initialDebtor = null,
            onDismiss = { showAddNewCustomerDialog = false },
            onCustomerSaved = { createdDebtor ->
                selectedDebtor = createdDebtor
            }
        )
    }
}

@Composable
private fun ReceiptPreviewModal(
    viewModel: PosViewModel,
    onDone: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }
    val storeAddr = remember { prefs.getString("store_location", "Poblacion, Philippines") ?: "Poblacion, Philippines" }
    val storeContact = remember { prefs.getString("store_contact", "0912-345-6789") ?: "0912-345-6789" }
    val customFooter = remember { prefs.getString("receipt_footer", "Thank you for shopping at AlKris!") ?: "Thank you for shopping at AlKris!" }
    val sale = state.lastSale

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            sale?.let { ThermalPrinterManager.print(context, it, state.storeName) }
        } else {
            Toast.makeText(context, "Bluetooth permission required for thermal printer", Toast.LENGTH_SHORT).show()
        }
    }

    AlertDialog(
        onDismissRequest = onDone,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Receipt Preview",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Button(onClick = onDone) { Text("Done") }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // THERMAL RECEIPT DISPLAY
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(state.storeName.ifBlank { "ALKRIS SARI-SARI STORE" }, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (storeAddr.isNotBlank()) {
                            Text(storeAddr, fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
                        }
                        if (storeContact.isNotBlank()) {
                            Text("Contact: $storeContact", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))

                        sale?.let { s ->
                            Text("Receipt #: ${s.formattedReceiptCode(state.storeName)}", fontSize = 10.sp)
                            Text("Date: ${s.purchasedAt.format(DateTimeFormatter.ofPattern("MM/dd/yyyy, hh:mm a"))}", fontSize = 10.sp)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))

                            s.lines.forEach { line ->
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(line.itemName, fontSize = 10.sp, modifier = Modifier.weight(1f))
                                    Text("${line.quantity} x ${Peso.format(line.unitPrice)}", fontSize = 10.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(Peso.format(line.subtotal), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("TOTAL AMOUNT:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(Peso.format(s.total), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Green)
                            }

                            if (s.paymentType == "CREDIT") {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))
                                Text("UTANG (Credit Transaction)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Pink)
                                Text("Name: ${s.customerName}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                if (s.customerContact.isNotBlank()) {
                                    Text("Contact: ${s.customerContact}", fontSize = 10.sp, color = Color.Gray)
                                }

                                val partialCash = (s.cashReceived - s.change).coerceAtLeast(0.0)
                                val remainingOwed = (s.total - partialCash).coerceAtLeast(0.0)
                                if (partialCash > 0.0) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Partial Cash Paid:", fontSize = 10.sp)
                                        Text(Peso.format(partialCash), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Remaining Owed:", fontSize = 10.sp)
                                        Text(Peso.format(remainingOwed), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Pink)
                                    }
                                }

                                Spacer(Modifier.height(4.dp))
                                Text("Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.", fontSize = 9.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, color = Color.DarkGray)

                                if (s.signature != null && s.signature.isNotEmpty()) {
                                    val sigBmp = remember(s.signature) {
                                        runCatching {
                                            BitmapFactory.decodeByteArray(s.signature, 0, s.signature.size)
                                        }.getOrNull()
                                    }
                                    sigBmp?.let { bmp ->
                                        Spacer(Modifier.height(4.dp))
                                        Text("Customer Signature:", fontSize = 9.sp, color = Color.Gray)
                                        Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = "Customer Signature",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(60.dp),
                                            contentScale = ContentScale.Fit
                                        )
                                    }
                                }
                            } else if (s.paymentType.equals("GCASH", ignoreCase = true) || s.paymentType.equals("EWALLET", ignoreCase = true)) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Payment Method:", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("GCash", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Blue)
                                }
                                if (s.customerContact.isNotBlank()) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("GCash Ref / Trace #:", fontSize = 10.sp)
                                        Text(s.customerContact, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Amount Paid (GCash):", fontSize = 10.sp)
                                    Text(Peso.format(s.total), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Green)
                                }
                            } else {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 3.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Payment Method:", fontSize = 10.sp)
                                    Text("Cash", fontSize = 10.sp)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Cash Received:", fontSize = 10.sp)
                                    Text(Peso.format(s.cashReceived), fontSize = 10.sp)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Change:", fontSize = 10.sp)
                                    Text(Peso.format(s.change), fontSize = 10.sp)
                                }
                            }
                        }

                        Spacer(Modifier.height(6.dp))
                        Text(customFooter.ifBlank { "Thank you for shopping!" }, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, textAlign = TextAlign.Center)
                        Text("NOT VALID FOR BIR CLAIMING TAX", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("INTERNAL STORE MONITORING PURPOSES ONLY", fontSize = 8.sp, color = Color.Gray)
                    }
                }

                // THERMAL PRINTER CONTROLS
                Text("Thermal Printer Status: Connected • Ready to print", fontWeight = FontWeight.Bold, color = Green, fontSize = 12.sp)

                Button(
                    onClick = {
                        sale?.let { s ->
                            val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                arrayOf(
                                    Manifest.permission.BLUETOOTH_CONNECT,
                                    Manifest.permission.BLUETOOTH_SCAN,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                )
                            } else {
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                            }
                            val missing = permissions.filter {
                                ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
                            }
                            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
                            else ThermalPrinterManager.print(context, s, state.storeName)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = ControlShape
                ) {
                    Icon(Icons.Default.Print, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Print")
                }

                OutlinedButton(
                    onClick = {
                        sale?.let { s ->
                            ReceiptImageExporter.saveReceiptToGallery(context, s, state.storeName)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = ControlShape
                ) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    val eReceiptTint = if (isDark) Color.White else Green
                    Icon(Icons.Default.Download, contentDescription = null, tint = eReceiptTint)
                    Spacer(Modifier.width(8.dp))
                    Text("Save E-Receipt Image", color = eReceiptTint, fontWeight = FontWeight.SemiBold)
                }
            }
        },
        confirmButton = {}
    )
}
