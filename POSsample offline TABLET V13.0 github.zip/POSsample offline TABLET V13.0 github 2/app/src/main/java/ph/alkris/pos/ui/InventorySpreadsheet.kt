package ph.alkris.pos.ui

import android.text.Html
import ph.alkris.pos.data.InventoryItem
import java.io.InputStream
import java.io.OutputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private val SpreadsheetDateFormat = DateTimeFormatter.ISO_LOCAL_DATE_TIME
private val InventoryColumns = listOf(
    "barcode", "name", "purchase_cost", "selling_price", "stock_quantity", "low_stock_limit", "recommended_stock"
)

internal object InventorySpreadsheet {
    fun write(output: OutputStream, inventory: List<InventoryItem>) {
        val rows = buildString {
            append("<row r=\"1\">")
            InventoryColumns.forEachIndexed { index, column -> append(cell(index + 1, 1, column)) }
            append("</row>")
            inventory.forEachIndexed { rowIndex, item ->
                val row = rowIndex + 2
                append("<row r=\"$row\">")
                listOf(
                    item.barcode,
                    item.name,
                    item.purchaseCost,
                    item.sellingPrice,
                    item.stockQuantity,
                    item.lowStockLimit,
                    item.recommendedStock
                ).forEachIndexed { index, value -> append(cell(index + 1, row, value.toString())) }
                append("</row>")
            }
        }
        ZipOutputStream(output).use { zip ->
            entry(zip, "[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry(zip, "_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry(zip, "xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Inventory" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry(zip, "xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            entry(zip, "xl/worksheets/sheet1.xml", """<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$rows</sheetData></worksheet>""")
        }
    }

    fun read(input: InputStream): List<InventoryItem> {
        val entries = ZipInputStream(input).use { zip ->
            buildMap {
                generateSequence { zip.nextEntry }.forEach { entry ->
                    if (!entry.isDirectory) put(entry.name, zip.readBytes().toString(Charsets.UTF_8))
                }
            }
        }
        val sheet = entries.entries
            .firstOrNull { it.key.startsWith("xl/worksheets/") && it.key.endsWith(".xml") }
            ?.value
            ?: error("The selected file does not contain an Inventory worksheet")
        val sharedStrings = entries["xl/sharedStrings.xml"]
            ?.let { parseSharedStrings(it) }
            ?: emptyList()
        val rows = Regex("<row\\b[^>]*>(.*?)</row>", RegexOption.DOT_MATCHES_ALL)
            .findAll(sheet)
            .map { match ->
                Regex("<c\\b[^>]*>(.*?)</c>", RegexOption.DOT_MATCHES_ALL)
                    .findAll(match.groupValues[1])
                    .mapNotNull { cellMatch ->
                        val attributes = cellMatch.value.substringBefore('>')
                        val reference = attribute(attributes, "r") ?: return@mapNotNull null
                        val column = reference.takeWhile { it.isLetter() }
                            .fold(0) { result, letter -> result * 26 + (letter.uppercaseChar() - 'A' + 1) } - 1
                        val body = cellMatch.groupValues[1]
                        val type = attribute(attributes, "t")
                        val rawValue = Regex("<(?:t|v)\\b[^>]*>(.*?)</(?:t|v)>", RegexOption.DOT_MATCHES_ALL)
                            .find(body)?.groupValues?.get(1) ?: ""
                        val value = when (type) {
                            "s" -> sharedStrings.getOrNull(rawValue.trim().toIntOrNull() ?: -1).orEmpty()
                            else -> decodeXml(rawValue)
                        }
                        column to value.trim()
                    }
                    .toList()
                    .let { cells ->
                        List(maxOf(6, (cells.maxOfOrNull { it.first } ?: -1) + 1)) { index ->
                            cells.firstOrNull { it.first == index }?.second.orEmpty()
                        }
                    }
            }.toList()

        val headerColumns = rows.firstOrNull()?.map { it.lowercase() }.orEmpty()
        val hasRecommendedStock = headerColumns.getOrNull(6) == "recommended_stock"

        require(headerColumns.take(6) == InventoryColumns.take(6)) {
            "Invalid inventory template. Expected columns: ${InventoryColumns.take(6).joinToString(", ")}"
        }

        return rows.drop(1).filter { it.any(String::isNotBlank) }.mapIndexed { index, values ->
            require(values.size >= 6) { "Invalid inventory row ${index + 2}" }
            val recStock = if (hasRecommendedStock && values.size >= 7 && values[6].isNotBlank()) {
                parseWholeNumber(values[6], "recommended stock", index + 2)
            } else {
                10
            }

            InventoryItem(
                barcode = normalizeBarcode(values[0]),
                name = values[1].trim(),
                purchaseCost = parseDecimal(values[2], "purchase cost", index + 2),
                sellingPrice = parseDecimal(values[3], "selling price", index + 2),
                stockQuantity = parseWholeNumber(values[4], "stock quantity", index + 2),
                lowStockLimit = parseWholeNumber(values[5], "low-stock limit", index + 2),
                recommendedStock = recStock,
                addedAt = LocalDateTime.now()
            ).also {
                require(it.barcode.isNotBlank() && it.name.isNotBlank()) { "Barcode and name are required on row ${index + 2}" }
                require(it.purchaseCost >= 0 && it.sellingPrice >= 0 && it.stockQuantity >= 0 && it.lowStockLimit >= 0 && it.recommendedStock >= 0) {
                    "Negative values are not allowed on row ${index + 2}"
                }
            }
        }
    }

    private fun parseSharedStrings(xml: String): List<String> =
        Regex("<si\\b[^>]*>(.*?)</si>", RegexOption.DOT_MATCHES_ALL)
            .findAll(xml)
            .map { si ->
                Regex("<t\\b[^>]*>(.*?)</t>", RegexOption.DOT_MATCHES_ALL)
                    .findAll(si.groupValues[1])
                    .joinToString("") { decodeXml(it.groupValues[1]) }
            }
            .toList()

    private fun attribute(tag: String, name: String): String? =
        Regex("""\b${Regex.escape(name)}\s*=\s*["']([^"']*)["']""")
            .find(tag)?.groupValues?.get(1)

    private fun decodeXml(value: String): String =
        Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString()

    private fun parseDecimal(value: String, field: String, row: Int): Double =
        value.trim().replace(",", "").toDoubleOrNull()
            ?: error("Invalid $field on row $row: '$value'")

    private fun parseWholeNumber(value: String, field: String, row: Int): Int {
        val normalized = value.trim().replace(",", "")
        val number = normalized.toDoubleOrNull()
            ?: error("Invalid $field on row $row: '$value'")
        require(number % 1.0 == 0.0 && number in Int.MIN_VALUE.toDouble()..Int.MAX_VALUE.toDouble()) {
            "Invalid $field on row $row: '$value' (must be a whole number)"
        }
        return number.toInt()
    }

    private fun normalizeBarcode(value: String): String {
        val barcode = value.trim()
        return Regex("""^([+-]?\d+)\.0+$""").matchEntire(barcode)
            ?.groupValues
            ?.get(1)
            ?: barcode
    }

    private fun cell(column: Int, row: Int, value: String): String {
        val reference = "${('A'.code + column - 1).toChar()}$row"
        return "<c r=\"$reference\" t=\"inlineStr\"><is><t>${escape(value)}</t></is></c>"
    }

    private fun escape(value: String) = value
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;")

    private fun entry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray())
        zip.closeEntry()
    }
}
