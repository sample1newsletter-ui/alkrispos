package ph.alkris.pos.ui.screens

import ph.alkris.pos.ui.dialogs.AddCustomerProfileDialog
import android.content.res.Configuration
import android.widget.Toast
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.ui.graphics.luminance
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.ui.PdfExporter
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.ReceiptImageExporter
import ph.alkris.pos.ui.components.Blue
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Green
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.ui.components.Pink
import ph.alkris.pos.ui.components.ScrollbarLazyColumn
import ph.alkris.pos.ui.components.SkyBlue
import ph.alkris.pos.ui.dialogs.UtangDialog
import ph.alkris.pos.ui.printDebtPayment
import ph.alkris.pos.ui.printItemizedReport
import ph.alkris.pos.ui.printReceivablesReport
import java.time.LocalDate
import java.time.LocalDateTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UtangLedgerScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier,
    onSelectDebtor: (Debtor) -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var selectedDebtor by remember { mutableStateOf<Debtor?>(null) }
    var editingDebtor by remember { mutableStateOf<Debtor?>(null) }
    var sortMode by remember { mutableIntStateOf(0) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var showSettled by remember { mutableStateOf(false) }
    var activePdfDebtor by remember { mutableStateOf<Debtor?>(null) }

    val exportSingleDebtorPdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            val debtorToExport = activePdfDebtor
            if (debtorToExport != null) {
                context.contentResolver.openOutputStream(it)?.use { stream ->
                    val sales = state.cashHistorySales.filter { s -> s.paymentType == "CREDIT" && s.customerContact == debtorToExport.contact }
                    val debtPayments = state.cashHistoryDebtPayments.filter { p -> p.contact == debtorToExport.contact }
                    PdfExporter.exportDebtorUnpaidItems(stream, state.storeName, debtorToExport, sales, debtPayments)
                    Toast.makeText(context, "Debtor statement PDF exported", Toast.LENGTH_SHORT).show()
                }
                viewModel.logActivity("PRINT", "Saved/Exported debtor statement PDF for ${debtorToExport.name}")
            }
        }
    }

    fun handlePrintDebtorItems(debtor: Debtor) {
        viewModel.loadDebtors()
        viewModel.loadDebtPayments()
        val sales = state.cashHistorySales.filter { s -> s.paymentType == "CREDIT" && s.customerContact == debtor.contact }
        printItemizedReport(context, LocalDate.of(2000, 1, 1), LocalDate.now(), sales, state.storeName, "UTANG ITEMS - ${debtor.name}", viewModel)
    }

    fun handleSaveDebtorPdf(debtor: Debtor) {
        activePdfDebtor = debtor
        exportSingleDebtorPdfLauncher.launch("Utang_Statement_${debtor.name.replace(" ", "_")}.pdf")
    }

    fun handleSaveDebtorPng(debtor: Debtor) {
        viewModel.loadDebtors()
        viewModel.loadDebtPayments()
        val sales = state.cashHistorySales.filter { s -> s.paymentType == "CREDIT" && s.customerContact == debtor.contact }
        val debtPayments = state.cashHistoryDebtPayments.filter { p -> p.contact == debtor.contact }
        ReceiptImageExporter.saveDebtorStatementToGallery(context, debtor, sales, debtPayments, state.storeName)
    }

    LaunchedEffect(Unit) {
        viewModel.loadDebtors()
    }

    val debtors = state.debtors
    val filteredDebtors = remember(debtors, searchQuery, sortMode, showSettled) {
        debtors
            .filter { showSettled || it.totalOwed > 0.0 }
            .filter {
                val q = searchQuery.trim()
                q.isEmpty() || it.name.contains(q, ignoreCase = true) || it.contact.contains(q, ignoreCase = true)
            }
            .let { list ->
                if (sortMode == 0) list.sortedBy { it.name.lowercase() }
                else list.sortedByDescending { it.totalOwed }
            }
    }

    val totalReceivables = debtors.sumOf { it.totalOwed }
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val searchBarContent = @Composable { modifier: Modifier ->
        Surface(
            modifier = modifier.height(38.dp),
            shape = ControlShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = "Search customer...",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (searchQuery.isNotEmpty()) {
                    IconButton(
                        onClick = { searchQuery = "" },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear search",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }

    val addCustomerButtonContent = @Composable {
        Button(
            onClick = { showAddCustomerDialog = true },
            shape = ControlShape,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
            modifier = Modifier.height(38.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Customer")
            Spacer(Modifier.width(4.dp))
            Text("Add Customer", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }

    val exportAllDebtorsPdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                PdfExporter.exportReceivablesReport(stream, state.storeName, LocalDate.of(2000, 1, 1), LocalDate.now(), debtors)
                Toast.makeText(context, "Receivables PDF exported", Toast.LENGTH_SHORT).show()
            }
            viewModel.logActivity("PRINT", "Saved/Exported receivables PDF report")
        }
    }

    val controlsRowContent = @Composable {
        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box {
                    OutlinedButton(
                        onClick = { sortMenuExpanded = true },
                        shape = ControlShape,
                        modifier = Modifier.height(34.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Sort,
                            contentDescription = "Sort debtors",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (sortMode == 0) "Sort: A-Z" else "Sort: Highest Utang",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    DropdownMenu(
                        expanded = sortMenuExpanded,
                        onDismissRequest = { sortMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Name A-Z") },
                            onClick = { sortMode = 0; sortMenuExpanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Highest Utang Amount") },
                            onClick = { sortMode = 1; sortMenuExpanded = false }
                        )
                    }
                }

                TextButton(
                    onClick = { showSettled = !showSettled },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text(
                        text = if (showSettled) "Hide Paid" else "Show Paid",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (showSettled) Pink else (if (isDark) SkyBlue else MaterialTheme.colorScheme.primary)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = {
                        exportAllDebtorsPdfLauncher.launch("Receivables_Report_${LocalDate.now()}.pdf")
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        Icons.Default.PictureAsPdf,
                        contentDescription = "Save PDF",
                        tint = if (isDark) SkyBlue else Blue,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = {
                        printReceivablesReport(context, LocalDate.of(2000, 1, 1), LocalDate.now(), debtors, state.storeName, viewModel)
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        Icons.Default.Print,
                        contentDescription = "Print Utang list",
                        tint = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = if (isLandscape) 4.dp else 16.dp),
        verticalArrangement = Arrangement.spacedBy(if (isLandscape) 8.dp else 16.dp)
    ) {
        // TOTAL STORE RECEIVABLES CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier.padding(if (isLandscape) 10.dp else 16.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f, fill = false)) {
                        Text("Total Store Receivables", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text(
                            Peso.format(totalReceivables),
                            fontSize = if (isLandscape) 20.sp else 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Pink
                        )
                    }

                    if (isLandscape) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(2f, fill = false)
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primary,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    "${debtors.size} Customers",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            searchBarContent(Modifier.widthIn(max = 240.dp))
                            addCustomerButtonContent()
                        }
                    } else {
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                "${debtors.size} Customers",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        if (!isLandscape) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                searchBarContent(Modifier.weight(1f))
                addCustomerButtonContent()
            }
        }

        controlsRowContent()

        // CUSTOMER CARDS LIST (3 COLUMNS IN LANDSCAPE, 1 COLUMN IN PORTRAIT)
        if (filteredDebtors.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("No customers found.", color = Color.Gray)
            }
        } else if (isLandscape) {
            val chunkedDebtors = remember(filteredDebtors) { filteredDebtors.chunked(3) }
            ScrollbarLazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                items(chunkedDebtors.size) { rowIndex ->
                    val rowItems = chunkedDebtors[rowIndex]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { debtor ->
                            DebtorCard(
                                debtor = debtor,
                                onClick = {
                                    selectedDebtor = debtor
                                    onSelectDebtor(debtor)
                                },
                                onPrintItems = { handlePrintDebtorItems(debtor) },
                                onSavePdf = { handleSaveDebtorPdf(debtor) },
                                onSavePng = { handleSaveDebtorPng(debtor) },
                                onEditCustomer = { editingDebtor = debtor },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(3 - rowItems.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            ScrollbarLazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                items(filteredDebtors, key = { it.contact }) { debtor ->
                    DebtorCard(
                        debtor = debtor,
                        onClick = {
                            selectedDebtor = debtor
                            onSelectDebtor(debtor)
                        },
                        onPrintItems = { handlePrintDebtorItems(debtor) },
                        onSavePdf = { handleSaveDebtorPdf(debtor) },
                        onSavePng = { handleSaveDebtorPng(debtor) },
                        onEditCustomer = { editingDebtor = debtor },
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }
    }

    selectedDebtor?.let { debtor ->
        val exportDebtorPdfLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/pdf")
        ) { uri ->
            uri?.let {
                context.contentResolver.openOutputStream(it)?.use { stream ->
                    val sales = state.cashHistorySales.filter { s -> s.paymentType == "CREDIT" && s.customerContact == debtor.contact }
                    val debtPayments = state.cashHistoryDebtPayments.filter { p -> p.contact == debtor.contact }
                    PdfExporter.exportDebtorUnpaidItems(stream, state.storeName, debtor, sales, debtPayments)
                    Toast.makeText(context, "Debtor statement PDF exported", Toast.LENGTH_SHORT).show()
                }
                viewModel.logActivity("PRINT", "Saved/Exported debtor statement PDF for ${debtor.name}")
            }
        }

        val exportAllDebtorsPdfLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/pdf")
        ) { uri ->
            uri?.let {
                context.contentResolver.openOutputStream(it)?.use { stream ->
                    PdfExporter.exportReceivablesReport(stream, state.storeName, LocalDate.of(2000, 1, 1), LocalDate.now(), debtors)
                    Toast.makeText(context, "Receivables PDF exported", Toast.LENGTH_SHORT).show()
                }
                viewModel.logActivity("PRINT", "Saved/Exported receivables PDF report")
            }
        }

        UtangDialog(
            debtors = debtors,
            debtPayments = state.debtPayments,
            initialDebtor = debtor,
            onPay = { d, amt, cash ->
                viewModel.recordDebtPayment(d, amt, cash)
                viewModel.loadDebtors()
                viewModel.loadDebtPayments()
                Toast.makeText(context, "Payment recorded for ${d.name}", Toast.LENGTH_SHORT).show()
            },
            onPrintItems = { d ->
                viewModel.loadDebtors()
                viewModel.loadDebtPayments()
                val sales = state.cashHistorySales.filter { s -> s.paymentType == "CREDIT" && s.customerContact == d.contact }
                printItemizedReport(context, LocalDate.of(2000, 1, 1), LocalDate.now(), sales, state.storeName, "UTANG ITEMS - ${d.name}", viewModel)
            },
            onPrintPayment = { payment ->
                printDebtPayment(context, payment, state.storeName, viewModel)
            },
            onSavePdf = {
                exportAllDebtorsPdfLauncher.launch("Receivables_Report_${LocalDate.now()}.pdf")
            },
            onPrint = {
                printReceivablesReport(context, LocalDate.of(2000, 1, 1), LocalDate.now(), debtors, state.storeName, viewModel)
            },
            onSaveDebtorPdf = { d ->
                exportDebtorPdfLauncher.launch("Utang_Statement_${d.name.replace(" ", "_")}.pdf")
            },
            onDismiss = { selectedDebtor = null }
        )
    }

    if (showAddCustomerDialog) {
        AddCustomerProfileDialog(
            viewModel = viewModel,
            initialDebtor = null,
            onDismiss = { showAddCustomerDialog = false }
        )
    }

    if (editingDebtor != null) {
        AddCustomerProfileDialog(
            viewModel = viewModel,
            initialDebtor = editingDebtor,
            onDismiss = { editingDebtor = null }
        )
    }
}

@Composable
private fun DebtorCard(
    debtor: Debtor,
    onClick: () -> Unit,
    onPrintItems: () -> Unit,
    onSavePdf: () -> Unit,
    onSavePng: () -> Unit,
    onEditCustomer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 4.dp)) {
                Text(
                    text = debtor.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    lineHeight = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = debtor.contact,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )

                Spacer(Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(
                        onClick = onPrintItems,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Print,
                            contentDescription = "Print items for ${debtor.name}",
                            tint = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onSavePdf,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.PictureAsPdf,
                            contentDescription = "Save PDF for ${debtor.name}",
                            tint = if (isDark) SkyBlue else Blue,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onSavePng,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Image,
                            contentDescription = "Save PNG for ${debtor.name}",
                            tint = Green,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onEditCustomer,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Customer Profile",
                            tint = if (isDark) Color.White else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("Owed Amount", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text(
                        text = Peso.format(debtor.totalOwed),
                        color = Pink,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
            }
        }
    }
}
