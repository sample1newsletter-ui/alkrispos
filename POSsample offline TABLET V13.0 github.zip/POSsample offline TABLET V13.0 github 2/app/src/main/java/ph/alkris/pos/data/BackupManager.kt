package ph.alkris.pos.data

import android.accounts.Account
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class BackupManager(private val context: Context) {
    private val scopeDriveFile = "https://www.googleapis.com/auth/drive.file"

    private val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .build()

    fun getSignInIntent(): Intent {
        return GoogleSignIn.getClient(context, gso).signInIntent
    }

    fun isSignedIn(): Boolean {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return account != null && !account.email.isNullOrBlank()
    }

    fun getSignedInEmail(): String? {
        return GoogleSignIn.getLastSignedInAccount(context)?.email
    }

    fun signOut(onComplete: () -> Unit = {}) {
        GoogleSignIn.getClient(context, gso).signOut().addOnCompleteListener {
            onComplete()
        }
    }

    suspend fun getAccessToken(): String = withContext(Dispatchers.IO) {
        val account = GoogleSignIn.getLastSignedInAccount(context)
            ?: throw Exception("No Google account found. Please sign in.")
        val scopes = "oauth2:$scopeDriveFile"
        val accountToUse = account.account ?: if (!account.email.isNullOrBlank()) Account(account.email!!, "com.google") else null
        if (accountToUse == null) {
            throw Exception("No valid account or email found in GoogleSignInAccount (${account.email})")
        }

        try {
            GoogleAuthUtil.getToken(context, accountToUse, scopes)
        } catch (recoverable: UserRecoverableAuthException) {
            Log.w("BackupManager", "Permission consent needs resolution intent interaction trigger", recoverable)
            throw recoverable
        } catch (e: Exception) {
            Log.e("BackupManager", "Error getting OAuth token", e)
            throw Exception("Failed to get Google token: ${e.localizedMessage ?: e.message}")
        }
    }

    suspend fun backupDatabase(storeName: String = "ALKRIS POS", mode: AppMode): Result<Unit> = withContext(Dispatchers.IO) {
        val dbFileName = if (mode == AppMode.ECASH) "pos_ecash.db" else "pos_mart.db"
        val dbFile = context.getDatabasePath(dbFileName)
        if (!dbFile.exists()) return@withContext Result.failure(Exception("Database file not found"))

        try {
            val token = getAccessToken()
            val dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
            val sanitizedStoreName = storeName.trim().ifBlank { "ALKRIS POS" }
            val modeLabel = if (mode == AppMode.ECASH) "Ecash" else "Mart"
            val baseName = "${modeLabel}_${sanitizedStoreName}_backup_${dateStr}"

            val query = URLEncoder.encode("name contains '$baseName' and trashed=false", "UTF-8")
            val searchUrl = URL("https://www.googleapis.com/drive/v3/files?q=$query")
            val searchConn = (searchUrl.openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 7000
                requestMethod = "GET"
                setRequestProperty("Authorization", "Bearer $token")
            }
            
            val responseCode = searchConn.responseCode
            val responseText = if (responseCode == HttpURLConnection.HTTP_OK) {
                searchConn.inputStream.bufferedReader().use { it.readText() }
            } else {
                searchConn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            }
            searchConn.disconnect()

            if (responseCode != HttpURLConnection.HTTP_OK) {
                return@withContext Result.failure(Exception("Drive search failed ($responseCode): $responseText"))
            }

            val existingNames = """"name":\s*"([^"]+)"""".toRegex()
                .findAll(responseText)
                .map { it.groupValues[1] }
                .toSet()

            var targetFileName = "$baseName.db"
            if (existingNames.contains(targetFileName)) {
                var counter = 1
                while (existingNames.contains("$baseName-$counter.db")) {
                    counter++
                }
                targetFileName = "$baseName-$counter.db"
            }

            val createUrl = URL("https://www.googleapis.com/drive/v3/files")
            val createConn = (createUrl.openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 7000
                requestMethod = "POST"
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
            }
            
            val jsonMeta = """{"name": "$targetFileName"}"""
            createConn.outputStream.use { it.write(jsonMeta.toByteArray()) }

            val createCode = createConn.responseCode
            val createResponse = if (createCode == HttpURLConnection.HTTP_OK || createCode == 201) {
                createConn.inputStream.bufferedReader().use { it.readText() }
            } else {
                createConn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            }
            createConn.disconnect()

            if (createCode != HttpURLConnection.HTTP_OK && createCode != 201) {
                return@withContext Result.failure(Exception("Drive file creation failed ($createCode): $createResponse"))
            }

            val finalFileId = """"id":\s*"([^"]+)"""".toRegex().find(createResponse)?.groupValues?.getOrNull(1)
                ?: return@withContext Result.failure(Exception("Failed to parse newly created file ID"))

            val uploadUrl = URL("https://www.googleapis.com/upload/drive/v3/files/$finalFileId?uploadType=media&method=PATCH")
            val uploadConn = (uploadUrl.openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 7000
                requestMethod = "POST"
                setRequestProperty("X-HTTP-Method-Override", "PATCH")
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "application/x-sqlite3")
                doOutput = true
            }

            dbFile.inputStream().use { input ->
                uploadConn.outputStream.use { output ->
                    input.copyTo(output)
                }
            }

            val uploadCode = uploadConn.responseCode
            val uploadResponse = if (uploadCode == HttpURLConnection.HTTP_OK || uploadCode == 201) {
                uploadConn.inputStream.bufferedReader().use { it.readText() }
            } else {
                uploadConn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            }
            uploadConn.disconnect()

            if (uploadCode == HttpURLConnection.HTTP_OK || uploadCode == 201) {
                AutoBackupScheduler.markBackupCompleted(context)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Drive upload failed ($uploadCode): $uploadResponse"))
            }
        } catch (recoverable: UserRecoverableAuthException) {
            Result.failure(recoverable)
        } catch (e: Exception) {
            Log.e("BackupManager", "Backup exception", e)
            Result.failure(e)
        }
    }
}
