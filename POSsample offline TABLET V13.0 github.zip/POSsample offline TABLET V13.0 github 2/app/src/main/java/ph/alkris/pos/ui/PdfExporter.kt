package ph.alkris.pos.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.content.Context
import android.content.ContentValues
import android.graphics.Color
import android.graphics.RectF
import android.provider.MediaStore
import android.os.Environment
import android.os.Build
import android.util.Log
import ph.alkris.pos.R
import java.io.File
import java.io.FileOutputStream
import ph.alkris.pos.data.InventoryItem
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.DebtPayment
import ph.alkris.pos.data.ActivityLog
import ph.alkris.pos.data.EcashAdjustment
import ph.alkris.pos.data.formattedReceiptCode
import java.io.OutputStream
import java.text.NumberFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object PdfExporter {
    private val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))

    private sealed class DebtorLedgerEntry(val timestamp: LocalDateTime) {
        data class CreditSale(val sale: Sale) : DebtorLedgerEntry(sale.purchasedAt)
        data class UtangPayment(val payment: DebtPayment) : DebtorLedgerEntry(payment.paidAt)
    }

    fun exportInventory(
        outputStream: OutputStream,
        storeName: String,
        date: LocalDate,
        items: List<InventoryItem>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 at 72dpi
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        val paint = Paint()
        
        var y = 50f
        
        // Header
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 18f
        canvas.drawText(storeName, 50f, y, paint)
        y += 25f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 14f
        canvas.drawText("INVENTORY REPORT", 50f, y, paint)
        y += 20f
        canvas.drawText("As of: ${date.format(DateTimeFormatter.ISO_LOCAL_DATE)}", 50f, y, paint)
        y += 40f
        
        // Table Headers
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Item Name", 50f, y, paint)
        canvas.drawText("Barcode", 250f, y, paint)
        canvas.drawText("Stock", 400f, y, paint)
        canvas.drawText("Price", 480f, y, paint)
        y += 10f
        canvas.drawLine(50f, y, 545f, y, paint)
        y += 20f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        items.forEach { item ->
            if (y > 780f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 50f
            }
            canvas.drawText(item.name.take(25), 50f, y, paint)
            canvas.drawText(item.barcode, 250f, y, paint)
            val stockStr = "${item.displayStock}${if (item.isKg) " kg" else if (item.isGrams) " grm" else ""}"
            canvas.drawText(stockStr, 400f, y, paint)
            canvas.drawText(peso.format(item.sellingPrice), 480f, y, paint)
            y += 20f
        }
        
        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportSalesReport(
        outputStream: OutputStream,
        storeName: String,
        start: LocalDate,
        end: LocalDate,
        sales: List<Sale>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        val paint = Paint()
        
        var y = 50f
        
        // Header
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 18f
        canvas.drawText(storeName, 50f, y, paint)
        y += 25f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 14f
        canvas.drawText("SALES REPORT", 50f, y, paint)
        y += 20f
        val dateRange = if (start == end) start.toString() else "$start to $end"
        canvas.drawText("Period: $dateRange", 50f, y, paint)
        y += 40f
        
        // Summary
        val totalSales = sales.sumOf { it.total }
        val totalProfit = sales.sumOf { it.profit }
        val totalItems = sales.sumOf { it.itemCount }
        
        canvas.drawText("Total Sales: ${peso.format(totalSales)}", 50f, y, paint)
        y += 20f
        canvas.drawText("Total Profit: ${peso.format(totalProfit)}", 50f, y, paint)
        y += 20f
        canvas.drawText("Total Items Sold: $totalItems", 50f, y, paint)
        y += 40f
        
        // Table Headers
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Date", 50f, y, paint)
        canvas.drawText("Items", 200f, y, paint)
        canvas.drawText("Total", 480f, y, paint)
        y += 10f
        canvas.drawLine(50f, y, 545f, y, paint)
        y += 20f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        sales.forEach { sale ->
            if (y > 780f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 50f
            }

            canvas.drawText(sale.purchasedAt.format(DateTimeFormatter.ofPattern("MMM dd HH:mm")), 50f, y, paint)
            canvas.drawText("${sale.itemCount} items", 200f, y, paint)
            canvas.drawText(peso.format(sale.total), 480f, y, paint)
            y += 20f
        }
        
        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportReceivablesReport(
        outputStream: OutputStream,
        storeName: String,
        start: LocalDate,
        end: LocalDate,
        debtors: List<Debtor>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        var y = 50f
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 18f
        canvas.drawText(storeName, 50f, y, paint)
        y += 25f
        paint.textSize = 14f
        canvas.drawText("RECEIVABLES REPORT", 50f, y, paint)
        y += 20f
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 11f
        canvas.drawText("As of ${LocalDate.now()}", 50f, y, paint)
        y += 35f
        paint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("Debtor", 50f, y, paint)
        canvas.drawText("Contact", 250f, y, paint)
        canvas.drawText("Last Date", 390f, y, paint)
        canvas.drawText("Amount", 490f, y, paint)
        y += 10f
        canvas.drawLine(50f, y, 545f, y, paint)
        y += 20f
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 10f
        debtors.forEach { debtor ->
            canvas.drawText(debtor.name.take(24), 50f, y, paint)
            canvas.drawText(debtor.contact.take(18), 250f, y, paint)
            canvas.drawText(debtor.lastTransactionAt.toLocalDate().toString(), 390f, y, paint)
            canvas.drawText(peso.format(debtor.totalOwed), 490f, y, paint)
            y += 20f
        }
        paint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText("TOTAL RECEIVABLES: ${peso.format(debtors.sumOf { it.totalOwed })}", 50f, y + 20f, paint)
        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportSalesHistory(
        outputStream: OutputStream,
        storeName: String,
        start: LocalDate,
        end: LocalDate,
        sales: List<Sale>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.DEFAULT
            textSize = 10f
        }
        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        var pageNumber = 0
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        var y = 50f

        fun drawHeader() {
            paint.typeface = bold
            paint.textSize = 18f
            canvas.drawText(storeName, 50f, y, paint)
            y += 24f
            paint.textSize = 14f
            canvas.drawText("SALES HISTORY", 50f, y, paint)
            y += 19f
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
            val range = if (start == end) start.toString() else "$start to $end"
            canvas.drawText("Period: $range", 50f, y, paint)
            y += 25f
        }

        fun newPage() {
            document.finishPage(page)
            pageNumber++
            page = document.startPage(pageInfo)
            canvas = page.canvas
            y = 50f
            drawHeader()
        }

        fun ensureSpace(height: Float) {
            if (y + height > 790f) newPage()
        }

        drawHeader()
        paint.textSize = 10f
        sales.sortedBy { it.purchasedAt }.forEachIndexed { index, sale ->
            ensureSpace(55f)
            paint.typeface = bold
            val displayType = if (sale.paymentType == "CREDIT") "Utang Sales" else "Cash Sales"
            val initials = storeName.split(" ").mapNotNull { it.firstOrNull() }.joinToString("").uppercase()
            val timestamp = sale.purchasedAt.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
            val refText = "Ref: $initials-S-$timestamp"
            canvas.drawText(
                "${index + 1}. ${sale.purchasedAt.format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm"))} [$displayType]",
                50f, y, paint
            )
            canvas.drawText(refText, 230f, y, paint)
            canvas.drawText("${sale.itemCount} items", 410f, y, paint)
            canvas.drawText("Total: ${peso.format(sale.total)}", 480f, y, paint)
            y += 16f
            paint.typeface = Typeface.DEFAULT
            sale.lines.forEach { line ->
                ensureSpace(16f)
                canvas.drawText("${line.itemName} x${line.quantity}", 70f, y, paint)
                canvas.drawText("Subtotal: ${peso.format(line.subtotal)}", 370f, y, paint)
                y += 15f
            }
            val subtotal = sale.lines.sumOf { it.subtotal }
            ensureSpace(30f)
            canvas.drawText("Transaction subtotal: ${peso.format(subtotal)}", 300f, y, paint)
            y += 22f
            canvas.drawLine(50f, y, 545f, y, paint)
            y += 15f
        }

        ensureSpace(55f)
        paint.typeface = bold
        paint.textSize = 13f
        canvas.drawText("OVERALL TOTAL: ${peso.format(sales.sumOf { it.total })}", 50f, y, paint)
        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportActivityLogs(
        outputStream: OutputStream,
        storeName: String,
        start: LocalDate,
        end: LocalDate,
        logs: List<ActivityLog>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.DEFAULT
            textSize = 10f
        }
        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        var y = 50f

        paint.typeface = bold
        paint.textSize = 18f
        canvas.drawText(storeName, 50f, y, paint)
        y += 24f
        paint.textSize = 14f
        canvas.drawText("APP ACTIVITY LOGS", 50f, y, paint)
        y += 19f
        paint.typeface = Typeface.DEFAULT
        paint.textSize = 10f
        canvas.drawText("Period: ${start.format(DateTimeFormatter.ISO_LOCAL_DATE)} to ${end.format(DateTimeFormatter.ISO_LOCAL_DATE)}", 50f, y, paint)
        y += 28f

        paint.typeface = bold
        canvas.drawText("Date & Time", 50f, y, paint)
        canvas.drawText("Action", 180f, y, paint)
        canvas.drawText("Details", 310f, y, paint)
        y += 16f
        canvas.drawLine(50f, y, 545f, y, paint)
        y += 18f

        paint.typeface = Typeface.DEFAULT
        paint.textSize = 10f
        val dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

        logs.forEach { log ->
            if (y > 780f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 50f
            }
            canvas.drawText(log.timestamp.format(dtf), 50f, y, paint)
            canvas.drawText(log.action.take(20), 180f, y, paint)
            val detailsText = if (log.details.length > 40) log.details.take(40) + "..." else log.details
            canvas.drawText(detailsText, 310f, y, paint)
            y += 18f
        }

        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportDiscountsReport(
        outputStream: OutputStream,
        storeName: String,
        start: LocalDate,
        end: LocalDate,
        sales: List<Sale>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.DEFAULT
            textSize = 10f
        }
        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        var y = 50f

        val discountedSales = sales.filter { it.discount > 0.0 }.sortedBy { it.purchasedAt }
        val totalDiscounts = discountedSales.sumOf { it.discount }

        fun drawHeader() {
            paint.typeface = bold
            paint.textSize = 18f
            canvas.drawText(storeName, 50f, y, paint)
            y += 24f
            paint.textSize = 14f
            canvas.drawText("DISCOUNTS REPORT", 50f, y, paint)
            y += 19f
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
            val range = if (start == end) start.toString() else "$start to $end"
            canvas.drawText("Period: $range", 50f, y, paint)
            y += 25f

            paint.typeface = bold
            canvas.drawText("Receipt Code", 50f, y, paint)
            canvas.drawText("Date & Time", 200f, y, paint)
            canvas.drawText("Original", 340f, y, paint)
            canvas.drawText("Discount", 420f, y, paint)
            canvas.drawText("Net Total", 490f, y, paint)
            y += 10f
            canvas.drawLine(50f, y, 545f, y, paint)
            y += 18f
            paint.typeface = Typeface.DEFAULT
        }

        fun ensureSpace(height: Float) {
            if (y + height > 790f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 50f
                drawHeader()
            }
        }

        drawHeader()

        if (discountedSales.isEmpty()) {
            paint.textSize = 10f
            canvas.drawText("No transactions with discounts given for selected dates.", 50f, y, paint)
        } else {
            paint.textSize = 10f
            discountedSales.forEach { sale ->
                ensureSpace(20f)
                val originalTotal = sale.total + sale.discount
                val receiptCode = sale.formattedReceiptCode(storeName)
                val dateStr = sale.purchasedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))

                canvas.drawText(receiptCode, 50f, y, paint)
                canvas.drawText(dateStr, 200f, y, paint)
                canvas.drawText(peso.format(originalTotal), 340f, y, paint)
                canvas.drawText(peso.format(sale.discount), 420f, y, paint)
                canvas.drawText(peso.format(sale.total), 490f, y, paint)
                y += 18f
            }

            ensureSpace(40f)
            y += 10f
            canvas.drawLine(50f, y, 545f, y, paint)
            y += 18f
            paint.typeface = bold
            canvas.drawText("Total Discounted Transactions: ${discountedSales.size}", 50f, y, paint)
            canvas.drawText("Total Discounts Given: ${peso.format(totalDiscounts)}", 340f, y, paint)
        }

        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportEcashReport(
        outputStream: OutputStream,
        storeName: String,
        start: LocalDate,
        end: LocalDate,
        serviceStats: Map<String, Triple<Double, Double, Int>>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()
        
        var y = 50f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 18f
        canvas.drawText(storeName, 50f, y, paint)
        y += 25f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 14f
        canvas.drawText("ECASH SERVICES REPORT", 50f, y, paint)
        y += 20f
        val dateRange = if (start == end) start.toString() else "$start to $end"
        canvas.drawText("Period: $dateRange", 50f, y, paint)
        y += 40f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Service Type", 50f, y, paint)
        canvas.drawText("Volume Processed", 250f, y, paint)
        canvas.drawText("Service Fees (Profit)", 400f, y, paint)
        y += 10f
        canvas.drawLine(50f, y, 545f, y, paint)
        y += 25f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        var totalVol = 0.0
        var totalProf = 0.0
        serviceStats.entries.forEach { (service, stats) ->
            val (vol, prof, count) = stats
            val volStr = if (service == "Printing") "$count txns" else peso.format(vol)
            if (service != "Printing") totalVol += vol
            totalProf += prof
            canvas.drawText(service, 50f, y, paint)
            canvas.drawText(volStr, 250f, y, paint)
            canvas.drawText(peso.format(prof), 400f, y, paint)
            y += 25f
        }
        
        y += 10f
        canvas.drawLine(50f, y, 545f, y, paint)
        y += 25f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("TOTAL MONEY VOLUME", 50f, y, paint)
        canvas.drawText(peso.format(totalVol), 250f, y, paint)
        canvas.drawText(peso.format(totalProf), 400f, y, paint)
        
        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportWalletsHistoryReport(
        outputStream: OutputStream,
        storeName: String,
        start: LocalDate,
        end: LocalDate,
        adjustments: List<EcashAdjustment>
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()
        
        var y = 50f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 18f
        canvas.drawText(storeName, 50f, y, paint)
        y += 25f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 14f
        canvas.drawText("WALLETS HISTORY & ADJUSTMENTS", 50f, y, paint)
        y += 20f
        val dateRange = if (start == end) start.toString() else "$start to $end"
        canvas.drawText("Period: $dateRange", 50f, y, paint)
        y += 40f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Date & Time", 50f, y, paint)
        canvas.drawText("Wallet & Type", 200f, y, paint)
        canvas.drawText("Amount", 360f, y, paint)
        canvas.drawText("Note", 450f, y, paint)
        y += 10f
        canvas.drawLine(50f, y, 545f, y, paint)
        y += 25f
        
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        adjustments.forEach { adj ->
            canvas.drawText(adj.adjustedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")), 50f, y, paint)
            canvas.drawText("${adj.wallet} (${adj.type})", 200f, y, paint)
            canvas.drawText(peso.format(adj.amount), 360f, y, paint)
            canvas.drawText(adj.note.take(20), 450f, y, paint)
            y += 25f
        }
        
        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportDebtorUnpaidItems(
        outputStream: OutputStream,
        storeName: String,
        debtor: Debtor,
        sales: List<Sale>,
        payments: List<DebtPayment>,
        startDate: LocalDate = LocalDate.of(2026, 1, 1),
        endDate: LocalDate = LocalDate.now()
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        val paint = Paint()

        val leftMargin = 40f
        val rightMargin = 555f
        val dateColX = 290f
        val maxDescWidth = 235f

        fun drawLeftText(text: String, x: Float, y: Float, maxWidth: Float) {
            var displayText = text
            if (paint.measureText(displayText) > maxWidth) {
                while (displayText.length > 3 && paint.measureText("$displayText...") > maxWidth) {
                    displayText = displayText.dropLast(1)
                }
                displayText = "$displayText..."
            }
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText(displayText, x, y, paint)
        }

        fun drawRightText(text: String, x: Float, y: Float) {
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText(text, x, y, paint)
            paint.textAlign = Paint.Align.LEFT
        }

        var y = 40f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 16f
        canvas.drawText("DEBTOR UTANG STATEMENT (LEDGER)", leftMargin, y, paint)

        paint.textSize = 12f
        drawRightText(storeName, rightMargin, y)
        y += 22f

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        drawLeftText("Customer: ${debtor.name}", leftMargin, y, 235f)
        canvas.drawText("Period: $startDate to $endDate", dateColX, y, paint)
        y += 15f

        val contactStr = if (debtor.contact.isNotBlank()) "Contact: ${debtor.contact}" else "Contact: N/A"
        drawLeftText(contactStr, leftMargin, y, 235f)
        canvas.drawText("Report Date: ${LocalDate.now()}", dateColX, y, paint)
        y += 25f

        fun drawTableHeader() {
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 10f
            canvas.drawText("Description / Ref", leftMargin, y, paint)
            canvas.drawText("Date & Time", dateColX, y, paint)
            drawRightText("Amount / Balance", rightMargin, y)
            y += 6f
            canvas.drawLine(leftMargin, y, rightMargin, y, paint)
            y += 16f
        }

        drawTableHeader()

        // Partition prior items vs items in selected date range
        val priorSales = sales.filter { it.purchasedAt.toLocalDate() < startDate }
        val priorPayments = payments.filter { it.paidAt.toLocalDate() < startDate }

        val filteredSales = sales.filter { it.purchasedAt.toLocalDate() in startDate..endDate }
        val filteredPayments = payments.filter { it.paidAt.toLocalDate() in startDate..endDate }

        val priorSalesNetDebt = priorSales.sumOf { sale ->
            val down = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
            (sale.total - down).coerceAtLeast(0.0)
        }
        val priorPaymentsTotal = priorPayments.sumOf { it.amount }
        val initialBalance = (priorSalesNetDebt - priorPaymentsTotal).coerceAtLeast(0.0)

        val timeline: List<DebtorLedgerEntry> = (
            filteredSales.map { DebtorLedgerEntry.CreditSale(it) } +
            filteredPayments.map { DebtorLedgerEntry.UtangPayment(it) }
        ).sortedBy { it.timestamp }

        fun ensureSpace(height: Float) {
            if (y + height > 780f) {
                document.finishPage(page)
                page = document.startPage(pageInfo)
                canvas = page.canvas
                y = 40f
                drawTableHeader()
            }
        }

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f

        var runningBalance = initialBalance
        var totalSalesAmt = 0.0
        var totalCheckoutPartialPayments = 0.0
        var totalUtangPaymentsMade = 0.0

        if (initialBalance > 0.0) {
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            drawLeftText("Balance Forwarded (before $startDate)", leftMargin, y, maxDescWidth + 40f)
            drawRightText(peso.format(initialBalance), rightMargin, y)
            y += 18f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        if (timeline.isEmpty() && initialBalance == 0.0) {
            canvas.drawText("No credit transactions or payments recorded for this period.", leftMargin, y, paint)
            y += 25f
        } else {
            timeline.forEach { entry ->
                when (entry) {
                    is DebtorLedgerEntry.CreditSale -> {
                        val sale = entry.sale
                        ensureSpace(40f)
                        val refCode = sale.formattedReceiptCode(storeName).take(22)
                        val dateStr = sale.purchasedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))

                        runningBalance += sale.total
                        totalSalesAmt += sale.total

                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                        drawLeftText("Utang Ref: $refCode", leftMargin, y, maxDescWidth)
                        canvas.drawText(dateStr, dateColX, y, paint)
                        drawRightText("+${peso.format(sale.total)}", rightMargin, y)
                        y += 15f

                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                        sale.lines.forEach { line ->
                            ensureSpace(16f)
                            val itemDesc = "  • ${line.itemName} x${line.quantity}"
                            drawLeftText(itemDesc, leftMargin, y, maxDescWidth + 40f)
                            drawRightText(peso.format(line.subtotal), rightMargin, y)
                            y += 14f
                        }

                        val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                        if (downPayment > 0.0) {
                            totalCheckoutPartialPayments += downPayment
                            runningBalance = (runningBalance - downPayment).coerceAtLeast(0.0)
                            ensureSpace(16f)
                            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            drawLeftText("  Less Partial Payment (at checkout)", leftMargin, y, maxDescWidth + 40f)
                            drawRightText("-${peso.format(downPayment)}", rightMargin, y)
                            y += 14f
                            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                        }

                        ensureSpace(16f)
                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
                        drawLeftText("  Running Balance after Utang", leftMargin, y, maxDescWidth + 40f)
                        drawRightText(peso.format(runningBalance), rightMargin, y)
                        y += 18f
                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    }

                    is DebtorLedgerEntry.UtangPayment -> {
                        val payment = entry.payment
                        ensureSpace(35f)
                        val displayPaymentId = payment.id.take(18)
                        val dateStr = payment.paidAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))

                        runningBalance = (runningBalance - payment.amount).coerceAtLeast(0.0)
                        totalUtangPaymentsMade += payment.amount

                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                        drawLeftText("Partial Utang Payment ($displayPaymentId)", leftMargin, y, maxDescWidth)
                        canvas.drawText(dateStr, dateColX, y, paint)
                        drawRightText("-${peso.format(payment.amount)}", rightMargin, y)
                        y += 15f

                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
                        drawLeftText("  Running Balance after Payment", leftMargin, y, maxDescWidth + 40f)
                        drawRightText(peso.format(runningBalance), rightMargin, y)
                        y += 18f
                        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    }
                }
            }
        }

        // Summary Breakdown
        ensureSpace(80f)
        canvas.drawLine(leftMargin, y, rightMargin, y, paint)
        y += 18f

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 10f
        canvas.drawText("Total Credit Sales ($startDate to $endDate):", leftMargin, y, paint)
        drawRightText(peso.format(totalSalesAmt), rightMargin, y)
        y += 15f

        if (totalCheckoutPartialPayments > 0.0) {
            canvas.drawText("Total Checkout Partial Payments:", leftMargin, y, paint)
            drawRightText("-${peso.format(totalCheckoutPartialPayments)}", rightMargin, y)
            y += 15f
        }

        if (totalUtangPaymentsMade > 0.0) {
            canvas.drawText("Total Utang Payments Made:", leftMargin, y, paint)
            drawRightText("-${peso.format(totalUtangPaymentsMade)}", rightMargin, y)
            y += 15f
        }

        y += 4f
        canvas.drawLine(leftMargin, y, rightMargin, y, paint)
        y += 18f

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 11f
        canvas.drawText("CURRENT OUTSTANDING BALANCE:", leftMargin, y, paint)
        drawRightText(peso.format(debtor.totalOwed), rightMargin, y)

        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportUserManual(context: Context, outputStream: OutputStream) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val totalPages = 4
        var pageNumber = 1
        var page = document.startPage(pageInfo)
        var canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val leftMargin = 40f
        val rightMargin = 555f
        val printableWidth = rightMargin - leftMargin
        val pageHeight = 842f
        val maxY = 780f
        var y = 45f

        fun newPage() {
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 8.5f
            paint.color = Color.GRAY
            canvas.drawText("AlKris POS User Manual • Page $pageNumber of $totalPages", leftMargin, pageHeight - 30f, paint)
            canvas.drawLine(leftMargin, pageHeight - 42f, rightMargin, pageHeight - 42f, paint)
            paint.color = Color.BLACK

            document.finishPage(page)
            pageNumber++
            page = document.startPage(pageInfo)
            canvas = page.canvas
            y = 45f
        }

        fun checkSpace(required: Float) {
            if (y + required > maxY) {
                newPage()
            }
        }

        fun drawDocumentHeader() {
            val logoDisplaySize = 46f
            var titleX = leftMargin
            runCatching {
                val logoBmp = BitmapFactory.decodeResource(context.resources, R.drawable.alkris_pos_logo)
                if (logoBmp != null) {
                    val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        isFilterBitmap = true
                        isDither = true
                    }
                    val destRect = RectF(
                        leftMargin,
                        y - 2f,
                        leftMargin + logoDisplaySize,
                        y - 2f + logoDisplaySize
                    )
                    canvas.drawBitmap(logoBmp, null, destRect, logoPaint)
                    titleX = leftMargin + logoDisplaySize + 12f
                }
            }

            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 18f
            paint.color = Color.rgb(16, 73, 142)
            canvas.drawText("AlKris POS - User Manual & Guide", titleX, y + 12f, paint)

            paint.textSize = 10f
            paint.color = Color.DKGRAY
            canvas.drawText("Comprehensive Step-by-Step Operational Manual for Retail & E-Cash", titleX, y + 26f, paint)

            paint.typeface = Typeface.DEFAULT
            paint.textSize = 8.5f
            paint.color = Color.GRAY
            canvas.drawText("Developer: Bembem Presga  |  Created: September 2026  |  Edition: Offline v8.3.2", titleX, y + 38f, paint)

            y += logoDisplaySize + 8f

            paint.color = Color.rgb(16, 73, 142)
            canvas.drawLine(leftMargin, y, rightMargin, y, paint)
            y += 18f
            paint.color = Color.BLACK
        }

        fun drawSectionHeader(title: String) {
            checkSpace(38f)
            y += 6f
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 12.5f
            paint.color = Color.rgb(16, 73, 142)
            canvas.drawText(title, leftMargin, y, paint)
            y += 5f
            canvas.drawLine(leftMargin, y, rightMargin, y, paint)
            y += 15f
            paint.color = Color.BLACK
        }

        fun drawParagraph(text: String, indent: Float = 0f) {
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 9f
            paint.color = Color.BLACK

            val maxWidth = printableWidth - indent
            val words = text.split(" ")
            var line = ""

            words.forEach { word ->
                val testLine = if (line.isEmpty()) word else "$line $word"
                val textWidth = paint.measureText(testLine)
                if (textWidth > maxWidth) {
                    checkSpace(12f)
                    canvas.drawText(line, leftMargin + indent, y, paint)
                    y += 12f
                    line = word
                } else {
                    line = testLine
                }
            }
            if (line.isNotEmpty()) {
                checkSpace(12f)
                canvas.drawText(line, leftMargin + indent, y, paint)
                y += 12f
            }
            y += 3f
        }

        fun drawStep(stepNum: Int, stepTitle: String, description: String) {
            checkSpace(24f)
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 9f
            paint.color = Color.rgb(16, 73, 142)
            canvas.drawText("Step $stepNum: $stepTitle", leftMargin + 8f, y, paint)
            y += 12f

            paint.typeface = Typeface.DEFAULT
            paint.color = Color.BLACK
            drawParagraph(description, indent = 20f)
        }

        fun drawBullet(bulletTitle: String, description: String) {
            checkSpace(24f)
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 9f
            paint.color = Color.rgb(16, 73, 142)
            canvas.drawText("• $bulletTitle:", leftMargin + 8f, y, paint)
            y += 12f

            paint.typeface = Typeface.DEFAULT
            paint.color = Color.BLACK
            drawParagraph(description, indent = 20f)
        }

        fun drawTocItem(sectionNumber: String, title: String, pageStr: String) {
            checkSpace(16f)
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 9.5f
            paint.color = Color.rgb(16, 73, 142)
            canvas.drawText("$sectionNumber.", leftMargin + 10f, y, paint)

            paint.typeface = Typeface.DEFAULT
            paint.color = Color.BLACK
            canvas.drawText(title, leftMargin + 32f, y, paint)

            paint.color = Color.GRAY
            val titleWidth = paint.measureText(title)
            val startDots = leftMargin + 36f + titleWidth
            val endDots = rightMargin - 40f
            if (endDots > startDots) {
                var dotX = startDots
                while (dotX < endDots) {
                    canvas.drawText(".", dotX, y, paint)
                    dotX += 8f
                }
            }
            paint.color = Color.BLACK
            paint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText(pageStr, rightMargin - 32f, y, paint)
            y += 15f
        }

        drawDocumentHeader()

        drawSectionHeader("TABLE OF CONTENTS")
        drawTocItem("1", "System Architecture & Offline Engine", "Page 1")
        drawTocItem("2", "Sign-In, Fingerprint & Security", "Page 1")
        drawTocItem("3", "Point of Sale (POS) & Checkout Guide", "Page 2")
        drawTocItem("4", "Product Inventory & Excel Batch Tools", "Page 2")
        drawTocItem("5", "E-Cash & Financial Services Operations", "Page 2")
        drawTocItem("6", "Utang (Customer Credit) & Payment Accounting", "Page 3")
        drawTocItem("7", "Sales Reports, History & Financial Analytics", "Page 3")
        drawTocItem("8", "Cash Drawer Audit & Daily Cash History", "Page 3")
        drawTocItem("9", "Database Backup, Google Drive Cloud Sync & Logs", "Page 4")
        drawTocItem("10", "Official Software Disclaimer & Terms of Use", "Page 4")
        y += 8f

        drawSectionHeader("1. SYSTEM ARCHITECTURE & OFFLINE ENGINE")
        drawParagraph("AlKris POS is built for complete offline reliability. Store owners can run daily sales, manage inventory, record customer credit (utang), and print Bluetooth receipts without any internet connection.")
        drawBullet("100% Local Device Storage", "All product records, transaction logs, and customer accounts are securely stored in a local encrypted SQLite database on the tablet.")
        drawBullet("Dual Operating Modes", "Toggle seamlessly between Mart Mode (for retail products and barcode checkout) and E-Service Mode (for GCash, Maya, mobile load, and bills payment ledgers).")

        drawSectionHeader("2. SIGN-IN, FINGERPRINT & SECURITY")
        drawParagraph("Protect your business terminal with dual-layer authentication and automated security locks.")
        drawStep(1, "Fingerprint Sign-In", "If your tablet has a fingerprint sensor, touch the sensor when prompted on the sign-in screen to log in instantly without typing a PIN.")
        drawStep(2, "PIN Authentication", "Enter your registered PIN using either the 123 numeric keypad or ABC QWERTY toggle. Tap 'Sign in' to proceed.")
        drawStep(3, "Auto-Logout Timer", "In Settings, set the auto-logout timer to 1, 5, 15, or 30 minutes. Inactive terminals will automatically lock to prevent unauthorized access.")
        drawStep(4, "Settings Gear Menu", "Access the gear icon on the sign-in screen to change Store Name, update PIN, view Disclaimer, inspect About details, or download this PDF manual.")

        newPage()

        drawSectionHeader("3. POINT OF SALE (POS) & CHECKOUT GUIDE")
        drawParagraph("Follow these step-by-step instructions to process sales transactions at the checkout counter.")
        drawStep(1, "Scan or Search Products", "Point the built-in tablet camera or an external USB/Bluetooth barcode scanner at a product barcode, or search by product name.")
        drawStep(2, "Customize Cart Items", "Tap any item in the cart to adjust quantities, override unit selling prices, or add custom unlisted store products.")
        drawStep(3, "Apply Store Discounts", "Tap 'Discount' to apply percentage (%) or fixed amount (₱) discounts to specific cart items or the entire bill.")
        drawStep(4, "Payment & Bluetooth Receipt", "Select Cash, E-Cash, or Credit (Utang). Enter cash tendered to calculate change. Completing the sale prints an ESC/POS thermal receipt and pops open the cash drawer.")

        drawSectionHeader("4. PRODUCT INVENTORY & EXCEL BATCH TOOLS")
        drawParagraph("Manage product catalogs, track stock levels, and perform instant batch updates via Excel.")
        drawStep(1, "Add or Edit Products", "Enter barcode, item name, purchase cost, retail selling price, product category, and stock unit (pieces, kg, or grams).")
        drawStep(2, "Low-Stock Alerts", "Automatic low-stock warning badges highlight products that fall below safety thresholds so you can restock on time.")
        drawStep(3, "Excel Batch Export", "Tap 'Export Excel' to download your full inventory spreadsheet (.xlsx/.csv) to the tablet Downloads folder.")
        drawStep(4, "Excel Batch Import", "Edit prices or stock counts in Excel, then tap 'Import Excel' to update thousands of products in seconds.")

        drawSectionHeader("5. E-CASH & FINANCIAL SERVICES OPERATIONS")
        drawParagraph("Process digital financial service transactions with automated fee calculation and earnings tracking.")
        drawStep(1, "Select Service Category", "Switch to E-Service Mode and choose GCash, Maya, Mobile Load, or Utility Bills Payment.")
        drawStep(2, "Log Transaction", "Enter customer phone number, transaction reference number, cash amount, and applicable service fees.")
        drawStep(3, "Audit Daily E-Wallets", "Enter starting and ending daily e-wallet balances across channels to audit cash float and eliminate discrepancies.")

        newPage()

        drawSectionHeader("6. UTANG (CUSTOMER CREDIT) & PAYMENT ACCOUNTING")
        drawParagraph("Manage customer credit accounts and track debt repayments with complete accountability.")
        drawStep(1, "Register Customer Debtors", "Create debtor profiles with customer name, contact phone number, and credit notes.")
        drawStep(2, "Process Credit Sales", "At checkout, select 'CREDIT / UTANG' payment mode and assign the sale to a customer profile.")
        drawStep(3, "Record Debt Repayments", "When customers pay, log partial or full repayments in cash or e-cash to automatically update outstanding balances.")
        drawStep(4, "Export Debt Statements", "Generate itemized customer debt ledger statements and export them as PDF reports or print thermal ledger receipts.")

        drawSectionHeader("7. SALES REPORTS, HISTORY & FINANCIAL ANALYTICS")
        drawParagraph("Analyze financial health and review detailed historical transactions.")
        drawStep(1, "Filter Reporting Periods", "Select Today, Daily, Weekly, Monthly, or Custom Date Ranges on the Reports screen.")
        drawStep(2, "Review Revenue & Profits", "View Gross Sales Volume, Cost of Goods Sold, Total Discounts Applied, and Net Profit Margins.")
        drawStep(3, "Search Transaction History", "Search past sales by receipt code or date, view itemized cart breakdowns, and reprint receipts.")
        drawStep(4, "Export Financial PDFs", "Export Sales Reports, Receivables Summaries, Discounts Summaries, and System Activity Logs directly to PDF.")

        drawSectionHeader("8. CASH DRAWER AUDIT & DAILY CASH HISTORY")
        drawParagraph("Maintain strict cash drawer float accountability across store shifts.")
        drawStep(1, "Opening Cash Capital", "Register the starting cash drawer float at the start of each business day.")
        drawStep(2, "Record Cash Movements", "Log Cash Additions (capital top-up), Cash Pullouts (store expenses or owner withdrawals), and Customer Debt Repayments.")
        drawStep(3, "Shift Closing Reconciliation", "System calculates expected closing cash in drawer. Compare against physical cash count and print cash audit summary receipts.")

        newPage()

        drawSectionHeader("9. DATABASE BACKUP, GOOGLE DRIVE CLOUD SYNC & LOGS")
        drawParagraph("Ensure business continuity with automated cloud backups and administrative activity logs.")
        drawStep(1, "Offline Database Export", "Export full database backup files (.db) directly to tablet storage or USB flash drives for offline data migration.")
        drawStep(2, "Google Drive Cloud Sync", "When connected to the internet, sign into Google Drive for automated background cloud database backups.")
        drawStep(3, "System Activity Logs", "Review administrative audit logs tracking logins, inventory edits, PIN changes, and system backup events.")

        drawSectionHeader("10. OFFICIAL SOFTWARE DISCLAIMER & TERMS OF USE")
        drawParagraph("Below is the official software disclaimer governing the use of AlKris POS:")
        drawBullet("User Agreement & Acceptance", "By downloading, installing, signing in, or using the AlKris POS application, you explicitly acknowledge that you have read, understood, and agreed to be bound by all terms, conditions, disclaimers, and limitations of liability set forth in this Disclaimer & Terms of Use.")
        drawBullet("Application Scope", "AlKris POS is provided on an 'as-is' and 'as-available' basis for store management, sales processing, inventory control, and accounting.")
        drawBullet("BIR Non-Compliance Notice (Personal / Internal Use Only)", "AlKris POS is designed strictly for personal, internal store bookkeeping and sales logging. This software is NOT accredited by the BIR (Bureau of Internal Revenue) and does NOT issue official tax receipts. Users requiring a BIR-accredited POS system or Permit to Use (PTU) must consult and procure a BIR-accredited provider.")
        drawBullet("Offline Reliability & Cloud Features", "Core retail operations operate 100% locally on device storage without requiring internet. Internet access is ONLY used for optional Google Drive cloud sync and authentication.")
        drawBullet("Limitation of Liability", "The developer (Bembem Presga) and distributors assume no liability for financial losses, calculation errors, hardware failures, corruption of local database files, or business interruptions. Store owners are responsible for maintaining regular offline database exports and conducting physical reconciliations.")

        paint.typeface = Typeface.DEFAULT
        paint.textSize = 8.5f
        paint.color = Color.GRAY
        canvas.drawText("AlKris POS User Manual • Page $pageNumber of $totalPages", leftMargin, pageHeight - 30f, paint)
        canvas.drawLine(leftMargin, pageHeight - 42f, rightMargin, pageHeight - 42f, paint)

        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun downloadUserManualToDownloads(context: Context): Boolean {
        return runCatching {
            val fileName = "AlKris_POS_User_Manual.pdf"
            val resolver = context.contentResolver
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    ?: throw Exception("Failed to create download entry in MediaStore")
                resolver.openOutputStream(uri)?.use { os ->
                    exportUserManual(context, os)
                }
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val file = File(downloadsDir, fileName)
                FileOutputStream(file).use { os ->
                    exportUserManual(context, os)
                }
            }
            true
        }.getOrElse { e ->
            Log.e("PdfExporter", "Failed to download User Manual PDF", e)
            false
        }
    }
}
