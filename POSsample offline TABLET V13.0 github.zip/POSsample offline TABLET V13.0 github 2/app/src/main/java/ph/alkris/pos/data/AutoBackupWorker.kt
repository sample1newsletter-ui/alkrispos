package ph.alkris.pos.data

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import ph.alkris.pos.ui.PosViewModel
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.concurrent.TimeUnit

class AutoBackupWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val backupManager = BackupManager(applicationContext)

        try {
            if (backupManager.isSignedIn()) {
                val now = LocalDateTime.now()
                val activeSlot = AutoBackupScheduler.getActiveSlot(now)

                val prefsMart = applicationContext.getSharedPreferences("pos_mart_prefs", Context.MODE_PRIVATE)
                val prefsEcash = applicationContext.getSharedPreferences("pos_ecash_prefs", Context.MODE_PRIVATE)

                val lastSlotMart = prefsMart.getString("last_auto_backup_slot", null)
                val lastSlotEcash = prefsEcash.getString("last_auto_backup_slot", null)

                val needsBackupMart = lastSlotMart != activeSlot && AutoBackupScheduler.hasUnbackedChanges(applicationContext, "pos_mart_prefs")
                val needsBackupEcash = lastSlotEcash != activeSlot && AutoBackupScheduler.hasUnbackedChanges(applicationContext, "pos_ecash_prefs")

                if (needsBackupMart) {
                    val martRepo = LocalPosRepository(applicationContext, "pos_mart.db", "pos_mart_prefs")
                    val storeName = martRepo.getStoreName()
                    val result = backupManager.backupDatabase(storeName, AppMode.MART)
                    if (result.isSuccess) {
                        prefsMart.edit().putString("last_auto_backup_slot", activeSlot).apply()
                        AutoBackupScheduler.markBackupCompleted(applicationContext, "pos_mart_prefs")
                        Log.i("AutoBackupWorker", "Mart auto backup successful for slot: $activeSlot")
                    }
                } else if (lastSlotMart != activeSlot) {
                    prefsMart.edit().putString("last_auto_backup_slot", activeSlot).apply()
                }

                if (needsBackupEcash) {
                    val ecashRepo = LocalPosRepository(applicationContext, "pos_ecash.db", "pos_ecash_prefs")
                    val storeName = ecashRepo.getStoreName()
                    val result = backupManager.backupDatabase(storeName, AppMode.ECASH)
                    if (result.isSuccess) {
                        prefsEcash.edit().putString("last_auto_backup_slot", activeSlot).apply()
                        AutoBackupScheduler.markBackupCompleted(applicationContext, "pos_ecash_prefs")
                        Log.i("AutoBackupWorker", "Ecash auto backup successful for slot: $activeSlot")
                    }
                } else if (lastSlotEcash != activeSlot) {
                    prefsEcash.edit().putString("last_auto_backup_slot", activeSlot).apply()
                }
            }
        } catch (e: Exception) {
            Log.e("AutoBackupWorker", "Error executing auto backup worker", e)
        } finally {
            AutoBackupScheduler.scheduleNextWorker(applicationContext)
        }

        return Result.success()
    }
}

object AutoBackupScheduler {
    val SCHEDULE_HOURS = listOf(1, 8, 12, 15, 18) // 1 AM, 8 AM, 12 NN, 3 PM, 6 PM

    fun markDataChanged(context: Context, prefsName: String = "pos_prefs") {
        context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            .edit()
            .putLong("last_data_change_timestamp", System.currentTimeMillis())
            .apply()
    }

    fun markBackupCompleted(context: Context, prefsName: String = "pos_prefs") {
        context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            .edit()
            .putLong("last_backup_timestamp", System.currentTimeMillis())
            .apply()
    }

    fun hasUnbackedChanges(context: Context, prefsName: String = "pos_prefs"): Boolean {
        val prefs = context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val lastChange = prefs.getLong("last_data_change_timestamp", 0L)
        val lastBackup = prefs.getLong("last_backup_timestamp", 0L)
        return lastBackup == 0L || lastChange > lastBackup
    }

    fun getActiveSlot(now: LocalDateTime): String {
        val hour = now.hour
        val (slotDate, slotHour) = when {
            hour >= 18 -> now.toLocalDate() to 18
            hour >= 15 -> now.toLocalDate() to 15
            hour >= 12 -> now.toLocalDate() to 12
            hour >= 8  -> now.toLocalDate() to 8
            hour >= 1  -> now.toLocalDate() to 1
            else       -> now.toLocalDate().minusDays(1) to 18
        }
        return "${slotDate}_$slotHour"
    }

    fun checkAndTriggerAutoBackup(context: Context, viewModel: PosViewModel) {
        val backupManager = BackupManager(context)
        if (!backupManager.isSignedIn()) return

        val now = LocalDateTime.now()
        val activeSlot = getActiveSlot(now)
        val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
        val lastSlot = prefs.getString("last_auto_backup_slot", null)

        if (lastSlot != activeSlot) {
            if (!hasUnbackedChanges(context)) {
                Log.i("AutoBackupScheduler", "Skipping auto backup for slot $activeSlot: No transactions or data changes made.")
                prefs.edit().putString("last_auto_backup_slot", activeSlot).apply()
                return
            }
            prefs.edit().putString("last_auto_backup_slot", activeSlot).apply()
            viewModel.triggerDriveBackup(context, viewModel.state.value.currentMode, silent = true)
        }
    }

    fun calculateDelayUntilNextSlot(now: LocalDateTime = LocalDateTime.now()): Duration {
        val today = now.toLocalDate()
        val nextSlotTime = SCHEDULE_HOURS
            .asSequence()
            .map { LocalDateTime.of(today, LocalTime.of(it, 0)) }
            .firstOrNull { it.isAfter(now) }
            ?: LocalDateTime.of(today.plusDays(1), LocalTime.of(SCHEDULE_HOURS.first(), 0))

        return Duration.between(now, nextSlotTime).coerceAtLeast(Duration.ofSeconds(10))
    }

    fun scheduleNextWorker(context: Context) {
        val delay = calculateDelayUntilNextSlot()
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val workRequest = OneTimeWorkRequestBuilder<AutoBackupWorker>()
            .setInitialDelay(delay.toMillis(), TimeUnit.MILLISECONDS)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            workRequest
        )
    }

    const val WORK_NAME = "sarisari_auto_backup_scheduled_worker"
}
