package ph.alkris.pos.ui.screens

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import com.dantsu.escposprinter.connection.bluetooth.BluetoothPrintersConnections
import android.content.Context
import android.content.res.Configuration
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ph.alkris.pos.ui.DatabasePinDialog
import ph.alkris.pos.ui.PdfExporter
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Green
import ph.alkris.pos.ui.components.Pink
import ph.alkris.pos.ui.components.ScrollbarColor
import ph.alkris.pos.ui.components.SkyBlue
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
private fun ScrollbarColumn(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val scrollState = rememberScrollState()
    Box(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(end = 8.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            content = content
        )
        if (scrollState.maxValue > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(4.dp)
                    .drawWithContent {
                        val viewport = size.height
                        val maxScroll = scrollState.maxValue.toFloat()
                        val thumbHeight = (viewport * viewport / (viewport + maxScroll)).coerceAtLeast(30f)
                        val maxOffset = viewport - thumbHeight
                        val progress = scrollState.value.toFloat() / maxScroll
                        drawRoundRect(
                            color = ScrollbarColor,
                            topLeft = Offset(size.width - 4.dp.toPx(), maxOffset * progress),
                            size = Size(4.dp.toPx(), thumbHeight),
                            cornerRadius = CornerRadius(2.dp.toPx())
                        )
                    }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: PosViewModel,
    onDismiss: () -> Unit,
    onOpenAutoBackup: () -> Unit = {},
    onOpenManual: () -> Unit = {}
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }

    var storeName by remember { mutableStateOf(prefs.getString("store_name", "AlKris Sari-sari Store") ?: "AlKris Sari-sari Store") }
    var storeLocation by remember { mutableStateOf(prefs.getString("store_location", "Poblacion, Philippines") ?: "Poblacion, Philippines") }
    var storeContact by remember { mutableStateOf(prefs.getString("store_contact", "0912-345-6789") ?: "0912-345-6789") }
    var receiptFooter by remember { mutableStateOf(prefs.getString("receipt_footer", "Thank you for shopping!") ?: "Thank you for shopping!") }
    
    var themeMode by remember { mutableStateOf(prefs.getString("theme_mode", "System") ?: "System") }
    var enableBiometrics by remember { mutableStateOf(prefs.getBoolean("enable_biometrics", true)) }
    var autoLogoutMins by remember { mutableIntStateOf(prefs.getInt("auto_logout_minutes", 5)) }
    var is80mmPaper by remember { mutableStateOf(prefs.getBoolean("is_80mm_paper", false)) }
    var isSmallFont by remember { mutableStateOf(prefs.getBoolean("is_small_font", false)) }
    var drawerMode by remember { mutableStateOf(prefs.getString("drawer_mode", "COMBINED") ?: "COMBINED") }
    var autoBackupOn by remember { mutableStateOf(prefs.getBoolean("auto_backup_on", true)) }
    var autoBackupFreq by remember { mutableStateOf(prefs.getString("auto_backup_freq", "Every 4 Hours") ?: "Every 4 Hours") }
    var lastBackupDate by remember { mutableStateOf(prefs.getString("last_backup_date", "Oct 1, 2026 at 9:18 PM") ?: "Oct 1, 2026 at 9:18 PM") }

    var showPinChangeDialog by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showAutoLogoutDialog by remember { mutableStateOf(false) }
    var showBluetoothPrinterModal by remember { mutableStateOf(false) }
    var selectedPrinterName by remember { mutableStateOf(prefs.getString("connected_printer_name", "MTP-II") ?: "MTP-II") }
    var bluetoothDevicesList by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var selectedResetPreset by remember { mutableStateOf("") }

    var expandStoreIdentity by remember { mutableStateOf(false) }
    var expandAppearanceTheme by remember { mutableStateOf(false) }
    var expandSecuritySignIn by remember { mutableStateOf(false) }
    var expandReceiptPrinting by remember { mutableStateOf(false) }
    var expandDatabaseBackup by remember { mutableStateOf(false) }
    var expandInventoryReset by remember { mutableStateOf(false) }
    var expandOperationsManual by remember { mutableStateOf(false) }

    @SuppressLint("MissingPermission")
    fun scanBluetoothPrinters() {
        val list = mutableListOf<Pair<String, String>>()
        try {
            val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            if (bluetoothAdapter != null && bluetoothAdapter.isEnabled) {
                val bonded = try { bluetoothAdapter.bondedDevices } catch (_: Exception) { null }
                bonded?.forEach { dev ->
                    try {
                        if (dev.name.isNotBlank()) {
                            list.add(dev.name to dev.address)
                        }
                    } catch (_: Exception) {}
                }
            }
            val pairedConns = try { BluetoothPrintersConnections.selectFirstPaired() } catch (_: Exception) { null }
            if (pairedConns != null && list.none { it.second == pairedConns.device.address }) {
                list.add(pairedConns.device.name to pairedConns.device.address)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (list.isEmpty()) {
            list.add("MTP-II (Default Thermal)" to "00:11:22:33:44:55")
            list.add("POS-58 Thermal Printer" to "00:22:33:44:55:66")
            list.add("PT-210 Bluetooth Printer" to "00:33:44:55:66:77")
        }
        bluetoothDevicesList = list
        showBluetoothPrinterModal = true
    }

    val databaseExportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/x-sqlite3")
    ) { uri ->
        uri?.let {
            val pin = prefs.getString("app_pin", prefs.getString("station_pin", "1234")) ?: "1234"
            context.contentResolver.openOutputStream(it)?.use { stream ->
                viewModel.exportDatabase(pin, stream)
                Toast.makeText(context, "Database exported successfully", Toast.LENGTH_LONG).show()
            }
        }
    }

    val databaseImportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            val pin = prefs.getString("app_pin", prefs.getString("station_pin", "1234")) ?: "1234"
            context.contentResolver.openInputStream(it)?.use { stream ->
                viewModel.importDatabase(pin, stream)
                Toast.makeText(context, "Database restored. Restarting app...", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun saveStoreProfile() {
        val pin = prefs.getString("app_pin", prefs.getString("station_pin", "1234")) ?: "1234"
        viewModel.updateStoreName(storeName.trim(), pin)
        prefs.edit()
            .putString("store_name", storeName.trim())
            .putString("store_location", storeLocation.trim())
            .putString("store_contact", storeContact.trim())
            .putString("receipt_footer", receiptFooter.trim())
            .apply()
        Toast.makeText(context, "Store Profile Saved", Toast.LENGTH_SHORT).show()
    }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val sectionHeaderColor = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
    val iconSkyTint = if (isDark) SkyBlue else LocalContentColor.current

    val storeIdentityCard = @Composable {
        ExpandableSettingsCard(
            title = "Store Identity",
            expanded = expandStoreIdentity,
            onToggle = { expandStoreIdentity = !expandStoreIdentity },
            titleColor = sectionHeaderColor
        ) {
            OutlinedTextField(value = storeName, onValueChange = { storeName = it }, label = { Text("Store Name") }, singleLine = true, shape = ControlShape, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = storeLocation, onValueChange = { storeLocation = it }, label = { Text("Location") }, singleLine = true, shape = ControlShape, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = storeContact, onValueChange = { storeContact = it }, label = { Text("Phone Number") }, singleLine = true, shape = ControlShape, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = receiptFooter, onValueChange = { receiptFooter = it }, label = { Text("Receipt Footer Note") }, singleLine = true, shape = ControlShape, modifier = Modifier.fillMaxWidth())
            
            Button(
                onClick = { saveStoreProfile() },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Text("Save Store Profile")
            }
        }
    }

    val appearanceThemeCard = @Composable {
        ExpandableSettingsCard(
            title = "Appearance & Theme",
            expanded = expandAppearanceTheme,
            onToggle = { expandAppearanceTheme = !expandAppearanceTheme },
            titleColor = sectionHeaderColor
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("System", "Light", "Dark").forEach { mode ->
                    val selected = themeMode == mode
                    FilterChip(
                        selected = selected,
                        onClick = {
                            themeMode = mode
                            prefs.edit().putString("theme_mode", mode).apply()
                        },
                        label = { Text(mode) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Text("Choose Light mode, Dark mode, or follow your System theme.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }

    val securitySignInCard = @Composable {
        ExpandableSettingsCard(
            title = "Security & Sign-In",
            expanded = expandSecuritySignIn,
            onToggle = { expandSecuritySignIn = !expandSecuritySignIn },
            titleColor = sectionHeaderColor
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showPinChangeDialog = true },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Change PIN", fontWeight = FontWeight.SemiBold)
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Enable Face ID / Touch ID", fontWeight = FontWeight.SemiBold)
                Switch(
                    checked = enableBiometrics,
                    onCheckedChange = {
                        enableBiometrics = it
                        prefs.edit().putBoolean("enable_biometrics", it).apply()
                    }
                )
            }

            HorizontalDivider()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showAutoLogoutDialog = true }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Auto-Logout Timeout", fontWeight = FontWeight.SemiBold)
                    Text(
                        text = if (autoLogoutMins == 0) "Off (Disabled)" else "$autoLogoutMins minute${if (autoLogoutMins > 1) "s" else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
                Icon(Icons.Default.ChevronRight, contentDescription = "Change Auto-Logout", tint = Color.Gray)
            }
        }
    }

    val receiptPrintingCard = @Composable {
        ExpandableSettingsCard(
            title = "Receipt Printing & Cash Drawer",
            expanded = expandReceiptPrinting,
            onToggle = { expandReceiptPrinting = !expandReceiptPrinting },
            titleColor = sectionHeaderColor
        ) {
            Text("Printer Status: Connected ($selectedPrinterName)", fontWeight = FontWeight.SemiBold, color = Green)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("80mm Wide Paper", fontWeight = FontWeight.SemiBold)
                    Text("(Default: 58mm)", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                Switch(
                    checked = is80mmPaper,
                    onCheckedChange = {
                        is80mmPaper = it
                        prefs.edit().putBoolean("is_80mm_paper", it).apply()
                    }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Small Font (Screen Match)", fontWeight = FontWeight.SemiBold)
                    Text("Font B", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                Switch(
                    checked = isSmallFont,
                    onCheckedChange = {
                        isSmallFont = it
                        prefs.edit().putBoolean("is_small_font", it).apply()
                    }
                )
            }

            OutlinedButton(
                onClick = { scanBluetoothPrinters() },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Icon(Icons.Default.Bluetooth, contentDescription = null, tint = iconSkyTint)
                Spacer(Modifier.width(8.dp))
                Text("Scan Bluetooth", color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary)
            }
        }
    }

    val databaseBackupCard = @Composable {
        ExpandableSettingsCard(
            title = "Database Backup & Restore (.db)",
            expanded = expandDatabaseBackup,
            onToggle = { expandDatabaseBackup = !expandDatabaseBackup },
            titleColor = sectionHeaderColor
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenAutoBackup() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Auto Backup", fontWeight = FontWeight.SemiBold)
                    Text("ON • Drive • $autoBackupFreq", style = MaterialTheme.typography.bodySmall, color = Green)
                }
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
            }

            Text("Last Backup Created: $lastBackupDate", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

            Button(
                onClick = { databaseExportLauncher.launch("${storeName.replace(" ", "_")}_backup.db") },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Text("Export All Databases (.db) [Mart + E-Cash]", color = if (isDark) SkyBlue else Color.White)
            }

            OutlinedButton(
                onClick = { databaseExportLauncher.launch("${storeName.replace(" ", "_")}_mart_backup.db") },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Text("Export Mart Database (.db) [Inventory & Sales]", color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary)
            }

            OutlinedButton(
                onClick = { databaseExportLauncher.launch("${storeName.replace(" ", "_")}_ecash_backup.db") },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Text("Export E-Cash Database (.db) [E-Cash & Wallets]", color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary)
            }

            OutlinedButton(
                onClick = { databaseImportLauncher.launch("*/*") },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Text("Restore Database from .db File", color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary)
            }

            Text(
                "Backups are exported in native SQLite Database (.db) format. You can back up Mart (inventory, sales, utang debts, cash drawer) and E-Cash (transactions, e-wallets), or export all databases together.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }

    val inventoryResetCard = @Composable {
        ExpandableSettingsCard(
            title = "Inventory Reset",
            expanded = expandInventoryReset,
            onToggle = { expandInventoryReset = !expandInventoryReset },
            titleColor = Pink
        ) {
            OutlinedButton(
                onClick = {
                    selectedResetPreset = "0"
                    showResetDialog = true
                },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Pink)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Reset with 0 Inventories (Blank Slate)", fontWeight = FontWeight.Bold)
                    Text("Wipe all products and start completely empty", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }

            Button(
                onClick = {
                    selectedResetPreset = "400+"
                    showResetDialog = true
                },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Reset with 400+ Filipino Groceries", fontWeight = FontWeight.Bold)
                    Text("Includes Luya, Ahos, Bombay, Mantika & produce - 421 items", style = MaterialTheme.typography.bodySmall)
                }
            }

            Button(
                onClick = {
                    selectedResetPreset = "100+ Hardware"
                    showResetDialog = true
                },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Reset with 100+ Hardware & Construction Supplies", fontWeight = FontWeight.Bold)
                    Text("Pre-loads Cement, Steel Bars, Plywood, PVC, Wires, Tools & Paint - 100 items", style = MaterialTheme.typography.bodySmall)
                }
            }

            OutlinedButton(
                onClick = {
                    viewModel.compressAllProductImages(context)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                val iconSkyTint = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                Icon(Icons.Default.Compress, contentDescription = null, tint = iconSkyTint)
                Spacer(Modifier.width(8.dp))
                Text("Compress All Existing Product Images", fontWeight = FontWeight.Bold, color = iconSkyTint)
            }

            Text(
                "Requires PIN authorization only. Resetting wipes existing products and initializes the catalog with your chosen preset.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }

    val operationsManualCard = @Composable {
        ExpandableSettingsCard(
            title = "Operations Manual & Legal Notices",
            expanded = expandOperationsManual,
            onToggle = { expandOperationsManual = !expandOperationsManual },
            titleColor = sectionHeaderColor
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenManual() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("View User Manual (4-Page Guide)", fontWeight = FontWeight.SemiBold)
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
            }

            OutlinedButton(
                onClick = {
                    PdfExporter.downloadUserManualToDownloads(context)
                    Toast.makeText(context, "User Manual downloaded to Downloads", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null, tint = iconSkyTint)
                Spacer(Modifier.width(8.dp))
                Text("Download Manual to Files / Share", color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary)
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("• BIR Non-Compliance Notice", fontWeight = FontWeight.Bold, color = Pink, style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "AlKris POS is designed strictly for personal, internal store bookkeeping and sales logging. This software is NOT accredited by the Bureau of Internal Revenue (BIR) and does NOT issue official tax receipts or invoices.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = onDismiss) {
                        val doneColor = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                        Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = doneColor)
                    }
                }
            )
        }
    ) { padding ->
        if (isLandscape) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // LEFT COLUMN (INDEPENDENTLY SCROLLABLE WITH SCROLLBAR)
                ScrollbarColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    storeIdentityCard()
                    appearanceThemeCard()
                    securitySignInCard()
                    receiptPrintingCard()
                }

                // RIGHT COLUMN (INDEPENDENTLY SCROLLABLE WITH SCROLLBAR)
                ScrollbarColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    databaseBackupCard()
                    inventoryResetCard()
                    operationsManualCard()
                }
            }
        } else {
            ScrollbarColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                storeIdentityCard()
                appearanceThemeCard()
                securitySignInCard()
                receiptPrintingCard()
                databaseBackupCard()
                inventoryResetCard()
                operationsManualCard()
            }
        }
    }

    if (showPinChangeDialog) {
        var oldPin by remember { mutableStateOf("") }
        var newPin by remember { mutableStateOf("") }
        var confirmPin by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showPinChangeDialog = false },
            title = { Text("Change PIN", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = oldPin,
                        onValueChange = { oldPin = it },
                        label = { Text("Current PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { newPin = it },
                        label = { Text("New PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { confirmPin = it },
                        label = { Text("Confirm New PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showPinChangeDialog = false }) { Text("Cancel") }
                    Button(
                        onClick = {
                            when {
                                newPin.length < 4 -> {
                                    Toast.makeText(context, "New PIN must be at least 4 digits", Toast.LENGTH_SHORT).show()
                                }
                                newPin != confirmPin -> {
                                    Toast.makeText(context, "New PIN and Confirm PIN do not match", Toast.LENGTH_SHORT).show()
                                }
                                else -> {
                                    viewModel.verifyPin(oldPin) { isValid ->
                                        if (isValid) {
                                            viewModel.updatePin(newPin, oldPin)
                                            prefs.edit().putString("app_pin", newPin).putString("station_pin", newPin).apply()
                                            showPinChangeDialog = false
                                            Toast.makeText(context, "PIN updated successfully", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "Current PIN is incorrect", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            }
                        },
                        shape = ControlShape
                    ) {
                        Text("Update PIN")
                    }
                }
            }
        )
    }

    if (showResetDialog) {
        DatabasePinDialog(
            title = "Authorize Inventory Reset",
            message = "Enter PIN to authorize reset preset: $selectedResetPreset",
            onConfirm = { pin ->
                showResetDialog = false
                viewModel.resetDatabase(pin, selectedResetPreset)
            },
            onDismiss = { showResetDialog = false }
        )
    }

    if (showAutoLogoutDialog) {
        val options = listOf(
            "Off (Disabled)" to 0,
            "1 Minute" to 1,
            "5 Minutes" to 5,
            "15 Minutes" to 15,
            "30 Minutes" to 30,
            "60 Minutes" to 60
        )

        AlertDialog(
            onDismissRequest = { showAutoLogoutDialog = false },
            title = { Text("Set Auto-Logout Timeout", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    options.forEach { (label, mins) ->
                        Surface(
                            onClick = {
                                autoLogoutMins = mins
                                prefs.edit().putInt("auto_logout_minutes", mins).apply()
                                showAutoLogoutDialog = false
                                Toast.makeText(
                                    context,
                                    if (mins == 0) "Auto-logout disabled" else "Auto-logout set to $label",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            shape = ControlShape,
                            color = if (autoLogoutMins == mins) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    label,
                                    fontWeight = if (autoLogoutMins == mins) FontWeight.Bold else FontWeight.Normal,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                if (autoLogoutMins == mins) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAutoLogoutDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showBluetoothPrinterModal) {
        AlertDialog(
            onDismissRequest = { showBluetoothPrinterModal = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Select Bluetooth Printer", fontWeight = FontWeight.Bold)
                    IconButton(onClick = { scanBluetoothPrinters() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Printers")
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 280.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "Available & paired Bluetooth thermal printers:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                    Spacer(Modifier.height(4.dp))

                    bluetoothDevicesList.forEach { (name, mac) ->
                        val isSelected = selectedPrinterName.contains(name, ignoreCase = true) || selectedPrinterName == name
                        Surface(
                            onClick = {
                                selectedPrinterName = name
                                prefs.edit()
                                    .putString("connected_printer_name", name)
                                    .putString("connected_printer_mac", mac)
                                    .apply()
                                showBluetoothPrinterModal = false
                                Toast.makeText(context, "Connected to $name ($mac)", Toast.LENGTH_SHORT).show()
                            },
                            shape = ControlShape,
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Print,
                                        contentDescription = null,
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Column {
                                        Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("MAC: $mac", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }

                                if (isSelected) {
                                    Surface(
                                        color = Green.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            "Connected",
                                            color = Green,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBluetoothPrinterModal = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun ExpandableSettingsCard(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    titleColor: Color = MaterialTheme.colorScheme.primary,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = titleColor
                )
                IconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Toggle $title"
                    )
                }
            }

            if (expanded) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                content()
            }
        }
    }
}
