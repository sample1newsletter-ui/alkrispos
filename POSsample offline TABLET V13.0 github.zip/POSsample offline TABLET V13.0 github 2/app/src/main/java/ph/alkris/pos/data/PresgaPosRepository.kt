package ph.alkris.pos.data

import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.io.InputStream
import java.io.OutputStream
import kotlin.math.round

class PresgaPosRepository : PosRepository {
    private var currentPin = "1234"
    private var storeName = "ALKRIS POS"
    private val items = mutableListOf(
        InventoryItem("480001", "Lucky Me Pancit Canton", 12.0, 15.0, 24, 5),
        InventoryItem("480002", "Coca-Cola 330ml", 12.0, 18.0, 8, 5),
        InventoryItem("480003", "Cloud 9 Chocolate", 13.0, 18.0, 0, 5)
    )
    private val sales = mutableListOf<Sale>()
    private val debtPaymentRecords = mutableListOf<DebtPayment>()
    private val withdrawals = mutableListOf<CashWithdrawal>()
    private val capitals = mutableListOf<CashCapital>()

    override suspend fun authenticate(pin: String): Boolean { delay(150); return pin == currentPin }
    override suspend fun updatePin(newPin: String) { delay(150); currentPin = newPin }
    override suspend fun getStoreName(): String = storeName
    override suspend fun updateStoreName(name: String) { delay(150); storeName = name }
    override suspend fun inventory(): List<InventoryItem> { delay(150); return items.toList() }
    override suspend fun saveItem(item: InventoryItem) { items.removeAll { it.barcode == item.barcode }; items.add(item) }
    override suspend fun updateItemImage(barcode: String, imagePath: String) {
        val index = items.indexOfFirst { it.barcode == barcode }
        if (index >= 0) items[index] = items[index].copy(imagePath = imagePath)
    }
    override suspend fun deleteItem(barcode: String) { items.removeAll { it.barcode == barcode } }
    override suspend fun completeSale(sale: Sale) {
        sale.lines.forEach { line ->
            if (!line.barcode.startsWith("ECASH_")) {
                val index = items.indexOfFirst { it.barcode == line.barcode }
                require(index >= 0 && items[index].stockQuantity >= line.quantity) { "Insufficient stock for ${line.itemName}" }
            }
        }
        sale.lines.forEach { line ->
            if (!line.barcode.startsWith("ECASH_")) {
                val index = items.indexOfFirst { it.barcode == line.barcode }
                if (index >= 0) items[index] = items[index].copy(stockQuantity = items[index].stockQuantity - line.quantity)
            }
        }
        sales += sale
    }
    private fun Sale.netOwed(): Double {
        val downPayment = (cashReceived - change).coerceAtLeast(0.0)
        return (total - downPayment).coerceAtLeast(0.0)
    }

    override suspend fun customerReceivable(contact: String): Double =
        (
            sales.filter { it.paymentType == "CREDIT" && it.customerContact == contact }.sumOf { it.netOwed() } -
                debtPaymentRecords.filter { it.contact == contact }.sumOf { it.amount }
            ).let { (round(it * 100.0) / 100.0).coerceAtLeast(0.0) }
    override suspend fun debtors(): List<Debtor> =
        sales.filter { it.paymentType == "CREDIT" }.groupBy { it.customerContact }.map { (_, customerSales) ->
            val sale = customerSales.maxBy { it.purchasedAt }
            val netOwed = customerSales.sumOf { it.netOwed() } -
                debtPaymentRecords.filter { it.contact == sale.customerContact }.sumOf { it.amount }
            val roundedOwed = (round(netOwed * 100.0) / 100.0).coerceAtLeast(0.0)
            Debtor(
                sale.customerName,
                sale.customerContact,
                roundedOwed,
                sale.purchasedAt,
                sale.signature
            )
        }
    override suspend fun saveCustomer(name: String, phone: String, address: String, creditLimit: Double, signature: ByteArray?) {}
    override suspend fun recordDebtPayment(payment: DebtPayment) {
        val owed = customerReceivable(payment.contact)
        val amountCents = round(payment.amount * 100.0).toLong()
        val owedCents = round(owed * 100.0).toLong()
        require(payment.amount > 0 && amountCents <= owedCents) { "Invalid payment amount" }
        debtPaymentRecords += payment
        capitals += CashCapital(amount = payment.amount, note = "Utang payment - ${payment.debtorName}")
    }
    override suspend fun debtPayments(): List<DebtPayment> = debtPaymentRecords.sortedByDescending { it.paidAt }

    override suspend fun voidSale(saleId: String) {
        delay(150)
        val sale = sales.find { it.id == saleId } ?: return
        sale.lines.forEach { line ->
            val index = items.indexOfFirst { it.barcode == line.barcode }
            if (index >= 0) items[index] = items[index].copy(stockQuantity = items[index].stockQuantity + line.quantity)
        }
        sales.removeAll { it.id == saleId }
    }

    override suspend fun salesBetween(start: LocalDate, end: LocalDate): List<Sale> = sales.filter { it.purchasedAt.toLocalDate() in start..end }
    override suspend fun totalCash(): Double = sales.sumOf { it.cashAmount } + capitals.sumOf { it.amount } - withdrawals.sumOf { it.amount }
    override suspend fun cashBalanceAt(date: LocalDate): Double =
        sales.filter { it.purchasedAt.toLocalDate() <= date }.sumOf { it.cashAmount } +
            capitals.filter { it.addedAt.toLocalDate() <= date }.sumOf { it.amount } -
            withdrawals.filter { it.withdrawnAt.toLocalDate() <= date }.sumOf { it.amount }
    override suspend fun recordCashWithdrawal(withdrawal: CashWithdrawal) { withdrawals += withdrawal }
    override suspend fun cashWithdrawals(): List<CashWithdrawal> = withdrawals.sortedByDescending { it.withdrawnAt }
    override suspend fun recordCashCapital(capital: CashCapital) { capitals += capital }
    override suspend fun cashCapitals(): List<CashCapital> = capitals.sortedByDescending { it.addedAt }
    override suspend fun exportDatabase(output: OutputStream, format: String) =
        output.write("POS_CSV_V1\n".toByteArray())
    override suspend fun importDatabase(input: InputStream) { importDatabaseTarget(input, "BOTH") }
    override suspend fun importDatabaseTarget(input: InputStream, target: String) { input.copyTo(
        ByteArrayOutputStream()
    ) }
    override suspend fun resetDatabase(preset: String) {
        currentPin = "1234"
        storeName = "ALKRIS POS"
        items.clear()
        if (preset == "400+") {
            items += listOf(
                InventoryItem("480000000001", "Lucky Me Pancit Canton Original 80g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000031", "Century Tuna Flakes in Oil 180g", 32.0, 39.0, 40, 8),
                InventoryItem("480000000071", "Nescafe 3in1 Original Coffee Twin Pack 56g", 12.0, 15.0, 60, 10)
            )
        } else if (preset.contains("Hardware", ignoreCase = true)) {
            items += listOf(
                InventoryItem("480000000501", "Holcim Excel Portland Cement 40kg", 215.0, 240.0, 50, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000511", "Deformed Steel Bar 10mm x 6m Grade 33", 145.0, 168.0, 100, 20, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000531", "Neltex PVC Pipe Blue Water 1/2 inch x 3m", 72.0, 88.0, 50, 10, unit = "pcs", category = "Plumbing")
            )
        }
        sales.clear()
        withdrawals.clear()
        capitals.clear()
        logs.clear()
        adjustments.clear()
    }

    private val logs = mutableListOf<ActivityLog>()
    private val adjustments = mutableListOf<EcashAdjustment>()
    private var storeLogoBase64: String? = null

    override suspend fun logActivity(action: String, details: String) { logs += ActivityLog(action = action, details = details) }
    override suspend fun activityLogs(start: LocalDate, end: LocalDate): List<ActivityLog> = logs.filter { it.timestamp.toLocalDate() in start..end }.sortedByDescending { it.timestamp }
    override suspend fun getStoreLogoBase64(): String? = storeLogoBase64
    override suspend fun saveStoreLogoBase64(base64: String?) { storeLogoBase64 = base64 }
    override suspend fun recordEcashAdjustment(adjustment: EcashAdjustment) { adjustments += adjustment }
    override suspend fun ecashAdjustmentsBetween(start: LocalDate, end: LocalDate): List<EcashAdjustment> = adjustments.filter { it.adjustedAt.toLocalDate() in start..end }.sortedByDescending { it.adjustedAt }
    override suspend fun totalEwalletBalance(): Double {
        return adjustments.sumOf { if (it.wallet == "EWALLET") { if (it.type == "ADD") it.amount else -it.amount } else 0.0 }
    }
}
