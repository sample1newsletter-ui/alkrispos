package ph.alkris.pos.ui

import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import ph.alkris.pos.R

object CashSoundManager {
    fun playChimeSound(context: Context) {
        runCatching {
            val mediaPlayer = MediaPlayer.create(context, R.raw.cash_register)
            if (mediaPlayer != null) {
                mediaPlayer.setOnCompletionListener { mp ->
                    mp.release()
                }
                mediaPlayer.start()
            } else {
                playBeepSound()
            }
        }.onFailure {
            playBeepSound()
        }
    }

    fun playBeepSound() {
        runCatching {
            val toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
            toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        }
    }
}
