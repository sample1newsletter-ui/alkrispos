package ph.alkris.pos

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import ph.alkris.pos.data.AutoBackupScheduler
import ph.alkris.pos.data.LocalPosRepository
import ph.alkris.pos.ui.PosApp
import ph.alkris.pos.ui.PosViewModel

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        AutoBackupScheduler.scheduleNextWorker(applicationContext)
        setContent {
            val martRepository = LocalPosRepository(this@MainActivity, "pos_mart.db", "pos_mart_prefs")
            val ecashRepository = LocalPosRepository(this@MainActivity, "pos_ecash.db", "pos_ecash_prefs")
            val viewModel: PosViewModel = viewModel { PosViewModel(martRepository, ecashRepository) }
            PosApp(viewModel)
        }
    }
}
