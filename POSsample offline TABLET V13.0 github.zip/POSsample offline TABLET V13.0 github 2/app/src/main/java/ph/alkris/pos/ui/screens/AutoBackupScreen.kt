package ph.alkris.pos.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.components.Green

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoBackupScreen(
    viewModel: PosViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }

    var isAutoBackupEnabled by remember { mutableStateOf(prefs.getBoolean("auto_backup_on", true)) }
    var frequency by remember { mutableStateOf(prefs.getString("auto_backup_freq", "Every 4 Hours") ?: "Every 4 Hours") }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val options = listOf("Every Hour", "Every 4 Hours", "Every 12 Hours", "Daily")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Auto Backup", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = onDismiss) {
                        Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Automatic Cloud Backup", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Safeguard SQLite store databases to your chosen cloud account.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Switch(
                            checked = isAutoBackupEnabled,
                            onCheckedChange = {
                                isAutoBackupEnabled = it
                                prefs.edit().putBoolean("auto_backup_on", it).apply()
                            }
                        )
                    }

                    HorizontalDivider()

                    Text("Backup Frequency", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                    Box(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dropdownExpanded = true }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Frequency", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                Text(frequency, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            options.forEach { opt ->
                                DropdownMenuItem(
                                    text = { Text(opt) },
                                    onClick = {
                                        frequency = opt
                                        prefs.edit().putString("auto_backup_freq", opt).apply()
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Text(
                            "Transaction-Triggered Schedule: Backups run automatically at your chosen frequency whenever internet connectivity is available.",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}
