package ph.alkris.pos.ui.screens

import android.content.Context
import android.content.res.Configuration
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ph.alkris.pos.data.AppMode
import ph.alkris.pos.data.CashCapital
import ph.alkris.pos.data.CashWithdrawal
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.components.Blue
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Green
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.ui.components.Pink
import ph.alkris.pos.ui.components.ScrollbarLazyColumn
import ph.alkris.pos.ui.components.SkyBlue
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs

private data class ShiftAuditRecord(
    val timestamp: String,
    val modeName: String,
    val startingFloat: Double,
    val expectedCash: Double,
    val actualCash: Double,
    val variance: Double
) {
    val statusText: String
        get() = when {
            variance < -0.01 -> "SHORT ₱%.2f".format(abs(variance))
            variance > 0.01 -> "OVER ₱%.2f".format(variance)
            else -> "EXACT / BALANCED"
        }
}

private fun parseShiftRecord(str: String): ShiftAuditRecord? {
    val parts = str.split("|")
    if (parts.size < 6) return null
    return try {
        ShiftAuditRecord(
            timestamp = parts[0],
            modeName = parts[1],
            startingFloat = parts[2].toDouble(),
            expectedCash = parts[3].toDouble(),
            actualCash = parts[4].toDouble(),
            variance = parts[5].toDouble()
        )
    } catch (e: Exception) {
        null
    }
}

private fun serializeShiftRecord(record: ShiftAuditRecord): String {
    return "${record.timestamp}|${record.modeName}|${record.startingFloat}|${record.expectedCash}|${record.actualCash}|${record.variance}"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashDrawerScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier,
    mode: AppMode = AppMode.MART
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }
    var isShiftOpen by remember { mutableStateOf(prefs.getBoolean("shift_is_open", true)) }
    var hasHadPreviousShift by remember { mutableStateOf(prefs.getBoolean("shift_has_had_previous", false)) }

    val initialAuditSet = remember { prefs.getStringSet("shift_audit_records", emptySet()) ?: emptySet() }
    var shiftRecords by remember {
        mutableStateOf(
            initialAuditSet.mapNotNull { parseShiftRecord(it) }
                .sortedByDescending { it.timestamp }
        )
    }

    LaunchedEffect(state.cashTotal, state.ewalletBalance, state.cashHistory) {
        isShiftOpen = prefs.getBoolean("shift_is_open", true)
        hasHadPreviousShift = prefs.getBoolean("shift_has_had_previous", false)
        val currentSet = prefs.getStringSet("shift_audit_records", emptySet()) ?: emptySet()
        shiftRecords = currentSet.mapNotNull { parseShiftRecord(it) }.sortedByDescending { it.timestamp }
    }

    var showKickDrawerNotice by remember { mutableStateOf(false) }
    var showCashMovementDialog by remember { mutableStateOf(false) }
    var showOpenShiftDialog by remember { mutableStateOf(false) }
    var showCloseShiftDialog by remember { mutableStateOf(false) }
    var showEwalletTopUpDialog by remember { mutableStateOf(false) }
    var showMovementsList by remember { mutableStateOf(true) }
    var showAuditHistory by remember { mutableStateOf(true) }

    val currentShiftCash = state.cashTotal ?: 0.0
    val activeShiftStartTimeStr = prefs.getString("shift_start_time", null)
    val activeShiftStart = remember(activeShiftStartTimeStr, isShiftOpen) {
        if (!activeShiftStartTimeStr.isNullOrBlank()) {
            runCatching { LocalDateTime.parse(activeShiftStartTimeStr) }.getOrDefault(LocalDateTime.now().withHour(0).withMinute(0))
        } else {
            LocalDateTime.now().withHour(0).withMinute(0)
        }
    }

    val customStartingFloat = prefs.getFloat("shift_starting_float", -1f)
    val startingFloat = if (customStartingFloat >= 0f) customStartingFloat.toDouble() else state.cashHistoryStartingCash
    val ecashCashSales = state.transactions.filter { it.purchasedAt >= activeShiftStart && it.paymentType == "CASH" && !it.lines.any { l -> l.itemName.startsWith("Cash-Out", ignoreCase = true) } }.sumOf { it.total }
    val ecashOutPaid = state.transactions.filter { it.purchasedAt >= activeShiftStart && it.lines.any { l -> l.itemName.startsWith("Cash-Out", ignoreCase = true) } }.sumOf { it.total }
    val martCashSales = state.cashHistorySales.filter { it.purchasedAt >= activeShiftStart && it.paymentType == "CASH" }.sumOf { it.total }
    val utangCollections = state.cashHistoryDebtPayments.filter { it.paidAt >= activeShiftStart }.sumOf { it.amount }
    val manualAdditions = state.cashCapitals.filter { it.addedAt >= activeShiftStart }.sumOf { it.amount }
    val storePullouts = state.cashHistory.filter { it.withdrawnAt >= activeShiftStart }.sumOf { it.amount }

    val expectedCashInDrawer = if (mode == AppMode.ECASH) {
        startingFloat + ecashCashSales + utangCollections + manualAdditions - ecashOutPaid - storePullouts
    } else {
        startingFloat + martCashSales + utangCollections + manualAdditions - storePullouts
    }

    val dtf = remember { DateTimeFormatter.ofPattern("hh:mm a") }
    val dateTimeFormatter = remember { DateTimeFormatter.ofPattern("MM/dd/yyyy, hh:mm a") }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val activeShiftCard = @Composable {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    Text("CASH BALANCE", fontWeight = FontWeight.Bold, color = if (isDark) Color.White else MaterialTheme.colorScheme.primary)
                    val badgeColor = if (isShiftOpen) Green else Pink
                    val badgeText = if (isShiftOpen) "Opened ${LocalDateTime.now().format(dtf)}" else "Shift Closed"
                    Surface(
                        color = badgeColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            badgeText,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = badgeColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    Peso.format(expectedCashInDrawer),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (expectedCashInDrawer >= 0.0) Green else Pink
                )

                HorizontalDivider()

                if (mode == AppMode.ECASH) {
                    ShiftLineItem("Opening Starting Cash", Peso.format(startingFloat))
                    ShiftLineItem("+ E-Cash Services Cash Sales", Peso.format(ecashCashSales))
                    ShiftLineItem("+ Utang Collections", Peso.format(utangCollections))
                    ShiftLineItem("+ Cash Additions", Peso.format(manualAdditions))
                    if (ecashOutPaid > 0.0) {
                        ShiftLineItem("- E-Cash Out Cash Paid", "-${Peso.format(ecashOutPaid)}")
                    }
                    ShiftLineItem("- Expenses / Pullouts", "-${Peso.format(storePullouts)}")
                } else {
                    ShiftLineItem("Opening Starting Cash", Peso.format(startingFloat))
                    ShiftLineItem("+ Cash Sales", Peso.format(martCashSales))
                    ShiftLineItem("+ Utang Collections", Peso.format(utangCollections))
                    ShiftLineItem("+ Cash Additions", Peso.format(manualAdditions))
                    ShiftLineItem("- Expenses / Pullouts", "-${Peso.format(storePullouts)}")
                }

                HorizontalDivider()

                ShiftLineItem("Expected Cash in Drawer", Peso.format(expectedCashInDrawer), isBold = true)

                Spacer(Modifier.height(8.dp))

                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f

                val kickDrawerBtn = @Composable { m: Modifier ->
                    OutlinedButton(
                        onClick = { showKickDrawerNotice = true },
                        modifier = m.height(42.dp),
                        shape = ControlShape,
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                    ) {
                        Text(
                            "Kick\nDrawer",
                            fontSize = 11.sp,
                            lineHeight = 12.sp,
                            textAlign = TextAlign.Center,
                            color = if (isDark) Color.White else MaterialTheme.colorScheme.primary
                        )
                    }
                }

                val cashMovementBtn = @Composable { m: Modifier ->
                    Button(
                        onClick = { showCashMovementDialog = true },
                        modifier = m.height(42.dp),
                        shape = ControlShape,
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                    ) {
                        Text(
                            "Cash\nMovement",
                            fontSize = 11.sp,
                            lineHeight = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                val shiftActionButton = @Composable { m: Modifier ->
                    val buttonText = if (isShiftOpen) {
                        "Close\nShift"
                    } else if (hasHadPreviousShift) {
                        "Reopen\nShift"
                    } else {
                        "Open\nShift"
                    }

                    val buttonColor = if (isShiftOpen) {
                        Pink
                    } else if (hasHadPreviousShift) {
                        if (isDark) SkyBlue else Blue
                    } else {
                        Green
                    }

                    OutlinedButton(
                        onClick = {
                            if (isShiftOpen) {
                                showCloseShiftDialog = true
                            } else {
                                showOpenShiftDialog = true
                            }
                        },
                        modifier = m.height(42.dp),
                        shape = ControlShape,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = buttonColor),
                        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                    ) {
                        Text(
                            buttonText,
                            fontSize = 11.sp,
                            lineHeight = 12.sp,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    kickDrawerBtn(Modifier.weight(1f))
                    cashMovementBtn(Modifier.weight(1f))
                    shiftActionButton(Modifier.weight(1f))
                }
            }
        }
    }

    val cashMovementsCard = @Composable {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showMovementsList = !showMovementsList },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (mode == AppMode.ECASH) "E-Wallet Movements" else "Cash Movements (Additions / Pullouts)",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        fontSize = 13.sp
                    )
                    IconButton(
                        onClick = { showMovementsList = !showMovementsList },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (showMovementsList) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Toggle Movements List"
                        )
                    }
                }

                if (showMovementsList) {
                    if (mode == AppMode.ECASH) {
                        val ecashMovements = state.ecashAdjustments
                        if (ecashMovements.isEmpty()) {
                            Text("No E-Wallet movements recorded yet.", color = Color.Gray, style = MaterialTheme.typography.bodyMedium, fontSize = 12.sp)
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 220.dp)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                ecashMovements.forEach { adj ->
                                    val isAdd = adj.type == "ADD"
                                    val reasonText = adj.note.ifBlank { "${adj.wallet} ${adj.type}" }
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f).padding(end = 4.dp)) {
                                            Text(reasonText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(adj.adjustedAt.format(dateTimeFormatter), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                        }
                                        Text(
                                            text = if (isAdd) "+${Peso.format(adj.amount)}" else "-${Peso.format(adj.amount)}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isAdd) Green else Pink
                                        )
                                    }
                                    HorizontalDivider()
                                }
                            }
                        }
                    } else {
                        val allMovements = remember(state.cashHistory, state.cashCapitals, state.cashHistoryDebtPayments, activeShiftStart) {
                            val list = mutableListOf<Triple<String, Double, LocalDateTime>>()
                            state.cashCapitals.filter { it.addedAt >= activeShiftStart }.forEach { capital ->
                                list.add(Triple(if (capital.note.isNotBlank()) capital.note else "Capital Top-Up (In)", capital.amount, capital.addedAt))
                            }
                            state.cashHistoryDebtPayments.filter { it.paidAt >= activeShiftStart }.forEach { debtPay ->
                                list.add(Triple("Utang Collection: ${debtPay.debtorName}", debtPay.amount, debtPay.paidAt))
                            }
                            state.cashHistory.filter { it.withdrawnAt >= activeShiftStart }.forEach { withdrawal ->
                                list.add(Triple(if (withdrawal.note.isNotBlank()) withdrawal.note else "Store Expense (Out)", -withdrawal.amount, withdrawal.withdrawnAt))
                            }
                            list.sortedByDescending { it.third }
                        }

                        if (allMovements.isEmpty()) {
                            Text("No cash movements recorded yet.", color = Color.Gray, style = MaterialTheme.typography.bodyMedium, fontSize = 12.sp)
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 220.dp)
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                allMovements.forEach { (reason, amount, time) ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f).padding(end = 4.dp)) {
                                            Text(reason, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(time.format(dateTimeFormatter), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                        }
                                        Text(
                                            text = if (amount >= 0.0) "+${Peso.format(amount)}" else "-${Peso.format(-amount)}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (amount >= 0.0) Green else Pink
                                        )
                                    }
                                    HorizontalDivider()
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val shiftAuditHistoryCard = @Composable {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAuditHistory = !showAuditHistory },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Shift Audit History", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, fontSize = 13.sp)
                    IconButton(
                        onClick = { showAuditHistory = !showAuditHistory },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (showAuditHistory) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Toggle Shift Audit History"
                        )
                    }
                }

                if (showAuditHistory) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (shiftRecords.isEmpty()) {
                            Text("No previous closed shifts in history.", color = Color.Gray, style = MaterialTheme.typography.bodyMedium, fontSize = 12.sp)
                        } else {
                            shiftRecords.forEach { record ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                "${record.modeName} Shift • ${record.timestamp}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            val statusColor = when {
                                                record.variance < -0.01 -> Pink
                                                record.variance > 0.01 -> Green
                                                else -> Color.Gray
                                            }
                                            Surface(
                                                color = statusColor.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    record.statusText,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = statusColor,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        HorizontalDivider()

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Start: ${Peso.format(record.startingFloat)}", fontSize = 10.sp, color = Color.Gray)
                                            Text("Expected: ${Peso.format(record.expectedCash)}", fontSize = 10.sp, color = Color.Gray)
                                            Text("Counted: ${Peso.format(record.actualCash)}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val ewalletCard = @Composable {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    Text("E-WALLET BALANCE", fontWeight = FontWeight.Bold, color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary)
                    Surface(
                        color = Blue.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            "Active Float",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = Blue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    Peso.format(state.ewalletBalance),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (state.ewalletBalance >= 0.0) Blue else Pink
                )

                Text(
                    "Used for Cash-In, Buy-Load, and Bills Payment transactions.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )

                OutlinedButton(
                    onClick = { showEwalletTopUpDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = ControlShape
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Top Up E-Wallet Balance", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (isLandscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.Top
            ) {
                // LEFT COLUMN (FIXED AND NON-SCROLLABLE)
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (mode == AppMode.ECASH) {
                        ewalletCard()
                    } else {
                        activeShiftCard()
                    }
                }

                // RIGHT COLUMN (EXPANDABLE & INDEPENDENTLY SCROLLABLE)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    cashMovementsCard()
                    shiftAuditHistoryCard()
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (mode == AppMode.ECASH) {
                    ewalletCard()
                } else {
                    activeShiftCard()
                }
                cashMovementsCard()
                shiftAuditHistoryCard()
            }
        }
    }

    if (showKickDrawerNotice) {
        AlertDialog(
            onDismissRequest = { showKickDrawerNotice = false },
            title = { Text("Drawer Notice", fontWeight = FontWeight.Bold) },
            text = { Text("Thermal printer not connected to trigger kick drawer.") },
            confirmButton = {
                Button(onClick = { showKickDrawerNotice = false }) { Text("OK") }
            }
        )
    }

    if (showCashMovementDialog) {
        CashMovementModal(
            viewModel = viewModel,
            mode = mode,
            onDismiss = { showCashMovementDialog = false }
        )
    }

    if (showOpenShiftDialog) {
        val titleText = if (hasHadPreviousShift) "Reopen Cash Shift" else "Open Cash Shift"
        val confirmBtnText = if (hasHadPreviousShift) "Confirm Reopen Shift" else "Confirm Open Shift"
        val toastText = if (hasHadPreviousShift) "Shift reopened successfully" else "Shift opened successfully"

        val lastClosingCash = remember { prefs.getFloat("shift_last_closing_cash", -1f) }
        var startingInputText by remember {
            mutableStateOf(
                if (lastClosingCash >= 0f) lastClosingCash.toInt().toString()
                else startingFloat.toInt().toString()
            )
        }
        val newStartingAmt = startingInputText.toDoubleOrNull() ?: startingFloat

        AlertDialog(
            onDismissRequest = { showOpenShiftDialog = false },
            title = { Text(titleText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter starting cash for this shift:", style = MaterialTheme.typography.bodyMedium)

                    if (lastClosingCash >= 0f) {
                        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                        OutlinedButton(
                            onClick = { startingInputText = lastClosingCash.toInt().toString() },
                            modifier = Modifier.fillMaxWidth().height(36.dp),
                            shape = ControlShape,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Text(
                                text = "Use Last Closing Cash: ${Peso.format(lastClosingCash.toDouble())}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    OutlinedTextField(
                        value = startingInputText,
                        onValueChange = { startingInputText = it },
                        label = { Text("Starting Money (₱)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // QUICK STARTING FLOAT PRESETS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1000.0, 2000.0, 3000.0, 5000.0).forEach { preset ->
                            OutlinedButton(
                                onClick = { startingInputText = preset.toInt().toString() },
                                modifier = Modifier.weight(1f).height(34.dp),
                                shape = ControlShape,
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    text = "₱${preset.toInt()}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showOpenShiftDialog = false }) { Text("Cancel") }
                    Button(
                        onClick = {
                            showOpenShiftDialog = false
                            isShiftOpen = true
                            hasHadPreviousShift = true
                            prefs.edit()
                                .putBoolean("shift_is_open", true)
                                .putBoolean("shift_has_had_previous", true)
                                .putFloat("shift_starting_float", newStartingAmt.toFloat())
                                .putString("shift_start_time", LocalDateTime.now().toString())
                                .apply()
                            Toast.makeText(context, "$toastText (${Peso.format(newStartingAmt)})", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Green),
                        shape = ControlShape
                    ) { Text(confirmBtnText) }
                }
            }
        )
    }

    if (showCloseShiftDialog) {
        var closingInputText by remember { mutableStateOf("") }
        val actualClosingCash = closingInputText.toDoubleOrNull() ?: expectedCashInDrawer
        val variance = actualClosingCash - expectedCashInDrawer

        AlertDialog(
            onDismissRequest = { showCloseShiftDialog = false },
            title = { Text("Close Cash Shift", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter actual cash counted in drawer to finalize shift:", style = MaterialTheme.typography.bodyMedium)

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Expected Cash:", fontSize = 12.sp)
                                Text(Peso.format(expectedCashInDrawer), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Counted Cash:", fontSize = 12.sp)
                                Text(Peso.format(actualClosingCash), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            HorizontalDivider()
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Variance / Status:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                val varColor = when {
                                    variance < -0.01 -> Pink
                                    variance > 0.01 -> Green
                                    else -> Color.Gray
                                }
                                val varText = when {
                                    variance < -0.01 -> "SHORT ₱%.2f".format(abs(variance))
                                    variance > 0.01 -> "OVER ₱%.2f".format(variance)
                                    else -> "EXACT / BALANCED"
                                }
                                Text(varText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = varColor)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = closingInputText,
                        onValueChange = { closingInputText = it },
                        label = { Text("Counted Closing Cash (₱)") },
                        placeholder = { Text(Peso.format(expectedCashInDrawer)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedButton(
                        onClick = { closingInputText = expectedCashInDrawer.toInt().toString() },
                        modifier = Modifier.fillMaxWidth().height(34.dp),
                        shape = ControlShape,
                        contentPadding = PaddingValues(2.dp)
                    ) {
                        Text("Set Exact Expected (${Peso.format(expectedCashInDrawer)})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showCloseShiftDialog = false }) { Text("Cancel") }
                    Button(
                        onClick = {
                            showCloseShiftDialog = false
                            isShiftOpen = false
                            hasHadPreviousShift = true

                            val record = ShiftAuditRecord(
                                timestamp = LocalDateTime.now().format(dateTimeFormatter),
                                modeName = if (mode == AppMode.ECASH) "E-Cash" else "Mart",
                                startingFloat = startingFloat,
                                expectedCash = expectedCashInDrawer,
                                actualCash = actualClosingCash,
                                variance = variance
                            )

                            val updatedList = listOf(record) + shiftRecords
                            shiftRecords = updatedList

                            val stringSet = updatedList.map { serializeShiftRecord(it) }.toSet()
                            prefs.edit()
                                .putBoolean("shift_is_open", false)
                                .putBoolean("shift_has_had_previous", true)
                                .putFloat("shift_last_closing_cash", actualClosingCash.toFloat())
                                .putStringSet("shift_audit_records", stringSet)
                                .apply()

                            val toastMsg = if (variance < -0.01) {
                                "Shift closed (Short: ₱%.2f)".format(abs(variance))
                            } else if (variance > 0.01) {
                                "Shift closed (Over: ₱%.2f)".format(variance)
                            } else {
                                "Shift closed cleanly (Balanced)"
                            }

                            Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Pink),
                        shape = ControlShape
                    ) { Text("Confirm Close Shift") }
                }
            }
        )
    }

    if (showEwalletTopUpDialog) {
        var topUpAmountText by remember { mutableStateOf("") }
        var topUpNoteText by remember { mutableStateOf("") }
        val topUpAmt = topUpAmountText.toDoubleOrNull() ?: 0.0

        AlertDialog(
            onDismissRequest = { showEwalletTopUpDialog = false },
            title = { Text("Top Up E-Wallet Balance", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Current E-Wallet Float: ${Peso.format(state.ewalletBalance)}", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = topUpAmountText,
                        onValueChange = { topUpAmountText = it },
                        label = { Text("Amount to Add (₱)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = topUpNoteText,
                        onValueChange = { topUpNoteText = it },
                        label = { Text("Note / Ref (Optional)") },
                        singleLine = true,
                        shape = ControlShape,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // QUICK TOP-UP PRESETS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1000.0, 5000.0, 10000.0, 20000.0).forEach { preset ->
                            OutlinedButton(
                                onClick = { topUpAmountText = preset.toLong().toString() },
                                modifier = Modifier.weight(1f).height(34.dp),
                                shape = ControlShape,
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                            ) {
                                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                Text(
                                    text = "₱${preset.toInt() / 1000}k",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showEwalletTopUpDialog = false }) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (topUpAmt > 0.0) {
                                viewModel.recordEcashAdjustment("ADD", "EWALLET", topUpAmt, topUpNoteText)
                                showEwalletTopUpDialog = false
                                Toast.makeText(context, "E-Wallet topped up by ${Peso.format(topUpAmt)}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = topUpAmt > 0.0,
                        shape = ControlShape
                    ) {
                        Text("Confirm Top Up")
                    }
                }
            }
        )
    }
}

@Composable
private fun ShiftLineItem(label: String, value: String, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun CashMovementModal(
    viewModel: PosViewModel,
    mode: AppMode,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val defaultType = if (mode == AppMode.ECASH) "Capital Float (In)" else "Store Expense (Out)"
    var movementType by remember { mutableStateOf(defaultType) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var amountText by remember { mutableStateOf("") }
    var reasonText by remember { mutableStateOf("") }

    val options = if (mode == AppMode.ECASH) {
        listOf(
            "E-Wallet Float Top-Up (In)",
            "E-Wallet Float Withdrawal (Out)",
            "Cash Drawer Capital Float (In)",
            "Bank Deposit / Pullout (Out)",
            "Store Expense (Out)"
        )
    } else {
        listOf(
            "Capital Top-Up (In)",
            "Store Expense (Out)",
            "Owner Withdrawal (Out)",
            "Supplier Payment (Out)"
        )
    }

    val amount = amountText.toDoubleOrNull() ?: 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Record Cash Movement", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Movement Type", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = movementType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Type") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = ControlShape,
                        trailingIcon = {
                            IconButton(onClick = { dropdownExpanded = !dropdownExpanded }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        options.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt) },
                                onClick = {
                                    movementType = opt
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("Amount & Details", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (₱)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    label = { Text("Reason / Payee / Description") },
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    Text("Cancel", color = if (isDark) Color.White else MaterialTheme.colorScheme.primary)
                }
                Button(
                    onClick = {
                        if (mode == AppMode.ECASH) {
                            when (movementType) {
                                "E-Wallet Float Top-Up (In)" -> {
                                    viewModel.recordEcashAdjustment("ADD", "EWALLET", amount, reasonText, onSuccess = { onDismiss() }, onError = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() })
                                }
                                "E-Wallet Float Withdrawal (Out)" -> {
                                    viewModel.recordEcashAdjustment("MINUS", "EWALLET", amount, reasonText, onSuccess = { onDismiss() }, onError = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() })
                                }
                                "Cash Drawer Capital Float (In)" -> {
                                    viewModel.recordCashCapital(amount)
                                    onDismiss()
                                }
                                else -> {
                                    viewModel.recordCashWithdrawal(amount, "$movementType - $reasonText", onSuccess = { onDismiss() }, onError = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() })
                                }
                            }
                        } else {
                            if (movementType.contains("(In)")) {
                                viewModel.recordCashCapital(amount)
                                onDismiss()
                            } else {
                                viewModel.recordCashWithdrawal(amount, "$movementType - $reasonText", onSuccess = { onDismiss() }, onError = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() })
                            }
                        }
                    },
                    enabled = amount > 0.0,
                    shape = ControlShape
                ) { Text("Save", fontWeight = FontWeight.Bold) }
            }
        }
    )
}
