package ph.alkris.pos.ui.screens

import ph.alkris.pos.ui.components.CustomDateRangeDialog
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import android.content.res.Configuration
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.input.PasswordVisualTransformation
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.formattedReceiptCode
import ph.alkris.pos.data.Debtor
import android.content.Context
import ph.alkris.pos.ui.OpenShiftModalDialog
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.CashSoundManager
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.ui.components.Blue
import ph.alkris.pos.ui.components.Pink
import ph.alkris.pos.ui.components.SkyBlue
import androidx.compose.ui.graphics.luminance
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.dialogs.DebtorsDialog
import ph.alkris.pos.ui.components.ScrollbarLazyColumn
import ph.alkris.pos.ui.PdfExporter
import ph.alkris.pos.ui.ThermalPrinterManager
import ph.alkris.pos.ui.ReceiptImageExporter
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EcashReportsScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var start by remember { mutableStateOf(LocalDate.now()) }
    var end by remember { mutableStateOf(LocalDate.now()) }
    var showCustomDateRangeDialog by remember { mutableStateOf(false) }
    var presetMenuExpanded by remember { mutableStateOf(false) }

    val dateRangeText = remember(start, end) {
        val dtf = java.time.format.DateTimeFormatter.ofPattern("MMM dd, yyyy")
        if (start == end) {
            if (start == LocalDate.now()) "Today (${start.format(dtf)})"
            else if (start == LocalDate.now().minusDays(1)) "Yesterday (${start.format(dtf)})"
            else start.format(dtf)
        } else {
            "${start.format(dtf)} – ${end.format(dtf)}"
        }
    }

    LaunchedEffect(start, end) {
        viewModel.loadSummary(start, end)
    }

    val sales = state.currentReportSales

    val serviceStats = remember(sales) {
        val map = mutableMapOf<String, Triple<Double, Double, Int>>(
            "Cash-In" to Triple(0.0, 0.0, 0),
            "Cash-Out" to Triple(0.0, 0.0, 0),
            "Buy-Load" to Triple(0.0, 0.0, 0),
            "Bills Payment" to Triple(0.0, 0.0, 0),
            "Printing" to Triple(0.0, 0.0, 0)
        )
        sales.forEach { sale ->
            sale.lines.forEach { line ->
                val name = line.itemName
                val type = when {
                    name.startsWith("Cash-In", ignoreCase = true) -> "Cash-In"
                    name.startsWith("Cash-Out", ignoreCase = true) -> "Cash-Out"
                    name.startsWith("Buy-Load", ignoreCase = true) -> "Buy-Load"
                    name.startsWith("Bills Payment", ignoreCase = true) -> "Bills Payment"
                    name.startsWith("Printing", ignoreCase = true) -> "Printing"
                    else -> "Other"
                }
                if (map.containsKey(type)) {
                    val principalStr = name.substringAfter(" - ₱", "").substringBefore(" [Ref:", "")
                    val principal = if (type == "Printing") 0.0 else (principalStr.toDoubleOrNull() ?: line.unitCost)
                    val profit = if (type == "Cash-Out" || type == "Printing") line.subtotal else (line.subtotal - line.costTotal).coerceAtLeast(0.0)
                    val current = map[type]!!
                    map[type] = Triple(current.first + principal, current.second + profit, current.third + 1)
                }
            }
        }
        map
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                PdfExporter.exportEcashReport(stream, state.storeName, start, end, serviceStats)
                Toast.makeText(context, "Ecash Report PDF exported", Toast.LENGTH_SHORT).show()
            }
            viewModel.logActivity("PRINT", "Saved/Exported Ecash Report PDF for $start to $end")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            ThermalPrinterManager.printEcashReport(context, start, end, serviceStats, state.storeName)
        }
    }

    val totalMoneyVolume = serviceStats.entries.filter { it.key != "Printing" }.sumOf { it.value.first }
    val totalPrintingCount = serviceStats["Printing"]?.third ?: 0
    val totalProfitAll = serviceStats.values.sumOf { it.second }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                InventoryAction(Icons.Default.PictureAsPdf, "Save PDF", if (isDark) Color.White else Blue) {
                    exportLauncher.launch("Ecash_Report_${start}_to_${end}.pdf")
                }
                InventoryAction(Icons.Default.Print, "Print", if (isDark) Color.White else Color.Unspecified) {
                    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
                    } else {
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                    }
                    val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                    if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
                    else ThermalPrinterManager.printEcashReport(context, start, end, serviceStats, state.storeName)
                }

                Box {
                    InventoryAction(Icons.Default.DateRange, "Date Range", if (isDark) Color.White else Color.Unspecified) {
                        presetMenuExpanded = true
                    }
                    DropdownMenu(
                        expanded = presetMenuExpanded,
                        onDismissRequest = { presetMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Today", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now()
                                end = start
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Yesterday", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().minusDays(1)
                                end = start
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("This Week", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().minusDays((LocalDate.now().dayOfWeek.value - 1).toLong())
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("This Month", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().withDayOfMonth(1)
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Last Month", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                val currentMonth = LocalDate.now().withDayOfMonth(1)
                                end = currentMonth.minusDays(1)
                                start = end.withDayOfMonth(1)
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Last 30 Days", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.now().minusDays(30)
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("All Time", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                start = LocalDate.of(2000, 1, 1)
                                end = LocalDate.now()
                                presetMenuExpanded = false
                                viewModel.loadSummary(start, end)
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Custom Date Range...", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
                            onClick = {
                                presetMenuExpanded = false
                                showCustomDateRangeDialog = true
                            }
                        )
                    }
                }
            }

            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            val dateTextColor = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface

            OutlinedButton(
                onClick = { showCustomDateRangeDialog = true },
                modifier = Modifier.weight(1f).height(40.dp),
                shape = ControlShape,
                contentPadding = PaddingValues(horizontal = 10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date Range", tint = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Text(
                        text = dateRangeText,
                        color = dateTextColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

        val serviceListContent = @Composable {
            val statsList = remember(serviceStats) { serviceStats.entries.toList() }
            val chunkedStats = remember(statsList) { statsList.chunked(2) }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                chunkedStats.forEach { rowPair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        rowPair.forEach { (serviceName, stats) ->
                            val principal = stats.first
                            val profit = stats.second
                            val count = stats.third
                            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                            Card(
                                modifier = Modifier.weight(1f),
                                elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 2.dp else 0.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                    val titleColor = if (isDark) Color.White else MaterialTheme.colorScheme.primary
                                    val profitColor = if (isDark) Color(0xFF66BB6A) else Color(0xFF1B5E20)
                                    Text(
                                        text = serviceName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = titleColor
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(if (serviceName == "Printing") "Txns:" else "Volume:", color = Color.Gray, fontSize = 10.sp)
                                        Text(if (serviceName == "Printing") "$count txns" else Peso.format(principal), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Profit:", color = Color.Gray, fontSize = 10.sp)
                                        Text(Peso.format(profit), color = profitColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                        if (rowPair.size == 1) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        val summaryCardContent = @Composable {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Summary of Services",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Money Processed:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(Peso.format(totalMoneyVolume), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Printing Transactions:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("$totalPrintingCount txns", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                        val profitColor = if (isDark) Color(0xFF66BB6A) else Color(0xFF1B5E20)
                        Text("Total Service Fees (Profit):", fontWeight = FontWeight.Bold, color = profitColor, fontSize = 13.sp)
                        Text(Peso.format(totalProfitAll), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = profitColor)
                    }
                }
            }
        }

        if (isLandscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                ) {
                    serviceListContent()
                }
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    summaryCardContent()
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                serviceListContent()
                summaryCardContent()
            }
        }

        if (showCustomDateRangeDialog) {
            CustomDateRangeDialog(
                initialStart = start,
                initialEnd = end,
                onConfirm = { newStart, newEnd ->
                    start = newStart
                    end = newEnd
                    viewModel.loadSummary(start, end)
                },
                onDismiss = { showCustomDateRangeDialog = false }
            )
        }
    }
}

@Composable
fun EcashServicesScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    var serviceType by rememberSaveable { mutableStateOf("Cash-In") }
    var customerName by rememberSaveable { mutableStateOf("") }
    var customerAddress by rememberSaveable { mutableStateOf("") }
    var customServiceDetails by rememberSaveable { mutableStateOf("") }
    var contactNumber by rememberSaveable { mutableStateOf("") }
    var referenceNumber by rememberSaveable { mutableStateOf("") }
    var principalText by rememberSaveable { mutableStateOf("") }
    var serviceChargeText by rememberSaveable { mutableStateOf("5") }
    var cashReceivedText by rememberSaveable { mutableStateOf("") }
    var refError by rememberSaveable { mutableStateOf(false) }
    var nameError by rememberSaveable { mutableStateOf(false) }
    var isRefQwertyKeyboard by rememberSaveable { mutableStateOf(false) }
    var isNameQwertyKeyboard by rememberSaveable { mutableStateOf(false) }

    var completedSaleInfo by remember { mutableStateOf<Pair<Sale, Double>?>(null) }
    var showShiftRedirectDialog by remember { mutableStateOf(false) }

    val isPrinting = serviceType == "Printing"
    val isCashOut = serviceType == "Cash-Out"
    val principal = if (isPrinting) 0.0 else (principalText.toDoubleOrNull() ?: 0.0)
    val serviceCharge = serviceChargeText.toDoubleOrNull() ?: 0.0
    val rawCashReceived = cashReceivedText.toDoubleOrNull() ?: 0.0

    val totalToCollect = if (isCashOut || isPrinting) serviceCharge else (principal + serviceCharge)

    val displayCashReceived = if (cashReceivedText.isBlank()) 0.0 else rawCashReceived
    val cashToGiveCustomer = if (isCashOut) (principal - serviceCharge + rawCashReceived).coerceAtLeast(0.0) else 0.0

    val change = if (isCashOut) cashToGiveCustomer else (displayCashReceived - totalToCollect).coerceAtLeast(0.0)

    val isProcessEnabled = if (isCashOut) {
        principal > 0.0 && referenceNumber.isNotBlank() && principal >= serviceCharge
    } else if (isPrinting) {
        serviceCharge > 0.0 && customServiceDetails.isNotBlank() && cashReceivedText.isNotBlank() && rawCashReceived >= serviceCharge
    } else {
        principal > 0.0 && referenceNumber.isNotBlank() && cashReceivedText.isNotBlank() && rawCashReceived >= totalToCollect
    }

    val profit = serviceCharge
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val cardPadding = if (isLandscape) 10.dp else 16.dp
    val itemSpacing = if (isLandscape) 8.dp else 16.dp

    val printPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            completedSaleInfo?.let { (sale, _) ->
                ThermalPrinterManager.print(context, sale, state.storeName)
                viewModel.logActivity("PRINT", "Printed ecash receipt for ${sale.id}")
            }
        }
    }

    val detailsInputCard = @Composable {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(cardPadding),
                    verticalArrangement = Arrangement.spacedBy(itemSpacing)
                ) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    Text(
                        text = "$serviceType Details",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isDark) 13.sp else 15.sp,
                        color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Customer Name (Optional)", fontSize = 11.sp) },
                        textStyle = TextStyle(fontSize = 12.sp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (isNameQwertyKeyboard) KeyboardType.Text else KeyboardType.Number
                        ),
                        trailingIcon = {
                            TextButton(
                                onClick = { isNameQwertyKeyboard = !isNameQwertyKeyboard },
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                Text(
                                    if (isNameQwertyKeyboard) "123" else "ABC",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    )
                    if (nameError) {
                        Text("Customer name is required for Utang", color = MaterialTheme.colorScheme.error, fontSize = 10.sp)
                    }

                    OutlinedTextField(
                        value = contactNumber,
                        onValueChange = { contactNumber = it },
                        label = { Text("Contact Number (Optional)", fontSize = 11.sp) },
                        textStyle = TextStyle(fontSize = 12.sp),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )

                    if (!isPrinting) {
                        OutlinedTextField(
                            value = referenceNumber,
                            onValueChange = {
                                referenceNumber = it
                                if (it.isNotBlank()) refError = false
                            },
                            label = { Text("Reference Number * (Required)", fontSize = 11.sp) },
                            textStyle = TextStyle(fontSize = 12.sp),
                            modifier = Modifier.fillMaxWidth(),
                            isError = refError,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = if (isRefQwertyKeyboard) KeyboardType.Text else KeyboardType.Number
                            ),
                            trailingIcon = {
                                IconButton(onClick = { isRefQwertyKeyboard = !isRefQwertyKeyboard }) {
                                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                    Text(
                                        text = if (isRefQwertyKeyboard) "123" else "ABC",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        )
                        if (refError) {
                            Text("Reference number is required", color = MaterialTheme.colorScheme.error, fontSize = 10.sp)
                        }
                    }

                    if (isPrinting) {
                        OutlinedTextField(
                            value = customServiceDetails,
                            onValueChange = { customServiceDetails = it },
                            label = { Text("Printing Details / Description * (Required)", fontSize = 11.sp) },
                            placeholder = { Text("e.g. 5 pages Colored, 2 pages Short", fontSize = 11.sp) },
                            textStyle = TextStyle(fontSize = 12.sp),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    } else {
                        OutlinedTextField(
                            value = principalText,
                            onValueChange = { principalText = it },
                            label = { Text(when (serviceType) {
                                "Buy-Load" -> "Load Amount (₱)"
                                "Bills Payment" -> "Bill Amount (₱)"
                                else -> "Principal Amount (₱)"
                            }, fontSize = 11.sp) },
                            textStyle = TextStyle(fontSize = 12.sp),
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = serviceChargeText,
                        onValueChange = { serviceChargeText = it },
                        label = { Text(if (isPrinting) "Printing Fee (₱)" else "Service Charge (₱)", fontSize = 11.sp) },
                        textStyle = TextStyle(fontSize = 12.sp),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("5", "10", "15", "20").forEach { fee ->
                            OutlinedButton(
                                onClick = { serviceChargeText = fee },
                                modifier = Modifier.weight(1f).height(32.dp),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                            ) {
                                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                Text(
                                    text = "₱$fee",
                                    color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = cashReceivedText,
                        onValueChange = { cashReceivedText = it },
                        label = { Text("Customer Cash (₱)", fontSize = 11.sp) },
                        textStyle = TextStyle(fontSize = 12.sp),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )

                    // QUICK CASH PRESET BUTTONS (EXACT, NEXT HUNDRED, ₱500, ₱1,000)
                    val nextHundred = (ceil((totalToCollect + 0.01) / 100.0) * 100.0).coerceAtLeast(100.0)
                    val ecashCashPresets = listOf(
                        "Exact" to totalToCollect,
                        "${Peso.format(nextHundred).removeSuffix(".00")}" to nextHundred,
                        "₱500" to 500.0,
                        "₱1,000" to 1000.0
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ecashCashPresets.forEach { (lbl, valAmt) ->
                            OutlinedButton(
                                onClick = {
                                    cashReceivedText = if (valAmt % 1.0 == 0.0) valAmt.toLong().toString() else valAmt.toString()
                                },
                                modifier = Modifier.weight(1f).height(32.dp),
                                shape = ControlShape,
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                            ) {
                                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                Text(
                                    text = lbl,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        val summaryCard = @Composable {
            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            val labelFontSize = if (isDark) 11.sp else 13.sp
            val valueFontSize = if (isDark) 12.sp else 14.sp
            val headerFontSize = if (isDark) 13.sp else 15.sp

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(if (isDark) 12.dp else 16.dp),
                    verticalArrangement = Arrangement.spacedBy(if (isDark) 6.dp else 8.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Service Type:", fontSize = labelFontSize)
                        Text(serviceType, fontWeight = FontWeight.Bold, fontSize = valueFontSize)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Payment Method:", fontSize = labelFontSize)
                        val methodColor = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                        Text("Cash", fontWeight = FontWeight.Bold, color = methodColor, fontSize = valueFontSize)
                    }
                    if (isPrinting) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            val profitColor = if (isDark) Color(0xFF66BB6A) else Color(0xFF1B5E20)
                            Text("Printing Fee / Charge:", color = profitColor, fontWeight = FontWeight.Bold, fontSize = labelFontSize)
                            Text(Peso.format(profit), color = profitColor, fontWeight = FontWeight.Bold, fontSize = valueFontSize)
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Principal / Amount:", fontSize = labelFontSize)
                            Text(Peso.format(principal), fontSize = valueFontSize)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            val profitColor = if (isDark) Color(0xFF66BB6A) else Color(0xFF1B5E20)
                            Text("Service Fee (Your Profit):", color = profitColor, fontWeight = FontWeight.Bold, fontSize = labelFontSize)
                            Text(Peso.format(profit), color = profitColor, fontWeight = FontWeight.Bold, fontSize = valueFontSize)
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Transaction Value:", fontWeight = FontWeight.Bold, fontSize = headerFontSize)
                        val totalColor = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary
                        Text(Peso.format(totalToCollect), fontWeight = FontWeight.Bold, fontSize = headerFontSize, color = totalColor)
                    }
                    if (isCashOut) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Customer Cash (Fee):", fontWeight = FontWeight.Bold, fontSize = labelFontSize)
                            Text(Peso.format(rawCashReceived), fontWeight = FontWeight.Bold, fontSize = valueFontSize)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            val cashToGiveColor = if (isDark) SkyBlue else Blue
                            Text("Cash to Give Customer:", fontWeight = FontWeight.Bold, color = cashToGiveColor, fontSize = headerFontSize)
                            Text(Peso.format(cashToGiveCustomer), fontWeight = FontWeight.Bold, color = cashToGiveColor, fontSize = headerFontSize)
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Cash Received:", fontWeight = FontWeight.Bold, fontSize = labelFontSize)
                            Text(Peso.format(displayCashReceived), fontWeight = FontWeight.Bold, fontSize = valueFontSize)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            val changeColor = if (isDark) SkyBlue else Blue
                            Text("Change:", fontWeight = FontWeight.Bold, color = changeColor, fontSize = headerFontSize)
                            Text(Peso.format(change), fontWeight = FontWeight.Bold, color = changeColor, fontSize = headerFontSize)
                        }
                    }
                }
            }
        }

        val processButton = @Composable {
            Button(
                onClick = {
                    val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
                    val isShiftOpen = prefs.getBoolean("shift_is_open", true)
                    if (!isShiftOpen) {
                        showShiftRedirectDialog = true
                        return@Button
                    }

                    if (isPrinting && customServiceDetails.isBlank()) {
                        Toast.makeText(context, "Printing details/description is required", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (!isPrinting && referenceNumber.isBlank()) {
                        refError = true
                        Toast.makeText(context, "Reference number is required", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (!isPrinting && principal <= 0.0) {
                        Toast.makeText(context, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (!isCashOut && displayCashReceived < totalToCollect) {
                        Toast.makeText(context, "Cash received is less than total to collect", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (isCashOut && principal < serviceCharge) {
                        Toast.makeText(context, "Principal amount must be at least the service fee", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    viewModel.recordEcashTransaction(
                        serviceType = serviceType,
                        customerName = customerName,
                        customerAddress = customerAddress,
                        contactNumber = contactNumber,
                        referenceNumber = referenceNumber,
                        serviceDetails = customServiceDetails,
                        principal = principal,
                        serviceCharge = serviceCharge,
                        cashReceived = displayCashReceived,
                        paymentType = "CASH",
                        signature = null,
                        pin = null,
                        onSuccess = { sale, chg ->
                            CashSoundManager.playChimeSound(context)
                            completedSaleInfo = sale to chg
                            customerName = ""
                            customerAddress = ""
                            customServiceDetails = ""
                            referenceNumber = ""
                            contactNumber = ""
                            principalText = ""
                            cashReceivedText = ""
                        },
                        onError = { err ->
                            Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                        }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                enabled = isProcessEnabled
            ) {
                Text(
                    "Process $serviceType",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(if (isLandscape) 8.dp else 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val serviceOptions = listOf(
                    "In" to "Cash-In",
                    "Out" to "Cash-Out",
                    "Load" to "Buy-Load",
                    "Bills" to "Bills Payment",
                    "Print" to "Printing"
                )
                serviceOptions.forEach { (label, type) ->
                    val selected = serviceType == type
                    Button(
                        onClick = { serviceType = type },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (isLandscape) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                    ) {
                        detailsInputCard()
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        summaryCard()
                        processButton()
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    detailsInputCard()
                    summaryCard()
                    processButton()
                    Spacer(Modifier.height(80.dp))
                }
            }
        }

        completedSaleInfo?.let { (sale, changeAmt) ->
        val isCompletedCashOut = sale.lines.any { it.itemName.startsWith("Cash-Out", ignoreCase = true) }
        AlertDialog(
            onDismissRequest = { completedSaleInfo = null },
            title = { Text("Service Completed", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Receipt Code: ${sale.formattedReceiptCode(state.storeName)}")
                    if (isCompletedCashOut) {
                        Text("Service Fee: ${Peso.format(sale.total)}")
                        Text(
                            "Cash to Give Customer: ${Peso.format(changeAmt)}",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            style = MaterialTheme.typography.titleLarge
                        )
                    } else {
                        Text("Total Amount: ${Peso.format(sale.total)}")
                        Text("Cash Received: ${Peso.format(sale.cashReceived)}")
                        Text(
                            "Change: ${Peso.format(changeAmt)}",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    ReceiptImageExporter.saveReceiptToGallery(context, sale, state.storeName)
                                }
                                .padding(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Image,
                                contentDescription = "E-receipt",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text("E-receipt", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
                                    } else {
                                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                                    }
                                    val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                                    if (missing.isNotEmpty()) printPermissionLauncher.launch(missing.toTypedArray())
                                    else {
                                        ThermalPrinterManager.print(context, sale, state.storeName)
                                        viewModel.logActivity("PRINT", "Printed ecash receipt for ${sale.id}")
                                    }
                                }
                                .padding(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Print,
                                contentDescription = "Print",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text("Print", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { completedSaleInfo = null }
                ) {
                    Text("Done")
                }
            }
        )
    }

    if (showShiftRedirectDialog) {
        OpenShiftModalDialog(
            onDismiss = { showShiftRedirectDialog = false },
            onConfirmed = { showShiftRedirectDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletsHistoryDialog(
    viewModel: PosViewModel,
    onDismiss: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var historyStart by remember { mutableStateOf(LocalDate.now().minusDays(30)) }
    var historyEnd by remember { mutableStateOf(LocalDate.now()) }
    var showCustomDateRangeDialog by remember { mutableStateOf(false) }
    var historyPresetMenuExpanded by remember { mutableStateOf(false) }

    val dateRangeText = remember(historyStart, historyEnd) {
        val dtf = java.time.format.DateTimeFormatter.ofPattern("MMM dd, yyyy")
        if (historyStart == historyEnd) {
            if (historyStart == LocalDate.now()) "Today (${historyStart.format(dtf)})"
            else if (historyStart == LocalDate.now().minusDays(1)) "Yesterday (${historyStart.format(dtf)})"
            else historyStart.format(dtf)
        } else {
            "${historyStart.format(dtf)} – ${historyEnd.format(dtf)}"
        }
    }

    LaunchedEffect(historyStart, historyEnd) {
        viewModel.loadEcashAdjustments(historyStart, historyEnd)
    }

    val adjustments = state.ecashAdjustments

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                PdfExporter.exportWalletsHistoryReport(stream, state.storeName, historyStart, historyEnd, adjustments)
                Toast.makeText(context, "Wallets History PDF exported", Toast.LENGTH_SHORT).show()
            }
            viewModel.logActivity("PRINT", "Saved/Exported Wallets History PDF for $historyStart to $historyEnd")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            ThermalPrinterManager.printWalletsHistoryReport(context, historyStart, historyEnd, adjustments, state.storeName)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Wallets History", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    IconButton(onClick = { exportLauncher.launch("Wallets_History_${historyStart}_to_${historyEnd}.pdf") }) {
                        Icon(Icons.Default.PictureAsPdf, "Save PDF", tint = if (isDark) Color.White else Blue)
                    }
                    IconButton(onClick = {
                        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
                        } else {
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                        }
                        val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
                        else ThermalPrinterManager.printWalletsHistoryReport(context, historyStart, historyEnd, adjustments, state.storeName)
                    }) {
                        Icon(Icons.Default.Print, "Print", tint = if (isDark) Color.White else Color.Unspecified)
                    }
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().heightIn(max = 450.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                        InventoryAction(Icons.Default.DateRange, "Date Range", if (isDark) Color.White else Color.Unspecified) {
                            historyPresetMenuExpanded = true
                        }
                        DropdownMenu(
                            expanded = historyPresetMenuExpanded,
                            onDismissRequest = { historyPresetMenuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Today", fontWeight = FontWeight.SemiBold) },
                                onClick = {
                                    historyStart = LocalDate.now()
                                    historyEnd = historyStart
                                    historyPresetMenuExpanded = false
                                    viewModel.loadEcashAdjustments(historyStart, historyEnd)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Yesterday", fontWeight = FontWeight.SemiBold) },
                                onClick = {
                                    historyStart = LocalDate.now().minusDays(1)
                                    historyEnd = historyStart
                                    historyPresetMenuExpanded = false
                                    viewModel.loadEcashAdjustments(historyStart, historyEnd)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("This Week", fontWeight = FontWeight.SemiBold) },
                                onClick = {
                                    historyStart = LocalDate.now().minusDays((LocalDate.now().dayOfWeek.value - 1).toLong())
                                    historyEnd = LocalDate.now()
                                    historyPresetMenuExpanded = false
                                    viewModel.loadEcashAdjustments(historyStart, historyEnd)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("This Month", fontWeight = FontWeight.SemiBold) },
                                onClick = {
                                    historyStart = LocalDate.now().withDayOfMonth(1)
                                    historyEnd = LocalDate.now()
                                    historyPresetMenuExpanded = false
                                    viewModel.loadEcashAdjustments(historyStart, historyEnd)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Last Month", fontWeight = FontWeight.SemiBold) },
                                onClick = {
                                    val currentMonth = LocalDate.now().withDayOfMonth(1)
                                    historyEnd = currentMonth.minusDays(1)
                                    historyStart = historyEnd.withDayOfMonth(1)
                                    historyPresetMenuExpanded = false
                                    viewModel.loadEcashAdjustments(historyStart, historyEnd)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Last 30 Days", fontWeight = FontWeight.SemiBold) },
                                onClick = {
                                    historyStart = LocalDate.now().minusDays(30)
                                    historyEnd = LocalDate.now()
                                    historyPresetMenuExpanded = false
                                    viewModel.loadEcashAdjustments(historyStart, historyEnd)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("All Time", fontWeight = FontWeight.SemiBold) },
                                onClick = {
                                    historyStart = LocalDate.of(2000, 1, 1)
                                    historyEnd = LocalDate.now()
                                    historyPresetMenuExpanded = false
                                    viewModel.loadEcashAdjustments(historyStart, historyEnd)
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Custom Date Range...", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
                                onClick = {
                                    historyPresetMenuExpanded = false
                                    showCustomDateRangeDialog = true
                                }
                            )
                        }
                    }

                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    val dateTextColor = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface

                    OutlinedButton(
                        onClick = { showCustomDateRangeDialog = true },
                        modifier = Modifier.weight(1f).height(40.dp),
                        shape = ControlShape,
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date Range", tint = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Text(
                                text = dateRangeText,
                                color = dateTextColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (adjustments.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No adjustments recorded for selected dates", color = Color.Gray)
                    }
                } else {
                    ScrollbarLazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                        items(adjustments.size, key = { index -> adjustments[index].id }) { index ->
                            val adj = adjustments[index]
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${adj.wallet} - ${adj.type}", fontWeight = FontWeight.Bold, color = if (adj.type == "ADD") Color(0xFF1B5E20) else Pink)
                                        Text(Peso.format(adj.amount), fontWeight = FontWeight.Bold)
                                    }
                                    if (adj.note.isNotBlank()) {
                                        Text("Note: ${adj.note}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                    }
                                    Text(adj.adjustedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )

    if (showCustomDateRangeDialog) {
        CustomDateRangeDialog(
            initialStart = historyStart,
            initialEnd = historyEnd,
            onConfirm = { newStart, newEnd ->
                historyStart = newStart
                historyEnd = newEnd
                viewModel.loadEcashAdjustments(historyStart, historyEnd)
            },
            onDismiss = { showCustomDateRangeDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletsDialog(
    cashTotal: Double,
    ewalletBalance: Double,
    transactions: List<Sale>,
    viewModel: PosViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var showAdjustmentDialog by remember { mutableStateOf<Pair<String, String>?>(null) } // Pair(Wallet, Type) -> Wallet: "CASH" / "EWALLET", Type: "ADD" / "MINUS"
    var showHistoryDialog by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Wallets Summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 500.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Account Balance Overview", color = Color.Gray, style = MaterialTheme.typography.bodySmall)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Ewallet Column
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("E-Wallet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(8.dp))
                            Text("Balance:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(Peso.format(ewalletBalance), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Spacer(Modifier.height(12.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = { showAdjustmentDialog = "EWALLET" to "ADD" },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(2.dp)
                                ) { Text("+ Add", fontSize = 11.sp) }
                                OutlinedButton(
                                    onClick = { showAdjustmentDialog = "EWALLET" to "MINUS" },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(2.dp)
                                ) { Text("- Minus", fontSize = 11.sp) }
                            }
                        }
                    }

                    // Cash Column
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Cash", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            Text("Drawer:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(Peso.format(cashTotal), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, color = Color(0xFF0D47A1))
                            Spacer(Modifier.height(12.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = { showAdjustmentDialog = "CASH" to "ADD" },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(2.dp)
                                ) { Text("+ Add", fontSize = 11.sp) }
                                OutlinedButton(
                                    onClick = { showAdjustmentDialog = "CASH" to "MINUS" },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(2.dp)
                                ) { Text("- Minus", fontSize = 11.sp) }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        viewModel.loadEcashAdjustments(LocalDate.now().minusDays(30), LocalDate.now())
                        showHistoryDialog = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("View Wallets History")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { viewModel.clearCash(); onDismiss() }) { Text("Close") }
        }
    )

    showAdjustmentDialog?.let { (wallet, type) ->
        var amountStr by remember { mutableStateOf("") }
        var noteStr by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdjustmentDialog = null },
            title = { Text("$type $wallet Funds", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("Amount (₱)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = noteStr,
                        onValueChange = { noteStr = it },
                        label = { Text("Note / Reason (Optional)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showAdjustmentDialog = null }) { Text("Cancel") }
                    TextButton(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            if (amt > 0.0) {
                                viewModel.recordEcashAdjustment(type = type, wallet = wallet, amount = amt, note = noteStr)
                                showAdjustmentDialog = null
                            } else {
                                Toast.makeText(context, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) { Text("Confirm") }
                }
            }
        )
    }

    if (showHistoryDialog) {
        WalletsHistoryDialog(
            viewModel = viewModel,
            onDismiss = { showHistoryDialog = false }
        )
    }
}
