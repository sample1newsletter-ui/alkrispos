package ph.alkris.pos.ui.screens

import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Pink

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

@Composable
fun LoginScreen(
    viewModel: PosViewModel,
    pinError: String?,
    storeName: String,
    onTriggerBiometrics: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }
    val isBiometricEnabled = remember { prefs.getBoolean("enable_biometrics", true) }

    var pin by remember { mutableStateOf("") }
    var useKeyboard by remember { mutableStateOf(false) }
    var showFaceNotRecognizedDialog by remember { mutableStateOf(false) }

    fun onKeyClick(key: String) {
        if (key == "C") {
            pin = ""
        } else if (key == "DEL") {
            if (pin.isNotEmpty()) pin = pin.dropLast(1)
        } else {
            if (pin.length < 8) pin += key
        }
        if (pin.length >= 4) {
            viewModel.login(pin)
        }
    }

    Scaffold(
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "FOR INTERNAL BOOKKEEPING ONLY",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                    Text(
                        text = "NON-BIR ACCREDITED • NOT AN OFFICIAL TAX RECEIPT",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Top Header
            Text(
                text = storeName.ifBlank { "AlKris Sari-sari Store" },
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // PIN Dots or Input
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (pin.isEmpty()) "Enter PIN" else "PIN Entered: ${"•".repeat(pin.length)}",
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (pinError != null) Pink else MaterialTheme.colorScheme.onSurface
                )

                pinError?.let {
                    Text(it, color = Pink, style = MaterialTheme.typography.bodySmall)
                }

                if (useKeyboard) {
                    OutlinedTextField(
                        value = pin,
                        onValueChange = {
                            if (it.length <= 8) {
                                pin = it
                                if (it.length >= 4) viewModel.login(it)
                            }
                        },
                        label = { Text("PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        shape = ControlShape,
                        modifier = Modifier.width(220.dp)
                    )
                } else {
                    // Keypad Grid 1-9, C, 0, DEL
                    val keys = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("C", "0", "DEL")
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        keys.forEach { row ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                row.forEach { key ->
                                    KeypadButton(key = key, onClick = { onKeyClick(key) })
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = { useKeyboard = !useKeyboard }) {
                    Text(
                        text = if (useKeyboard) "Use Keypad" else "Use Keyboard",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (isBiometricEnabled) {
                    OutlinedButton(
                        onClick = {
                            onTriggerBiometrics()
                        },
                        modifier = Modifier.width(240.dp),
                        shape = ControlShape
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Face ID / Touch ID",
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }

    if (showFaceNotRecognizedDialog) {
        AlertDialog(
            onDismissRequest = { showFaceNotRecognizedDialog = false },
            title = { Text("Face Not Recognized", fontWeight = FontWeight.Bold) },
            text = { Text("Try Face ID again or use your PIN to sign in.") },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showFaceNotRecognizedDialog = false }) {
                        Text("Cancel")
                    }
                    Button(onClick = {
                        showFaceNotRecognizedDialog = false
                        onTriggerBiometrics()
                    }) {
                        Text("Try Face ID Again")
                    }
                }
            }
        )
    }
}

@Composable
private fun KeypadButton(key: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier.size(68.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (key == "DEL") {
                Icon(Icons.Default.Backspace, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text(
                    text = key,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = if (key == "C") Pink else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
