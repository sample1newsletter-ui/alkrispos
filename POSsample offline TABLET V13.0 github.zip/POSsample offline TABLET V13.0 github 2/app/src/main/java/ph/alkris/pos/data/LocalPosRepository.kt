package ph.alkris.pos.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.io.InputStream
import java.io.OutputStream
import java.io.File
import java.util.UUID
import android.util.Base64
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.round

class LocalPosRepository(
    context: Context,
    private val dbName: String = "pos_local.db",
    private val prefsName: String = "pos_prefs"
) : PosRepository {
    private val appContext = context.applicationContext
    private val database = PosDatabase(appContext, dbName, prefsName)
    private val dateTimeFormat = DateTimeFormatter.ISO_LOCAL_DATE_TIME
    private val repoDbType = if (dbName.contains("ecash", ignoreCase = true)) "ECASH" else "MART"

    private fun ensureDbTypeMarker(db: SQLiteDatabase) {
        runCatching {
            val values = ContentValues().apply {
                put("key", "db_type")
                put("value", repoDbType)
            }
            db.insertWithOnConflict("store_settings", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    override suspend fun authenticate(pin: String): Boolean = withContext(Dispatchers.IO) {
        val sanitized = pin.trim()
        if (sanitized.isBlank()) return@withContext false
        database.readableDatabase.query(
            "users", arrayOf("pin"), "pin = ? AND active = 1", arrayOf(sanitized), null, null, null
        ).use { it.moveToFirst() }
    }

    override suspend fun updatePin(newPin: String) = withContext(Dispatchers.IO) {
        val sanitized = newPin.trim()
        require(sanitized.isNotBlank()) { "New PIN cannot be empty" }
        val db = database.writableDatabase
        db.beginTransaction()
        try {
            db.delete("users", null, null)
            val values = ContentValues().apply {
                put("pin", sanitized)
                put("active", 1)
            }
            db.insertOrThrow("users", null, values)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        AutoBackupScheduler.markDataChanged(appContext)
        Unit
    }

    override suspend fun getStoreName(): String = withContext(Dispatchers.IO) {
        val dbName = runCatching {
            database.readableDatabase.query("store_settings", arrayOf("value"), "key = 'store_name'", null, null, null, null).use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
        val prefName = database.preferences.getString("store_name", null)
        val candidate = dbName?.ifBlank { null } ?: prefName?.ifBlank { null } ?: DEFAULT_STORE_NAME
        candidate.ifBlank { DEFAULT_STORE_NAME }
    }

    override suspend fun updateStoreName(name: String) = withContext(Dispatchers.IO) {
        database.preferences.edit().putString("store_name", name).apply()
        val values = ContentValues().apply {
            put("key", "store_name")
            put("value", name)
        }
        database.writableDatabase.insertWithOnConflict("store_settings", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        AutoBackupScheduler.markDataChanged(appContext)
        Unit
    }

    override suspend fun recordEcashAdjustment(adjustment: EcashAdjustment) = withContext(Dispatchers.IO) {
        val db = database.writableDatabase
        val values = ContentValues().apply {
            put("id", adjustment.id)
            put("type", adjustment.type)
            put("wallet", adjustment.wallet)
            put("amount", adjustment.amount)
            put("note", adjustment.note)
            put("adjusted_at", adjustment.adjustedAt.format(dateTimeFormat))
        }
        db.insertOrThrow("ecash_adjustments", null, values)
        AutoBackupScheduler.markDataChanged(appContext)
        Unit
    }

    override suspend fun ecashAdjustmentsBetween(start: LocalDate, end: LocalDate): List<EcashAdjustment> = withContext(Dispatchers.IO) {
        val startStr = start.atStartOfDay().format(dateTimeFormat)
        val endStr = end.atTime(23, 59, 59).format(dateTimeFormat)
        database.readableDatabase.query(
            "ecash_adjustments",
            null,
            "adjusted_at BETWEEN ? AND ?",
            arrayOf(startStr, endStr),
            null, null, "adjusted_at DESC"
        ).use { cursor ->
            val list = mutableListOf<EcashAdjustment>()
            while (cursor.moveToNext()) {
                list.add(
                    EcashAdjustment(
                        id = cursor.getString(cursor.getColumnIndexOrThrow("id")),
                        type = cursor.getString(cursor.getColumnIndexOrThrow("type")),
                        wallet = cursor.getString(cursor.getColumnIndexOrThrow("wallet")),
                        amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                        note = cursor.getString(cursor.getColumnIndexOrThrow("note")),
                        adjustedAt = LocalDateTime.parse(cursor.getString(cursor.getColumnIndexOrThrow("adjusted_at")), dateTimeFormat)
                    )
                )
            }
            list
        }
    }

    override suspend fun totalEwalletBalance(): Double = withContext(Dispatchers.IO) {
        val adjustments = ecashAdjustmentsBetween(LocalDate.of(2000, 1, 1), LocalDate.now())
        adjustments.sumOf { if (it.wallet == "EWALLET") { if (it.type == "ADD") it.amount else -it.amount } else 0.0 }
    }

    override suspend fun getStoreLogoBase64(): String? = withContext(Dispatchers.IO) {
        runCatching {
            database.readableDatabase.query("store_settings", arrayOf("value"), "key = 'store_logo_base64'", null, null, null, null).use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
    }

    override suspend fun saveStoreLogoBase64(base64: String?) = withContext(Dispatchers.IO) {
        if (base64 == null) {
            database.writableDatabase.delete("store_settings", "key = 'store_logo_base64'", null)
        } else {
            val values = ContentValues().apply {
                put("key", "store_logo_base64")
                put("value", base64)
            }
            database.writableDatabase.insertWithOnConflict("store_settings", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        }
        AutoBackupScheduler.markDataChanged(appContext)
        Unit
    }

    override suspend fun logActivity(action: String, details: String) = withContext(Dispatchers.IO) {
        val log = ActivityLog(action = action, details = details)
        val values = ContentValues().apply {
            put("id", log.id)
            put("action", log.action)
            put("details", log.details)
            put("timestamp", log.timestamp.format(dateTimeFormat))
        }
        database.writableDatabase.insertOrThrow("activity_logs", null, values)
        Unit
    }

    override suspend fun activityLogs(start: LocalDate, end: LocalDate): List<ActivityLog> = withContext(Dispatchers.IO) {
        val startStr = "${start}T00:00:00"
        val endStr = "${end}T23:59:59"
        database.readableDatabase.query(
            "activity_logs", null, "timestamp >= ? AND timestamp <= ?", arrayOf(startStr, endStr),
            null, null, "timestamp DESC"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(
                        ActivityLog(
                            id = cursor.getString(cursor.getColumnIndexOrThrow("id")),
                            action = cursor.getString(cursor.getColumnIndexOrThrow("action")),
                            details = cursor.getString(cursor.getColumnIndexOrThrow("details")),
                            timestamp = LocalDateTime.parse(cursor.getString(cursor.getColumnIndexOrThrow("timestamp")), dateTimeFormat)
                        )
                    )
                }
            }
        }
    }

    override suspend fun inventory(): List<InventoryItem> = withContext(Dispatchers.IO) {
        database.readableDatabase.query("inventory", null, null, null, null, null, "name COLLATE NOCASE").use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(cursor.toInventoryItem())
            }
        }
    }

    override suspend fun saveItem(item: InventoryItem) = withContext(Dispatchers.IO) {
        val db = database.writableDatabase
        val values = item.toContentValues()
        db.insertWithOnConflict("inventory", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        db.update("inventory", values, "barcode = ?", arrayOf(item.barcode))
        AutoBackupScheduler.markDataChanged(appContext)
    }

    override suspend fun deleteItem(barcode: String) = withContext(Dispatchers.IO) {
        database.writableDatabase.delete("inventory", "barcode = ?", arrayOf(barcode))
        AutoBackupScheduler.markDataChanged(appContext)
    }

    override suspend fun completeSale(sale: Sale) = withContext(Dispatchers.IO) {
        val db = database.writableDatabase
        db.beginTransaction()
        try {
            sale.lines.forEach { line ->
                if (line.barcode.startsWith("ECASH_")) {
                    db.insertOrThrow("sales", null, line.toContentValues(sale))
                } else {
                    val isKg = line.unit.equals("kg", ignoreCase = true) || line.unit.equals("kilograms", ignoreCase = true)
                    val isGrm = line.unit.equals("grm", ignoreCase = true) || line.unit.equals("grams", ignoreCase = true)
                    val deductQty = when {
                        isKg -> (line.weightKg * 1000.0).toInt()
                        isGrm -> line.grams.toInt()
                        else -> line.quantity
                    }

                    var remainingDeduct = deductQty
                    var totalStockAvailable = 0
                    db.query(
                        "inventory", arrayOf("SUM(stock_quantity)"), "barcode = ?",
                        arrayOf(line.barcode), null, null, null
                    ).use { if (it.moveToFirst()) totalStockAvailable = it.getInt(0) }

                    require(totalStockAvailable >= deductQty) { "Insufficient stock for ${line.itemName} (Available: ${if (isKg) "${totalStockAvailable / 1000.0} kg" else "$totalStockAvailable"})" }

                    db.query(
                        "inventory", arrayOf("barcode", "expiry_date", "stock_quantity"), "barcode = ?",
                        arrayOf(line.barcode), null, null, "expiry_date ASC"
                    ).use { cursor ->
                        while (cursor.moveToNext() && remainingDeduct > 0) {
                            val bCode = cursor.getString(0)
                            val expDate = cursor.getString(1)
                            val batchStock = cursor.getInt(2)
                            if (batchStock > 0) {
                                val deductFromBatch = remainingDeduct.coerceAtMost(batchStock)
                                db.execSQL(
                                    "UPDATE inventory SET stock_quantity = stock_quantity - ? WHERE barcode = ? AND expiry_date = ?",
                                    arrayOf(deductFromBatch, bCode, expDate)
                                )
                                remainingDeduct -= deductFromBatch
                            }
                        }
                    }
                    db.insertOrThrow("sales", null, line.toContentValues(sale))
                }
            }
            db.setTransactionSuccessful()
            AutoBackupScheduler.markDataChanged(appContext)
        } finally {
            db.endTransaction()
        }
    }

    override suspend fun customerReceivable(contact: String): Double = withContext(Dispatchers.IO) {
        val creditSales = salesBetween(LocalDate.of(2000, 1, 1), LocalDate.now())
            .filter { it.paymentType == "CREDIT" && it.customerContact == contact }
        val creditTotal = creditSales.sumOf { sale ->
            val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
            (sale.total - downPayment).coerceAtLeast(0.0)
        }
        val paidTotal = database.readableDatabase.query(
            "debt_payments", arrayOf("COALESCE(SUM(amount), 0.0)"),
            "contact = ?", arrayOf(contact), null, null, null
        ).use { cursor ->
            if (cursor.moveToFirst()) cursor.getDouble(0) else 0.0
        }
        (round((creditTotal - paidTotal) * 100.0) / 100.0).coerceAtLeast(0.0)
    }

    private data class CustomerProfileRow(
        val name: String,
        val addedAt: LocalDateTime,
        val address: String,
        val creditLimit: Double,
        val signature: ByteArray?
    )

    override suspend fun debtors(): List<Debtor> = withContext(Dispatchers.IO) {
        val db = database.readableDatabase

        // 1. Read all saved customer profiles
        val savedCustomers = mutableMapOf<String, CustomerProfileRow>()
        runCatching {
            db.query("customers", arrayOf("contact", "name", "address", "credit_limit", "added_at", "signature"), null, null, null, null, null).use { c ->
                val idxContact = c.getColumnIndex("contact")
                val idxName = c.getColumnIndex("name")
                val idxAddress = c.getColumnIndex("address")
                val idxLimit = c.getColumnIndex("credit_limit")
                val idxAddedAt = c.getColumnIndex("added_at")
                val idxSig = c.getColumnIndex("signature")
                while (c.moveToNext()) {
                    val contact = if (idxContact >= 0) c.getString(idxContact) else "N/A"
                    val name = if (idxName >= 0) c.getString(idxName) else "Unknown"
                    val address = if (idxAddress >= 0) c.getString(idxAddress) else ""
                    val limit = if (idxLimit >= 0) c.getDouble(idxLimit) else 0.0
                    val addedAtStr = if (idxAddedAt >= 0) c.getString(idxAddedAt) else null
                    val addedAt = runCatching { if (addedAtStr != null) LocalDateTime.parse(addedAtStr, dateTimeFormat) else LocalDateTime.now() }.getOrElse { LocalDateTime.now() }
                    val savedSig = if (idxSig >= 0 && !c.isNull(idxSig)) c.getBlob(idxSig) else null
                    savedCustomers[contact] = CustomerProfileRow(name, addedAt, address, limit, savedSig)
                }
            }
        }

        // 2. Read credit sales and debt payments
        val creditSales = salesBetween(LocalDate.of(2000, 1, 1), LocalDate.now()).filter { it.paymentType == "CREDIT" }
        val payments = runCatching {
            db.query("debt_payments", arrayOf("contact", "SUM(amount) AS paid"), null, null, "contact", null, null).use { c ->
                buildMap { while (c.moveToNext()) put(c.getString(0), c.getDouble(1)) }
            }
        }.getOrElse { emptyMap() }

        val debtorsMap = mutableMapOf<String, Debtor>()

        // First add all saved customer profiles
        savedCustomers.forEach { (contact, profile) ->
            val (name, addedAt, address, limit, savedSig) = profile
            val totalNetCreditOwed = creditSales.filter { it.customerContact == contact }.sumOf { sale ->
                val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                (sale.total - downPayment).coerceAtLeast(0.0)
            }
            val paid = payments[contact] ?: 0.0
            val roundedOwed = (round((totalNetCreditOwed - paid) * 100.0) / 100.0).coerceAtLeast(0.0)
            val lastTxn = creditSales.filter { it.customerContact == contact }.maxByOrNull { it.purchasedAt }?.purchasedAt ?: addedAt
            val saleSig = creditSales.filter { it.customerContact == contact }.maxByOrNull { it.purchasedAt }?.signature
            val finalSig = savedSig ?: saleSig
            debtorsMap[contact] = Debtor(name, contact, roundedOwed, lastTxn, finalSig, address, limit)
        }

        // Then add any debtors from credit sales that weren't explicitly saved
        creditSales.groupBy { it.customerContact }.forEach { (contact, customerSales) ->
            if (!debtorsMap.containsKey(contact)) {
                val latest = customerSales.maxBy { it.purchasedAt }
                val totalNetCreditOwed = customerSales.sumOf { sale ->
                    val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                    (sale.total - downPayment).coerceAtLeast(0.0)
                }
                val paid = payments[contact] ?: 0.0
                val roundedOwed = (round((totalNetCreditOwed - paid) * 100.0) / 100.0).coerceAtLeast(0.0)
                debtorsMap[contact] = Debtor(latest.customerName, latest.customerContact, roundedOwed, latest.purchasedAt, latest.signature)
            }
        }

        debtorsMap.values.sortedBy { it.name.lowercase() }
    }

    override suspend fun saveCustomer(name: String, phone: String, address: String, creditLimit: Double, signature: ByteArray?) = withContext(Dispatchers.IO) {
        val db = database.writableDatabase
        val contactStr = phone.trim().ifBlank { "N/A" }
        val nameClean = name.trim()
        val values = ContentValues().apply {
            put("contact", contactStr)
            put("name", nameClean)
            put("address", address.trim())
            put("credit_limit", creditLimit)
            put("added_at", LocalDateTime.now().format(dateTimeFormat))
            signature?.let { put("signature", it) }
        }
        db.insertWithOnConflict("customers", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        AutoBackupScheduler.markDataChanged(appContext)
    }

    override suspend fun recordDebtPayment(payment: DebtPayment) = withContext(Dispatchers.IO) {
            database.writableDatabase.insertOrThrow("debt_payments", null, ContentValues().apply {
                put("id", payment.id); put("debtor_name", payment.debtorName); put("contact", payment.contact)
                put("amount", payment.amount); put("cash_received", payment.cashReceived)
                put("change_amount", payment.change); put("paid_at", payment.paidAt.format(dateTimeFormat))
            })
            database.writableDatabase.insertOrThrow("cash_capitals", null, ContentValues().apply {
                put("id", UUID.randomUUID().toString()); put("amount", payment.amount)
                put("note", "Utang payment - ${payment.debtorName}"); put("added_at", payment.paidAt.format(dateTimeFormat))
            })
            AutoBackupScheduler.markDataChanged(appContext)
    }

    override suspend fun debtPayments(): List<DebtPayment> = withContext(Dispatchers.IO) {
        val db = database.readableDatabase
        val records = db.query("debt_payments", null, null, null, null, null, "paid_at ASC").use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(
                    DebtPayment(
                        cursor.getString(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("debtor_name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("contact")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("cash_received")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("change_amount")),
                        LocalDateTime.parse(cursor.getString(cursor.getColumnIndexOrThrow("paid_at")), dateTimeFormat)
                    )
                )
            }
        }
        if (records.isEmpty()) return@withContext emptyList()

        val allCreditSales = salesBetween(LocalDate.of(2000, 1, 1), LocalDate.now())
            .filter { it.paymentType == "CREDIT" }

        val paidByContact = mutableMapOf<String, Double>()
        records.map { payment ->
            val creditSalesAtPayment = allCreditSales.filter {
                it.customerContact == payment.contact && !it.purchasedAt.isAfter(payment.paidAt)
            }
            val totalNetCreditOwedAtPayment = creditSalesAtPayment.sumOf { sale ->
                val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                (sale.total - downPayment).coerceAtLeast(0.0)
            }
            val previousPaid = paidByContact[payment.contact] ?: 0.0
            val previousBalance = (totalNetCreditOwedAtPayment - previousPaid).coerceAtLeast(0.0)
            paidByContact[payment.contact] = previousPaid + payment.amount
            payment.copy(
                previousBalance = previousBalance,
                remainingBalance = (previousBalance - payment.amount).coerceAtLeast(0.0)
            )
        }.sortedByDescending { it.paidAt }
    }

    override suspend fun voidSale(saleId: String) = withContext(Dispatchers.IO) {
        val db = database.writableDatabase
        db.beginTransaction()
        try {
            db.query("sales", arrayOf("barcode", "quantity"), "sale_id = ?", arrayOf(saleId), null, null, null).use { cursor ->
                while (cursor.moveToNext()) {
                    db.execSQL(
                        "UPDATE inventory SET stock_quantity = stock_quantity + ? WHERE barcode = ?",
                        arrayOf(cursor.getInt(1), cursor.getString(0))
                    )
                }
            }
            db.delete("sales", "sale_id = ?", arrayOf(saleId))
            db.setTransactionSuccessful()
            AutoBackupScheduler.markDataChanged(appContext)
        } finally {
            db.endTransaction()
        }
    }

    override suspend fun salesBetween(start: LocalDate, end: LocalDate): List<Sale> = withContext(Dispatchers.IO) {
        database.readableDatabase.query("sales", null, null, null, null, null, "purchased_at DESC").use { cursor ->
            val sales = linkedMapOf<String, MutableList<SaleRow>>()
            while (cursor.moveToNext()) {
                val row = cursor.toSaleRow()
                if (row.purchasedAt.toLocalDate() in start..end) {
                    sales.getOrPut(row.saleId) { mutableListOf() }.add(row)
                }

            }
            sales.values.map { rows ->
                Sale(
                    rows.first().saleId, rows.first().purchasedAt, rows.map { it.line }, rows.first().discount,
                    rows.first().paymentType, rows.first().customerName, rows.first().customerContact, rows.first().signature
                    , rows.first().cashReceived, rows.first().change
                )
            }
        }
    }

    override suspend fun totalCash(): Double = withContext(Dispatchers.IO) {
        val allSales = salesBetween(LocalDate.of(2000, 1, 1), LocalDate.now())
        val salesTotal = allSales.sumOf { it.cashAmount }

        val withdrawals = database.readableDatabase.query("cash_withdrawals", arrayOf("amount"), null, null, null, null, null).use { cursor ->
            var total = 0.0
            while (cursor.moveToNext()) total += cursor.getDouble(0)
            total
        }
        val capitals = database.readableDatabase.query("cash_capitals", arrayOf("amount"), null, null, null, null, null).use { cursor ->
            var total = 0.0
            while (cursor.moveToNext()) total += cursor.getDouble(0)
            total
        }
        salesTotal + capitals - withdrawals
    }

    override suspend fun cashBalanceAt(date: LocalDate): Double = withContext(Dispatchers.IO) {
        val allSales = salesBetween(LocalDate.of(2000, 1, 1), date)
        val salesTotal = allSales.sumOf { it.cashAmount }

        val end = "${date}T23:59:59"
        fun sumTable(table: String, dateColumn: String): Double =
            database.readableDatabase.query(table, arrayOf("amount"), "$dateColumn <= ?", arrayOf(end), null, null, null).use { c ->
                var sum = 0.0
                while (c.moveToNext()) sum += c.getDouble(0)
                sum
            }
        salesTotal + sumTable("cash_capitals", "added_at") - sumTable("cash_withdrawals", "withdrawn_at")
    }

    override suspend fun recordCashWithdrawal(withdrawal: CashWithdrawal) = withContext(Dispatchers.IO) {
        database.writableDatabase.insertOrThrow("cash_withdrawals", null, ContentValues().apply {
            put("id", withdrawal.id)
            put("amount", withdrawal.amount)
            put("note", withdrawal.note)
            put("withdrawn_at", withdrawal.withdrawnAt.format(dateTimeFormat))
        })
        AutoBackupScheduler.markDataChanged(appContext)
    }

    override suspend fun cashWithdrawals(): List<CashWithdrawal> = withContext(Dispatchers.IO) {
        database.readableDatabase.query("cash_withdrawals", null, null, null, null, null, "withdrawn_at DESC").use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(
                    CashWithdrawal(
                        cursor.getString(cursor.getColumnIndexOrThrow("id")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                        cursor.getString(cursor.getColumnIndexOrThrow("note")),
                        LocalDateTime.parse(cursor.getString(cursor.getColumnIndexOrThrow("withdrawn_at")), dateTimeFormat)
                    )
                )
            }
        }
    }

    override suspend fun recordCashCapital(capital: CashCapital) = withContext(Dispatchers.IO) {
        database.writableDatabase.insertOrThrow("cash_capitals", null, ContentValues().apply {
            put("id", capital.id)
            put("amount", capital.amount)
            put("note", capital.note)
            put("added_at", capital.addedAt.format(dateTimeFormat))
        })
        AutoBackupScheduler.markDataChanged(appContext)
    }

    override suspend fun cashCapitals(): List<CashCapital> = withContext(Dispatchers.IO) {
        database.readableDatabase.query("cash_capitals", null, null, null, null, null, "added_at DESC").use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(
                    CashCapital(
                        cursor.getString(cursor.getColumnIndexOrThrow("id")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                        cursor.getString(cursor.getColumnIndexOrThrow("note")),
                        LocalDateTime.parse(cursor.getString(cursor.getColumnIndexOrThrow("added_at")), dateTimeFormat)
                    )
                )
            }
        }
    }

    override suspend fun exportDatabase(output: OutputStream, format: String) = withContext(Dispatchers.IO) {
        ensureDbTypeMarker(database.writableDatabase)
        if (format == "csv") {
            val db = database.readableDatabase
            val writer = output.bufferedWriter()
            writer.appendLine("POS_CSV_V1")
            listOf("users", "inventory", "sales", "cash_withdrawals", "cash_capitals", "debt_payments", "store_settings", "activity_logs").forEach { table ->
                db.query(table, null, null, null, null, null, null).use { cursor ->
                    val columns = cursor.columnNames.toList()
                    writer.appendLine(csvLine(listOf("TABLE", table) + columns))
                    while (cursor.moveToNext()) {
                        writer.appendLine(csvLine(listOf("ROW", table) + columns.map { column ->
                            if (cursor.isNull(cursor.getColumnIndexOrThrow(column))) "" else when (cursor.getType(cursor.getColumnIndexOrThrow(column))) {
                                android.database.Cursor.FIELD_TYPE_BLOB -> Base64.encodeToString(cursor.getBlob(cursor.getColumnIndexOrThrow(column)), Base64.NO_WRAP)
                                else -> cursor.getString(cursor.getColumnIndexOrThrow(column))
                            }
                        }))
                    }
                }
            }
            writer.flush()
        } else {
            database.close()
            databaseFile().inputStream().use { it.copyTo(output) }
            output.flush()
        }
    }

    override suspend fun importDatabase(input: InputStream) = importDatabaseTarget(input, "BOTH")

    override suspend fun importDatabaseTarget(input: InputStream, target: String) = withContext(Dispatchers.IO) {
        val temporaryFile = File(appContext.filesDir, "pos_local_import.db")
        try {
            val data = input.readBytes()
            require(data.isNotEmpty()) { "Uploaded database file is empty." }

            if (data.copyOfRange(0, minOf(data.size, 16)).contentEquals("SQLite format 3\u0000".toByteArray())) {
                temporaryFile.outputStream().use { it.write(data) }
                val isValidSchema = validateDatabaseSchema(temporaryFile, target)
                require(isValidSchema) {
                    when (target.uppercase()) {
                        "MART" -> "Uploaded file is an Ecash database and cannot be uploaded to Mart mode."
                        "ECASH" -> "Uploaded file is a Mart database and cannot be uploaded to Ecash mode."
                        else -> "Uploaded file is not a valid POS database file."
                    }
                }
                database.close()
                SQLiteDatabase.releaseMemory()
                temporaryFile.copyTo(databaseFile(), overwrite = true)
            } else {
                val csvContent = data.toString(Charsets.UTF_8)
                val targetUpper = target.uppercase()
                require(csvContent.contains("TABLE") || csvContent.contains("POS_CSV_V1") || csvContent.contains("barcode")) {
                    "Uploaded CSV file does not contain required POS fields."
                }
                if (targetUpper == "MART") {
                    require(!csvContent.contains("ecash_adjustments") && !csvContent.contains("ECASH_")) {
                        "Uploaded CSV file is an Ecash database and cannot be uploaded to Mart mode."
                    }
                } else if (targetUpper == "ECASH") {
                    require(csvContent.contains("ecash_adjustments") || csvContent.contains("ECASH_")) {
                        "Uploaded CSV file is a Mart database and cannot be uploaded to Ecash mode."
                    }
                }
                importCsv(csvContent)
            }
        } finally {
            temporaryFile.delete()
        }
        Unit
    }

    private fun validateDatabaseSchema(dbFile: File, target: String): Boolean {
        var db: SQLiteDatabase? = null
        return try {
            db = SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READONLY)
            val tables = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { cursor ->
                while (cursor.moveToNext()) {
                    tables.add(cursor.getString(cursor.getColumnIndexOrThrow("name")))
                }
            }

            if (!tables.contains("users") || !tables.contains("store_settings")) {
                return false
            }

            var dbTypeInFile: String? = null
            runCatching {
                db.query("store_settings", arrayOf("value"), "key = 'db_type'", null, null, null, null).use { c ->
                    if (c.moveToFirst()) dbTypeInFile = c.getString(0)
                }
            }

            val hasEcashAdjustments = tables.contains("ecash_adjustments") && runCatching {
                db.rawQuery("SELECT COUNT(*) FROM ecash_adjustments", null).use { c ->
                    c.moveToFirst() && c.getInt(0) > 0
                }
            }.getOrDefault(false)

            val hasEcashSales = if (tables.contains("sales")) {
                runCatching {
                    db.query("sales", arrayOf("barcode"), "barcode LIKE 'ECASH_%'", null, null, null, null).use { c ->
                        c.moveToFirst()
                    }
                }.getOrDefault(false)
            } else false

            val hasRetailInventory = if (tables.contains("inventory")) {
                runCatching {
                    db.query("inventory", arrayOf("barcode"), "barcode NOT LIKE 'ECASH_%'", null, null, null, null).use { c ->
                        c.moveToFirst()
                    }
                }.getOrDefault(false)
            } else false

            val targetUpper = target.uppercase()

            val isEcashByMarker = (dbTypeInFile == "ECASH")
            val isMartByMarker = (dbTypeInFile == "MART")

            // If there's no marker, we fallback to guessing by content
            val isEcashByContent = hasEcashAdjustments || hasEcashSales
            val isMartByContent = hasRetailInventory

            when (targetUpper) {
                "MART" -> {
                    if (dbTypeInFile != null) return isMartByMarker
                    return !isEcashByContent
                }
                "ECASH" -> {
                    if (dbTypeInFile != null) return isEcashByMarker
                    return !isMartByContent
                }
                else -> return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        } finally {
            db?.close()
        }
    }

    private fun csvLine(values: List<String>): String = values.joinToString(",") { value ->
        "\"${value.replace("\"", "\"\"")}\""
    }

    private fun parseCsvLine(line: String): List<String> {
        val values = mutableListOf<String>()
        val value = StringBuilder()
        var quoted = false
        var index = 0
        while (index < line.length) {
            val character = line[index]
            when {
                character == '"' && quoted && index + 1 < line.length && line[index + 1] == '"' -> {
                    value.append('"')
                    index++
                }
                character == '"' -> quoted = !quoted
                character == ',' && !quoted -> {
                    values += value.toString()
                    value.clear()
                }
                else -> value.append(character)
            }
            index++
        }
        values += value.toString()
        return values
    }

    private fun importCsv(csv: String) {
        val lines = csv.lineSequence().filter { it.isNotBlank() }.map(::parseCsvLine).toList()
        require(lines.firstOrNull()?.firstOrNull() == "POS_CSV_V1") { "Selected file is not a valid POS CSV backup" }
        val db = database.writableDatabase
        db.beginTransaction()
        try {
            listOf("sales", "cash_withdrawals", "cash_capitals", "debt_payments", "inventory", "users", "store_settings", "activity_logs").forEach {
                db.delete(it, null, null)
            }
            lines.drop(1).forEach { fields ->
                if (fields.firstOrNull() != "TABLE" && fields.firstOrNull() != "ROW") return@forEach
                if (fields.first() == "TABLE") return@forEach
                val table = fields[1]
                val columns = lines.drop(1).firstOrNull { it.firstOrNull() == "TABLE" && it.getOrNull(1) == table }?.drop(2)
                    ?: return@forEach
                val values = ContentValues()
                columns.forEachIndexed { index, column ->
                    val raw = fields.getOrNull(index + 2).orEmpty()
                    if (raw.isEmpty()) values.putNull(column)
                    else when (table) {
                        "inventory" -> when (column) {
                            "stock_quantity", "low_stock_limit", "recommended_stock" -> values.put(column, raw.toInt())
                            "purchase_cost", "selling_price" -> values.put(column, raw.toDouble())
                            else -> values.put(column, raw)
                        }
                        "sales" -> when (column) {
                            "quantity" -> values.put(column, raw.toInt())
                            "unit_price", "unit_cost", "discount", "cash_received", "change_amount" -> values.put(column, raw.toDouble())
                            "signature" -> values.put(column, Base64.decode(raw, Base64.DEFAULT))
                            else -> values.put(column, raw)
                        }
                        "cash_withdrawals", "cash_capitals", "debt_payments" ->
                            if (column == "amount") values.put(column, raw.toDouble()) else values.put(column, raw)
                        else -> values.put(column, raw)
                    }
                }
                db.insertOrThrow(table, null, values)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    override suspend fun resetDatabase(preset: String): Unit = withContext(Dispatchers.IO) {
        val db = database.writableDatabase
        db.beginTransactionNonExclusive()
        try {
            runCatching { db.execSQL("PRAGMA foreign_keys = OFF;") }

            // Ensure all columns exist in inventory table before clearing and seeding
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN image_path TEXT;") }
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN category TEXT NOT NULL DEFAULT 'General';") }
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN unit TEXT NOT NULL DEFAULT 'pcs';") }
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN recommended_stock INTEGER NOT NULL DEFAULT 10;") }

            db.execSQL("DELETE FROM sales;")
            db.execSQL("DELETE FROM cash_withdrawals;")
            db.execSQL("DELETE FROM cash_capitals;")
            db.execSQL("DELETE FROM debt_payments;")
            db.execSQL("DELETE FROM customers;")
            db.execSQL("DELETE FROM inventory;")
            db.execSQL("DELETE FROM users;")
            db.execSQL("DELETE FROM store_settings;")
            db.execSQL("DELETE FROM activity_logs;")
            db.execSQL("DELETE FROM ecash_adjustments;")

            val userValues = ContentValues().apply {
                put("pin", "1234")
                put("active", 1)
            }
            db.insertWithOnConflict("users", null, userValues, SQLiteDatabase.CONFLICT_REPLACE)

            when {
                preset.contains("400") -> database.seedPhGroceryInventory(db)
                preset.contains("Hardware", ignoreCase = true) -> database.seedHardwareInventory(db)
                else -> { /* "0" -> Blank slate */ }
            }

            db.setTransactionSuccessful()
        } catch (e: Exception) {
            e.printStackTrace()
            throw e
        } finally {
            try {
                db.endTransaction()
            } catch (_: Exception) {}
            runCatching { db.execSQL("PRAGMA foreign_keys = ON;") }
        }

        runCatching {
            database.preferences.edit().clear().commit()
            val posPrefs = appContext.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
            posPrefs.edit().clear().commit()
            AutoBackupScheduler.markDataChanged(appContext)
        }
        Unit
    }

    private data class SaleRow(
        val saleId: String,
        val purchasedAt: LocalDateTime,
        val line: SaleLine,
        val discount: Double,
        val paymentType: String,
        val customerName: String,
        val customerContact: String,
        val signature: ByteArray?,
        val cashReceived: Double,
        val change: Double
    )

    private fun InventoryItem.toContentValues() = ContentValues().apply {
        put("barcode", barcode)
        put("name", name)
        put("purchase_cost", purchaseCost)
        put("selling_price", sellingPrice)
        put("stock_quantity", stockQuantity)
        put("low_stock_limit", lowStockLimit)
        put("recommended_stock", recommendedStock)
        put("added_at", addedAt.format(dateTimeFormat))
        put("unit", unit)
        put("category", effectiveCategory)
        put("expiry_date", expiryDate.toString())
        imagePath?.let { put("image_path", it) }
    }

    override suspend fun updateItemImage(barcode: String, imagePath: String) = withContext(Dispatchers.IO) {
        val db = database.writableDatabase
        val values = ContentValues().apply {
            put("image_path", imagePath)
        }
        db.update("inventory", values, "barcode = ?", arrayOf(barcode))
        AutoBackupScheduler.markDataChanged(appContext)
    }

    private fun SaleLine.toContentValues(sale: Sale) = ContentValues().apply {
        put("sale_id", sale.id)
        put("purchased_at", sale.purchasedAt.format(dateTimeFormat))
        put("barcode", barcode)
        put("item_name", itemName)
        put("quantity", quantity)
        put("unit_price", unitPrice)
        put("unit_cost", unitCost)
        put("discount", sale.discount)
        put("payment_type", sale.paymentType)
        put("customer_name", sale.customerName)
        put("customer_contact", sale.customerContact)
        sale.signature?.let { put("signature", it) }
        put("cash_received", sale.cashReceived)
        put("change_amount", sale.change)
        put("unit", unit)
        put("grams", grams)
        put("weight_kg", weightKg)
    }



    private fun Cursor.toInventoryItem(): InventoryItem {
        val bc = getString(getColumnIndexOrThrow("barcode"))
        val nm = getString(getColumnIndexOrThrow("name"))
        val storedPath = getColumnIndex("image_path").let { idx ->
            if (idx != -1 && !isNull(idx)) getString(idx) else null
        }
        val effectivePath = if (!storedPath.isNullOrBlank()) storedPath else getPhGroceryImageUrl(bc, nm)
        val expStr = getColumnIndex("expiry_date").let {
            if (it != -1 && !isNull(it)) getString(it) else "2027-12-31"
        }
        val parsedExpiry = runCatching { LocalDate.parse(expStr) }.getOrDefault(LocalDate.now().plusYears(1))

        return InventoryItem(
            barcode = bc,
            name = nm,
            purchaseCost = getDouble(getColumnIndexOrThrow("purchase_cost")),
            sellingPrice = getDouble(getColumnIndexOrThrow("selling_price")),
            stockQuantity = getInt(getColumnIndexOrThrow("stock_quantity")),
            lowStockLimit = getInt(getColumnIndexOrThrow("low_stock_limit")),
            recommendedStock = getColumnIndex("recommended_stock").let { if (it != -1 && !isNull(it)) getInt(it) else 10 },
            addedAt = LocalDateTime.parse(getString(getColumnIndexOrThrow("added_at")), dateTimeFormat),
            unit = getColumnIndex("unit").let { if (it != -1 && !isNull(it)) getString(it) else "pcs" },
            category = getColumnIndex("category").let { if (it != -1 && !isNull(it)) getString(it) else "General" },
            imagePath = effectivePath,
            expiryDate = parsedExpiry
        )
    }

    private fun android.database.Cursor.toSaleRow() = SaleRow(
        getString(getColumnIndexOrThrow("sale_id")),
        LocalDateTime.parse(getString(getColumnIndexOrThrow("purchased_at")), dateTimeFormat),
        SaleLine(
            getString(getColumnIndexOrThrow("barcode")),
            getString(getColumnIndexOrThrow("item_name")),
            getInt(getColumnIndexOrThrow("quantity")),
            getDouble(getColumnIndexOrThrow("unit_price")),
            getDouble(getColumnIndexOrThrow("unit_cost")),
            unit = getColumnIndex("unit").let { if (it != -1 && !isNull(it)) getString(it) else "pcs" },
            grams = getColumnIndex("grams").let { if (it != -1 && !isNull(it)) getDouble(it) else 0.0 },
            weightKg = getColumnIndex("weight_kg").let { if (it != -1 && !isNull(it)) getDouble(it) else 0.0 }
        ),
        getDouble(getColumnIndexOrThrow("discount")),
        getString(getColumnIndexOrThrow("payment_type")),
        getString(getColumnIndexOrThrow("customer_name")),
        getString(getColumnIndexOrThrow("customer_contact")),
        getBlob(getColumnIndexOrThrow("signature")),
        getDouble(getColumnIndexOrThrow("cash_received")),
        getDouble(getColumnIndexOrThrow("change_amount"))
    )

    private class PosDatabase(context: Context, dbName: String, prefsName: String) : SQLiteOpenHelper(context, dbName, null, 16) {
        val preferences = context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)

        override fun onOpen(db: SQLiteDatabase) {
            super.onOpen(db)
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN image_path TEXT;") }
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN category TEXT NOT NULL DEFAULT 'General';") }
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN unit TEXT NOT NULL DEFAULT 'pcs';") }
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN recommended_stock INTEGER NOT NULL DEFAULT 10;") }
            runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN expiry_date TEXT NOT NULL DEFAULT '2027-12-31';") }
            runCatching { db.execSQL("CREATE TABLE IF NOT EXISTS customers (contact TEXT PRIMARY KEY, name TEXT NOT NULL, address TEXT NOT NULL DEFAULT '', credit_limit REAL NOT NULL DEFAULT 0.0, added_at TEXT NOT NULL);") }
            runCatching { db.execSQL("ALTER TABLE customers ADD COLUMN signature BLOB;") }
            runCatching { db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_purchased_at ON sales(purchased_at);") }
            runCatching { db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_payment_type ON sales(payment_type);") }
            runCatching { db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_contact ON sales(customer_contact);") }
            runCatching { db.execSQL("CREATE INDEX IF NOT EXISTS idx_ecash_adj_wallet ON ecash_adjustments(wallet, adjusted_at);") }
            runCatching { db.execSQL("CREATE INDEX IF NOT EXISTS idx_debt_payments_contact ON debt_payments(contact);") }
            runCatching { db.execSQL("CREATE INDEX IF NOT EXISTS idx_inventory_category ON inventory(category);") }
        }

        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE users (pin TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)")
            db.execSQL(
                "CREATE TABLE inventory (" +
                    "barcode TEXT PRIMARY KEY, name TEXT NOT NULL, purchase_cost REAL NOT NULL, " +
                    "selling_price REAL NOT NULL, stock_quantity INTEGER NOT NULL, " +
                    "low_stock_limit INTEGER NOT NULL, recommended_stock INTEGER NOT NULL DEFAULT 10, " +
                    "added_at TEXT NOT NULL, unit TEXT NOT NULL DEFAULT 'pcs', category TEXT NOT NULL DEFAULT 'General', " +
                    "image_path TEXT)"
            )
            db.execSQL(
                "CREATE TABLE sales (" +
                    "sale_id TEXT NOT NULL, purchased_at TEXT NOT NULL, barcode TEXT NOT NULL, " +
                    "item_name TEXT NOT NULL, quantity INTEGER NOT NULL, unit_price REAL NOT NULL, " +
                    "unit_cost REAL NOT NULL, discount REAL NOT NULL DEFAULT 0, " +
                    "payment_type TEXT NOT NULL DEFAULT 'CASH', customer_name TEXT NOT NULL DEFAULT 'Walkin', " +
                    "customer_contact TEXT NOT NULL DEFAULT '', signature BLOB, cash_received REAL NOT NULL DEFAULT 0, " +
                    "change_amount REAL NOT NULL DEFAULT 0, unit TEXT NOT NULL DEFAULT 'pcs', grams REAL NOT NULL DEFAULT 0, weight_kg REAL NOT NULL DEFAULT 0)"
            )
            db.execSQL("CREATE TABLE IF NOT EXISTS customers (contact TEXT PRIMARY KEY, name TEXT NOT NULL, address TEXT NOT NULL DEFAULT '', credit_limit REAL NOT NULL DEFAULT 0.0, added_at TEXT NOT NULL)")
            db.execSQL("CREATE TABLE cash_withdrawals (id TEXT PRIMARY KEY, amount REAL NOT NULL, note TEXT NOT NULL, withdrawn_at TEXT NOT NULL)")
            db.execSQL("CREATE TABLE cash_capitals (id TEXT PRIMARY KEY, amount REAL NOT NULL, note TEXT NOT NULL, added_at TEXT NOT NULL)")
            db.execSQL("CREATE TABLE debt_payments (id TEXT PRIMARY KEY, debtor_name TEXT NOT NULL, contact TEXT NOT NULL, amount REAL NOT NULL, cash_received REAL NOT NULL, change_amount REAL NOT NULL, paid_at TEXT NOT NULL)")
            db.execSQL("CREATE TABLE store_settings (`key` TEXT PRIMARY KEY, value TEXT)")
            db.execSQL("CREATE TABLE activity_logs (id TEXT PRIMARY KEY, `action` TEXT NOT NULL, details TEXT NOT NULL, timestamp TEXT NOT NULL)")
            db.execSQL("CREATE TABLE ecash_adjustments (id TEXT PRIMARY KEY, type TEXT NOT NULL, wallet TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL, adjusted_at TEXT NOT NULL)")
            db.insertOrThrow("users", null, ContentValues().apply {
                put("pin", "1234")
                put("active", 1)
            })
            seedDefaultInventory(db)
        }

        fun seedDefaultInventory(db: SQLiteDatabase) {
            listOf(
                InventoryItem("480001", "Lucky Me Pancit Canton", 12.0, 15.0, 24, 5),
                InventoryItem("480002", "Coca-Cola 330ml", 12.0, 18.0, 8, 5),
                InventoryItem("480003", "Cloud 9 Chocolate", 13.0, 18.0, 0, 5)
            ).forEach { item ->
                db.insertOrThrow("inventory", null, ContentValues().apply {
                    put("barcode", item.barcode)
                    put("name", item.name)
                    put("purchase_cost", item.purchaseCost)
                    put("selling_price", item.sellingPrice)
                    put("stock_quantity", item.stockQuantity)
                    put("low_stock_limit", item.lowStockLimit)
                    put("recommended_stock", item.recommendedStock)
                    put("added_at", item.addedAt.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
                    put("unit", item.unit)
                })
            }
        }

        fun seedPhGroceryInventory(db: SQLiteDatabase) {
            val items = listOf(
                // 1. Noodles & Pasta (1 - 30)
                InventoryItem("480000000001", "Lucky Me Pancit Canton Original 80g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000002", "Lucky Me Pancit Canton Extra Hot 80g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000003", "Lucky Me Pancit Canton Sweet & Spicy 80g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000004", "Lucky Me Pancit Canton Chilimansi 80g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000005", "Lucky Me Pancit Canton Kalamansi 80g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000006", "Lucky Me Instant Noodles Beef 55g", 10.0, 13.0, 60, 10),
                InventoryItem("480000000007", "Lucky Me Instant Noodles Chicken 55g", 10.0, 13.0, 60, 10),
                InventoryItem("480000000008", "Lucky Me Supreme Cup La Paz Batchoy 70g", 24.0, 30.0, 30, 5),
                InventoryItem("480000000009", "Lucky Me Supreme Cup Bulalo 70g", 24.0, 30.0, 30, 5),
                InventoryItem("480000000010", "Payless Xtra Big Pancit Canton Sweet & Spicy 130g", 16.0, 20.0, 40, 8),
                InventoryItem("480000000011", "Payless Xtra Big Pancit Canton Chilimansi 130g", 16.0, 20.0, 40, 8),
                InventoryItem("480000000012", "Nissin Yakisoba Spicy Chicken 77g", 14.0, 18.0, 35, 8),
                InventoryItem("480000000013", "Nissin Cup Noodles Seafood 40g", 20.0, 25.0, 30, 5),
                InventoryItem("480000000014", "Nissin Cup Noodles Beef 40g", 20.0, 25.0, 30, 5),
                InventoryItem("480000000015", "Shin Ramyun Noodle Soup Gourmet Spicy 120g", 45.0, 55.0, 25, 5),
                InventoryItem("480000000016", "Samyang Buldak Hot Chicken Ramen Carbonara 130g", 55.0, 68.0, 20, 5),
                InventoryItem("480000000017", "Royal Spaghetti Pasta 500g", 38.0, 48.0, 30, 5),
                InventoryItem("480000000018", "Fiesta Spaghetti Pasta 900g", 65.0, 78.0, 25, 5),
                InventoryItem("480000000019", "Del Monte Spaghetti Pasta 1kg", 72.0, 85.0, 20, 5),
                InventoryItem("480000000020", "El Real Spaghetti Pasta 800g", 52.0, 65.0, 25, 5),
                InventoryItem("480000000021", "White King Elbow Macaroni 400g", 32.0, 42.0, 30, 5),
                InventoryItem("480000000022", "Royal Elbow Macaroni 1kg", 75.0, 90.0, 20, 5),
                InventoryItem("480000000023", "Knorr Crab & Corn Soup Mix 47g", 22.0, 28.0, 30, 5),
                InventoryItem("480000000024", "Knorr Nido Soup Mix 60g", 24.0, 30.0, 30, 5),
                InventoryItem("480000000025", "Knorr Real Chinese Soup Corn 55g", 22.0, 28.0, 30, 5),
                InventoryItem("480000000026", "Super Q Golden Bihon 500g", 38.0, 48.0, 25, 5),
                InventoryItem("480000000027", "Super Q Special Sotanghon 250g", 42.0, 52.0, 25, 5),
                InventoryItem("480000000028", "Hobe Special Misua 227g", 22.0, 28.0, 30, 5),
                InventoryItem("480000000029", "First Quality Tanghon Vermicelli 250g", 30.0, 38.0, 25, 5),
                InventoryItem("480000000030", "Kikiam Noodle Topping Mix 200g", 25.0, 32.0, 20, 5),

                // 2. Canned Goods & Processed Meat (31 - 70)
                InventoryItem("480000000031", "Century Tuna Flakes in Oil 180g", 32.0, 39.0, 40, 8),
                InventoryItem("480000000032", "Century Tuna Flakes in Vegetable Oil 155g", 28.0, 35.0, 40, 8),
                InventoryItem("480000000033", "Century Tuna Hot & Spicy 180g", 33.0, 40.0, 40, 8),
                InventoryItem("480000000034", "Century Tuna Flakes in Brine 180g", 32.0, 39.0, 30, 5),
                InventoryItem("480000000035", "555 Sardines in Tomato Sauce 155g", 18.0, 23.0, 50, 10),
                InventoryItem("480000000036", "555 Sardines in Tomato Sauce Chili 155g", 18.0, 23.0, 50, 10),
                InventoryItem("480000000037", "Mega Sardines Green Tomato Sauce 155g", 19.0, 24.0, 50, 10),
                InventoryItem("480000000038", "Mega Sardines Red Hot Tomato Sauce 155g", 19.0, 24.0, 50, 10),
                InventoryItem("480000000039", "Ligo Sardines Red Tomato Sauce 155g", 20.0, 25.0, 40, 8),
                InventoryItem("480000000040", "Ligo Sardines Green Tomato Sauce Chili 155g", 20.0, 25.0, 40, 8),
                InventoryItem("480000000041", "San Jose Spanish Sardines in Corn Oil 225g", 65.0, 78.0, 20, 5),
                InventoryItem("480000000042", "Argentina Corned Beef 150g", 35.0, 42.0, 40, 8),
                InventoryItem("480000000043", "Argentina Corned Beef 260g", 58.0, 70.0, 30, 5),
                InventoryItem("480000000044", "Purefoods Corned Beef 150g", 55.0, 68.0, 30, 5),
                InventoryItem("480000000045", "Purefoods Corned Beef 210g", 78.0, 92.0, 25, 5),
                InventoryItem("480000000046", "Purefoods Corned Beef Star 150g", 32.0, 39.0, 40, 8),
                InventoryItem("480000000047", "Highlands Corned Beef 150g", 42.0, 52.0, 30, 5),
                InventoryItem("480000000048", "Swift Premium Corned Beef 150g", 40.0, 50.0, 30, 5),
                InventoryItem("480000000049", "CDO Karne Norte 150g", 22.0, 28.0, 40, 8),
                InventoryItem("480000000050", "CDO Meat Loaf 150g", 20.0, 25.0, 40, 8),
                InventoryItem("480000000051", "Argentina Meat Loaf 170g", 22.0, 27.0, 40, 8),
                InventoryItem("480000000052", "Maling Pork Luncheon Meat 397g", 90.0, 110.0, 20, 5),
                InventoryItem("480000000053", "SPAM Classic Luncheon Meat 340g", 185.0, 215.0, 15, 3),
                InventoryItem("480000000054", "SPAM Lite Luncheon Meat 340g", 185.0, 215.0, 15, 3),
                InventoryItem("480000000055", "Tulip Pork Luncheon Meat 340g", 145.0, 170.0, 20, 5),
                InventoryItem("480000000056", "Libbys Vienna Sausage 130g", 38.0, 48.0, 30, 5),
                InventoryItem("480000000057", "Swift Pork & Beans 230g", 25.0, 32.0, 30, 5),
                InventoryItem("480000000058", "Hunts Pork & Beans 230g", 26.0, 33.0, 30, 5),
                InventoryItem("480000000059", "CDO Liver Spread 85g", 18.0, 23.0, 40, 8),
                InventoryItem("480000000060", "Reno Liver Spread 85g", 22.0, 28.0, 40, 8),
                InventoryItem("480000000061", "Argentina Beef Loaf 150g", 22.0, 27.0, 40, 8),
                InventoryItem("480000000062", "Purefoods Beef Loaf 150g", 25.0, 32.0, 30, 5),
                InventoryItem("480000000063", "CDO Beef Loaf 150g", 22.0, 27.0, 40, 8),
                InventoryItem("480000000064", "555 Squid in Soy Sauce 155g", 28.0, 35.0, 25, 5),
                InventoryItem("480000000065", "555 Fried Sardines Escabeche 155g", 25.0, 32.0, 25, 5),
                InventoryItem("480000000066", "Century Tuna Mechado 180g", 35.0, 42.0, 30, 5),
                InventoryItem("480000000067", "Century Tuna Caldereta 180g", 35.0, 42.0, 30, 5),
                InventoryItem("480000000068", "San Marino Corned Tuna 180g", 34.0, 42.0, 30, 5),
                InventoryItem("480000000069", "San Marino Chili Corned Tuna 180g", 34.0, 42.0, 30, 5),
                InventoryItem("480000000070", "Del Monte Pineapple Chunks 227g", 30.0, 38.0, 25, 5),

                // 3. Coffee, Milk & Beverages (71 - 110)
                InventoryItem("480000000071", "Nescafe 3in1 Original Coffee Twin Pack 56g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000072", "Nescafe 3in1 Brown Coffee Twin Pack 56g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000073", "Nescafe 3in1 Creamy White Twin Pack 56g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000074", "Nescafe Classic Instant Coffee 25g", 22.0, 27.0, 40, 8),
                InventoryItem("480000000075", "Nescafe Classic Instant Coffee 50g", 42.0, 52.0, 30, 5),
                InventoryItem("480000000076", "Nescafe Gold Intense Freeze Dried 100g", 180.0, 215.0, 15, 3),
                InventoryItem("480000000077", "Kopiko Blanca Creamy Coffee Twin Pack 60g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000078", "Kopiko Brown Coffee Twin Pack 55g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000079", "Kopiko Black 3in1 Coffee Twin Pack 60g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000080", "Great Taste White Coffee Twin Pack 60g", 11.0, 14.0, 60, 10),
                InventoryItem("480000000081", "Great Taste Choco Coffee Twin Pack 60g", 11.0, 14.0, 60, 10),
                InventoryItem("480000000082", "Great Taste Granules Instant Coffee 50g", 38.0, 48.0, 30, 5),
                InventoryItem("480000000083", "Bear Brand Fortified Powdered Milk 33g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000084", "Bear Brand Fortified Powdered Milk 300g", 98.0, 118.0, 25, 5),
                InventoryItem("480000000085", "Bear Brand Fortified Powdered Milk 700g", 220.0, 255.0, 15, 3),
                InventoryItem("480000000086", "Bear Brand Adult Plus Milk Powder 300g", 110.0, 132.0, 20, 5),
                InventoryItem("480000000087", "Birch Tree Fortified Milk Powder 300g", 85.0, 102.0, 25, 5),
                InventoryItem("480000000088", "Anchor Full Cream Milk Powder 150g", 65.0, 78.0, 20, 5),
                InventoryItem("480000000089", "Nido Fortified Milk Powder 370g", 165.0, 195.0, 15, 3),
                InventoryItem("480000000090", "Alaska Fortified Powdered Milk 300g", 88.0, 105.0, 25, 5),
                InventoryItem("480000000091", "Alaska Evaporated Milk Can 370ml", 28.0, 35.0, 40, 8),
                InventoryItem("480000000092", "Alaska Condensed Milk Can 300ml", 42.0, 52.0, 35, 8),
                InventoryItem("480000000093", "Liberty Sweetened Condensed Milk 300ml", 35.0, 43.0, 35, 8),
                InventoryItem("480000000094", "Carnation Evaporated Milk Can 370ml", 29.0, 36.0, 35, 8),
                InventoryItem("480000000095", "Milo Chocolate Malt Drink Powder 24g", 8.0, 10.0, 80, 15),
                InventoryItem("480000000096", "Milo Chocolate Malt Drink Powder 300g", 92.0, 110.0, 25, 5),
                InventoryItem("480000000097", "Swiss Miss Hot Chocolate Mix 31g", 15.0, 19.0, 40, 8),
                InventoryItem("480000000098", "Ovaltine Choco Malt Drink 22g", 8.0, 10.0, 60, 10),
                InventoryItem("480000000099", "Coca-Cola Original Taste 330ml Can", 28.0, 35.0, 40, 10),
                InventoryItem("480000000100", "Coca-Cola Original Taste 1.5L PET", 62.0, 75.0, 30, 6),
                InventoryItem("480000000101", "Coca-Cola Zero Sugar 1.5L PET", 62.0, 75.0, 20, 5),
                InventoryItem("480000000102", "Royal Tru Orange 1.5L PET", 60.0, 72.0, 25, 5),
                InventoryItem("480000000103", "Sprite Lemon-Lime 1.5L PET", 60.0, 72.0, 25, 5),
                InventoryItem("480000000104", "Pepsi Cola 1.5L PET", 55.0, 68.0, 25, 5),
                InventoryItem("480000000105", "Mountain Dew Citrus 1.5L PET", 55.0, 68.0, 25, 5),
                InventoryItem("480000000106", "C2 Cool & Clean Green Tea Apple 500ml", 22.0, 28.0, 40, 8),
                InventoryItem("480000000107", "C2 Cool & Clean Green Tea Lemon 500ml", 22.0, 28.0, 40, 8),
                InventoryItem("480000000108", "Cobra Energy Drink Original 240ml", 16.0, 20.0, 50, 10),
                InventoryItem("480000000109", "Sting Energy Drink Red Power 330ml", 18.0, 22.0, 50, 10),
                InventoryItem("480000000110", "Gatorade Blue Bolt Sports Drink 500ml", 38.0, 46.0, 30, 5),

                // 4. Condiments, Sauces & Seasonings (111 - 150)
                InventoryItem("480000000111", "Datu Puti Soy Sauce Bottle 385ml", 18.0, 23.0, 40, 8),
                InventoryItem("480000000112", "Datu Puti Soy Sauce Bottle 1L", 42.0, 52.0, 25, 5),
                InventoryItem("480000000113", "Datu Puti Vinegar Bottle 385ml", 16.0, 20.0, 40, 8),
                InventoryItem("480000000114", "Datu Puti Vinegar Bottle 1L", 36.0, 45.0, 25, 5),
                InventoryItem("480000000115", "Silver Swan Soy Sauce Bottle 385ml", 18.0, 23.0, 40, 8),
                InventoryItem("480000000116", "Silver Swan Soy Sauce Bottle 1L", 42.0, 52.0, 25, 5),
                InventoryItem("480000000117", "Silver Swan Vinegar Bottle 385ml", 16.0, 20.0, 40, 8),
                InventoryItem("480000000118", "Silver Swan Vinegar Bottle 1L", 36.0, 45.0, 25, 5),
                InventoryItem("480000000119", "Mang Tomas All Purpose Sauce 325g", 32.0, 39.0, 30, 5),
                InventoryItem("480000000120", "Mang Tomas All Purpose Sauce Spicy 325g", 32.0, 39.0, 30, 5),
                InventoryItem("480000000121", "Knorr Liquid Seasoning Original 130ml", 35.0, 43.0, 30, 5),
                InventoryItem("480000000122", "Knorr Liquid Seasoning Chili 130ml", 35.0, 43.0, 30, 5),
                InventoryItem("480000000123", "Knorr Sinigang sa Sampalok Original 22g", 12.0, 15.0, 60, 10),
                InventoryItem("480000000124", "Knorr Sinigang sa Sampalok May Gabi 22g", 13.0, 16.0, 60, 10),
                InventoryItem("480000000125", "Knorr Pork Cubes 10g Pack of 6", 32.0, 39.0, 35, 8),
                InventoryItem("480000000126", "Knorr Beef Cubes 10g Pack of 6", 32.0, 39.0, 35, 8),
                InventoryItem("480000000127", "Knorr Chicken Cubes 10g Pack of 6", 32.0, 39.0, 35, 8),
                InventoryItem("480000000128", "Magic Sarap All in One Seasoning Sachet 8g", 4.0, 5.0, 120, 20),
                InventoryItem("480000000129", "Ajinomoto MSG Umami Seasoning 45g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000130", "Ajinomoto MSG Umami Seasoning 100g", 24.0, 30.0, 40, 8),
                InventoryItem("480000000131", "UFC Banana Ketchup Bottle 320g", 22.0, 28.0, 40, 8),
                InventoryItem("480000000132", "UFC Banana Ketchup Tamis Anghang 320g", 22.0, 28.0, 40, 8),
                InventoryItem("480000000133", "Papa Banana Ketchup Bottle 320g", 20.0, 25.0, 35, 8),
                InventoryItem("480000000134", "Del Monte Tomato Ketchup Bottle 320g", 28.0, 35.0, 30, 5),
                InventoryItem("480000000135", "Del Monte Filipino Style Spaghetti Sauce 250g", 24.0, 30.0, 35, 8),
                InventoryItem("480000000136", "Del Monte Filipino Style Spaghetti Sauce 1kg", 82.0, 98.0, 20, 5),
                InventoryItem("480000000137", "Clara Ole Spaghetti Sauce Sweet Style 1kg", 75.0, 90.0, 20, 5),
                InventoryItem("480000000138", "Del Monte Tomato Sauce Pouch 250g", 22.0, 28.0, 35, 8),
                InventoryItem("480000000139", "Del Monte Tomato Sauce Pouch 1kg", 78.0, 92.0, 20, 5),
                InventoryItem("480000000140", "Lee Kum Kee Premium Oyster Sauce 255g", 52.0, 65.0, 25, 5),
                InventoryItem("480000000141", "Mama Sitas Barbecue Marinade 350ml", 45.0, 56.0, 25, 5),
                InventoryItem("480000000142", "Minola Premium Cooking Oil Bottle 500ml", 58.0, 70.0, 25, 5),
                InventoryItem("480000000143", "Golden Fiesta Palm Oil Bottle 1L", 92.0, 110.0, 20, 5),
                InventoryItem("480000000144", "Baguio Pure Coconut Oil Bottle 1L", 115.0, 138.0, 15, 3),
                InventoryItem("480000000145", "UFC Green Peas Can 225g", 22.0, 28.0, 30, 5),
                InventoryItem("480000000146", "Del Monte Whole Kernel Corn 425g", 38.0, 46.0, 25, 5),
                InventoryItem("480000000147", "Jolly Whole Mushroom 400g", 42.0, 52.0, 25, 5),
                InventoryItem("480000000148", "McCormick Black Pepper Powder 30g", 28.0, 35.0, 30, 5),
                InventoryItem("480000000149", "McCormick Garlic Powder 30g", 32.0, 40.0, 25, 5),
                InventoryItem("480000000150", "Iodized Salt Rock Salt Bag 500g", 12.0, 15.0, 50, 10),

                // 5. Snacks, Biscuits & Confectionery (151 - 190)
                InventoryItem("480000000151", "Piattos Cheese Potato Chips 85g", 32.0, 39.0, 35, 8),
                InventoryItem("480000000152", "Piattos Sour Cream & Onion 85g", 32.0, 39.0, 35, 8),
                InventoryItem("480000000153", "Piattos Roadhouse Barbecue 85g", 32.0, 39.0, 35, 8),
                InventoryItem("480000000154", "Nova Country Cheddar Multigrain Chips 78g", 30.0, 38.0, 35, 8),
                InventoryItem("480000000155", "Vcut Potato Chips Cheese 60g", 28.0, 35.0, 35, 8),
                InventoryItem("480000000156", "Clover Chips Cheese Snack 85g", 30.0, 37.0, 35, 8),
                InventoryItem("480000000157", "Clover Chips Barbecue Snack 85g", 30.0, 37.0, 35, 8),
                InventoryItem("480000000158", "Boy Bawang Garlic Cornick 100g", 18.0, 23.0, 40, 8),
                InventoryItem("480000000159", "Boy Bawang Spicy Garlic Cornick 100g", 18.0, 23.0, 40, 8),
                InventoryItem("480000000160", "Chippy Barbecue Corn Chips 110g", 30.0, 38.0, 35, 8),
                InventoryItem("480000000161", "Chippy Red Hot Chili Corn Chips 110g", 30.0, 38.0, 35, 8),
                InventoryItem("480000000162", "Roller Coaster Cheese Ring Snack 85g", 28.0, 35.0, 35, 8),
                InventoryItem("480000000163", "Oishi Prawn Crackers Original 60g", 18.0, 23.0, 40, 8),
                InventoryItem("480000000164", "Oishi Kridser Spicy Seafood 60g", 18.0, 23.0, 40, 8),
                InventoryItem("480000000165", "SkyFlakes Crackers Single Pack 25g", 6.0, 8.0, 100, 20),
                InventoryItem("480000000166", "SkyFlakes Crackers Condensada Pack 25g", 7.0, 9.0, 80, 15),
                InventoryItem("480000000167", "Magic Flakes Cheese Crackers 28g", 6.0, 8.0, 80, 15),
                InventoryItem("480000000168", "Rebisco Crackers Plain Pack 33g", 6.0, 8.0, 80, 15),
                InventoryItem("480000000169", "Rebisco Sandwich Cream Chocolate 32g", 7.0, 9.0, 80, 15),
                InventoryItem("480000000170", "Fita Crackers Single Pack 30g", 7.0, 9.0, 80, 15),
                InventoryItem("480000000171", "MY San Graham Crackers Plain 200g", 38.0, 46.0, 30, 5),
                InventoryItem("480000000172", "MY San Graham Crackers Honey 200g", 38.0, 46.0, 30, 5),
                InventoryItem("480000000173", "Fudgee Barr Chocolate 10s Pack 380g", 68.0, 82.0, 25, 5),
                InventoryItem("480000000174", "Fudgee Barr Salted Caramel 10s 380g", 68.0, 82.0, 25, 5),
                InventoryItem("480000000175", "Rebisco Combi Wafer Roll Chocolate 24g", 6.0, 8.0, 80, 15),
                InventoryItem("480000000176", "Super Crunch Cheese Snack 60g", 15.0, 19.0, 40, 8),
                InventoryItem("480000000177", "Oishi Pillows Chocolate Filled 38g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000178", "Oishi Pillows Ube Filled 38g", 12.0, 15.0, 50, 10),
                InventoryItem("480000000179", "Cloud 9 Chocolate Bar Classic 28g", 9.0, 12.0, 60, 12),
                InventoryItem("480000000180", "Cloud 9 Overload Chocolate Bar 50g", 16.0, 20.0, 40, 8),
                InventoryItem("480000000181", "Flat Tops Milk Chocolate Pack 150g", 42.0, 52.0, 30, 5),
                InventoryItem("480000000182", "Curly Tops Milk Chocolate Pack 150g", 42.0, 52.0, 30, 5),
                InventoryItem("480000000183", "Choc Nut Original Peanut Chocolate 24s 200g", 48.0, 58.0, 30, 5),
                InventoryItem("480000000184", "Hany Milk Peanut Chocolate 24s 200g", 45.0, 55.0, 30, 5),
                InventoryItem("480000000185", "Mentos Mint Candy Roll 37g", 15.0, 19.0, 40, 8),
                InventoryItem("480000000186", "Maxx Menthol Candy Mentholated 50s Bag", 32.0, 40.0, 30, 5),
                InventoryItem("480000000187", "Stik-O Wafer Sticks Chocolate Jar 380g", 75.0, 90.0, 20, 5),
                InventoryItem("480000000188", "Regent Cheese Rings Snack 60g", 15.0, 19.0, 40, 8),
                InventoryItem("480000000189", "Voice Combo Sandwich Biscuits 30g", 7.0, 9.0, 60, 10),
                InventoryItem("480000000190", "Pretzels Chocolate Biscuits 40g", 12.0, 15.0, 50, 10),

                // 6. Personal Care, Soaps & Hygiene (191 - 230)
                InventoryItem("480000000191", "Safeguard Pure White Soap 130g", 38.0, 46.0, 40, 8),
                InventoryItem("480000000192", "Safeguard Lemon Fresh Soap 130g", 38.0, 46.0, 40, 8),
                InventoryItem("480000000193", "Safeguard Floral Pink Soap 130g", 38.0, 46.0, 40, 8),
                InventoryItem("480000000194", "Safeguard Body Wash Pure White 720ml", 195.0, 230.0, 15, 3),
                InventoryItem("480000000195", "Palmolive Intensive Moisture Shampoo 180ml", 85.0, 102.0, 25, 5),
                InventoryItem("480000000196", "Palmolive Anti-Dandruff Shampoo 180ml", 85.0, 102.0, 25, 5),
                InventoryItem("480000000197", "Sunsilk Smooth & Manageable Shampoo 180ml", 82.0, 98.0, 25, 5),
                InventoryItem("480000000198", "Sunsilk Strong & Long Shampoo 180ml", 82.0, 98.0, 25, 5),
                InventoryItem("480000000199", "Head & Shoulders Cool Menthol Shampoo 170ml", 110.0, 132.0, 20, 5),
                InventoryItem("480000000200", "Head & Shoulders Smooth & Silky Shampoo 170ml", 110.0, 132.0, 20, 5),
                InventoryItem("480000000201", "Cream Silk Standout Straight Conditioner 180ml", 92.0, 110.0, 25, 5),
                InventoryItem("480000000202", "Cream Silk Hair Fall Defense Conditioner 180ml", 92.0, 110.0, 25, 5),
                InventoryItem("480000000203", "Colgate Triple Action Toothpaste 145g", 78.0, 92.0, 30, 5),
                InventoryItem("480000000204", "Colgate Great Regular Flavor Toothpaste 145g", 78.0, 92.0, 30, 5),
                InventoryItem("480000000205", "Close-Up Ever Fresh Toothpaste Red 120g", 68.0, 82.0, 30, 5),
                InventoryItem("480000000206", "Close-Up Menthol Fresh Toothpaste 120g", 68.0, 82.0, 30, 5),
                InventoryItem("480000000207", "Oral-B Shiny Clean Toothbrush Soft 1s", 28.0, 35.0, 40, 8),
                InventoryItem("480000000208", "Rexona Women Deodorant Powder Dry Roll-On 50ml", 85.0, 102.0, 20, 5),
                InventoryItem("480000000209", "Rexona Men Deodorant Roll-On Ice Cool 50ml", 85.0, 102.0, 20, 5),
                InventoryItem("480000000210", "Nivea Men Deodorant Cool Kick Roll-On 50ml", 92.0, 110.0, 20, 5),
                InventoryItem("480000000211", "Eskinol Ice Pore Minimizing Cleanser 135ml", 42.0, 52.0, 25, 5),
                InventoryItem("480000000212", "Ponds Bright Beauty Facial Foam 100g", 125.0, 150.0, 15, 3),
                InventoryItem("480000000213", "Master Oil Control Deep Cleanser 135ml", 58.0, 70.0, 20, 5),
                InventoryItem("480000000214", "Block & White Papaya Lotion 200ml", 95.0, 115.0, 20, 5),
                InventoryItem("480000000215", "Vaseline Healthy Bright Lotion 200ml", 135.0, 160.0, 15, 3),
                InventoryItem("480000000216", "Johnsons Baby Powder White 100g", 38.0, 46.0, 30, 5),
                InventoryItem("480000000217", "Johnsons Baby Soap Regular 100g", 32.0, 39.0, 30, 5),
                InventoryItem("480000000218", "Charmee Cottony Soft Sanitary Pads 8s", 28.0, 35.0, 35, 8),
                InventoryItem("480000000219", "Whisper Skin Love Sanitary Pads 8s", 58.0, 70.0, 25, 5),
                InventoryItem("480000000220", "Modess Cottony Soft Sanitary Pads 8s", 38.0, 46.0, 30, 5),
                InventoryItem("480000000221", "Kleenex Facial Tissues Soft 100s", 45.0, 55.0, 25, 5),
                InventoryItem("480000000222", "Sanicare Facial Tissue 3-ply 100s", 48.0, 58.0, 25, 5),
                InventoryItem("480000000223", "Green Cross Isopropyl Alcohol 70% 250ml", 38.0, 46.0, 35, 8),
                InventoryItem("480000000224", "Green Cross Isopropyl Alcohol 70% 500ml", 68.0, 82.0, 25, 5),
                InventoryItem("480000000225", "Casino Ethyl Alcohol 70% 500ml", 65.0, 78.0, 25, 5),
                InventoryItem("480000000226", "Silka Papaya Whitening Soap 135g", 35.0, 43.0, 30, 5),
                InventoryItem("480000000227", "Kojie San Skin Lightening Soap 135g", 58.0, 70.0, 25, 5),
                InventoryItem("480000000228", "Bioderm Germicidal Soap Pink 135g", 25.0, 32.0, 35, 8),
                InventoryItem("480000000229", "Lactacyd Feminine Wash Pro Sensitive 150ml", 120.0, 145.0, 15, 3),
                InventoryItem("480000000230", "PH Care Feminine Wash Floral 150ml", 98.0, 118.0, 20, 5),

                // 7. Laundry, Soaps & Cleaners (231 - 265)
                InventoryItem("480000000231", "Surf Powder Detergent Cherry Blossom 1kg", 95.0, 115.0, 30, 5),
                InventoryItem("480000000232", "Surf Powder Detergent Sun Fresh 1kg", 95.0, 115.0, 30, 5),
                InventoryItem("480000000233", "Breeze Powder Detergent Stain Action 1kg", 135.0, 160.0, 25, 5),
                InventoryItem("480000000234", "Tide Powder Detergent Original 1kg", 125.0, 150.0, 25, 5),
                InventoryItem("480000000235", "Ariel Powder Detergent Sunrise Fresh 1kg", 145.0, 175.0, 20, 5),
                InventoryItem("480000000236", "Champion Powder Detergent Citrus 1kg", 88.0, 105.0, 30, 5),
                InventoryItem("480000000237", "Pride Powder Detergent Original 1kg", 82.0, 98.0, 30, 5),
                InventoryItem("480000000238", "Surf Fabric Conditioner Blossom Fresh 800ml", 78.0, 95.0, 25, 5),
                InventoryItem("480000000239", "Downy Fabric Conditioner Sunrise Fresh 900ml", 128.0, 152.0, 20, 5),
                InventoryItem("480000000240", "Downy Fabric Conditioner Passion 900ml", 128.0, 152.0, 20, 5),
                InventoryItem("480000000241", "Smart Dishwashing Liquid Lemon 250ml", 35.0, 43.0, 30, 5),
                InventoryItem("480000000242", "Joy Dishwashing Liquid Lime 250ml", 48.0, 58.0, 30, 5),
                InventoryItem("480000000243", "Joy Dishwashing Liquid Lemon 250ml", 48.0, 58.0, 30, 5),
                InventoryItem("480000000244", "Joy Dishwashing Paste Lemon 200g", 28.0, 35.0, 35, 8),
                InventoryItem("480000000245", "Axion Dishwashing Paste Lemon 190g", 30.0, 37.0, 35, 8),
                InventoryItem("480000000246", "Zonrox Bleach Original 500ml", 25.0, 32.0, 35, 8),
                InventoryItem("480000000247", "Zonrox Bleach Gentle Clean 500ml", 25.0, 32.0, 35, 8),
                InventoryItem("480000000248", "Zonrox Color Bleach 500ml", 38.0, 46.0, 25, 5),
                InventoryItem("480000000249", "Domex Thick Toilet Cleaner 500ml", 78.0, 95.0, 20, 5),
                InventoryItem("480000000250", "Lysol Disinfectant Spray Crisp Linen 170g", 185.0, 215.0, 15, 3),
                InventoryItem("480000000251", "Baygon Multi Insect Killer Aerosol 300ml", 165.0, 195.0, 15, 3),
                InventoryItem("480000000252", "Baygon Katol Mosquito Coil 10s Pack", 18.0, 23.0, 40, 8),
                InventoryItem("480000000253", "Off Insect Repellent Lotion 50ml", 68.0, 82.0, 25, 5),
                InventoryItem("480000000254", "Scotch Brite Heavy Duty Sponge 1s", 28.0, 35.0, 40, 8),
                InventoryItem("480000000255", "Pledge Furniture Polish Lemon 330ml", 195.0, 230.0, 12, 3),
                InventoryItem("480000000256", "Glade Air Freshener Spray Lemon 300ml", 145.0, 175.0, 15, 3),
                InventoryItem("480000000257", "Bareta Laundry Soap Blue Bar 350g", 20.0, 25.0, 40, 8),
                InventoryItem("480000000258", "Perla Laundry Soap Bar Original 90g", 18.0, 23.0, 40, 8),
                InventoryItem("480000000259", "Champion Laundry Soap Bar Blue 380g", 22.0, 27.0, 40, 8),
                InventoryItem("480000000260", "Tide Laundry Soap Bar Original 380g", 25.0, 32.0, 35, 8),
                InventoryItem("480000000261", "Solbac Disinfectant Spray Citrus 300ml", 155.0, 185.0, 15, 3),
                InventoryItem("480000000262", "Mr Muscle All Purpose Cleaner 500ml", 85.0, 102.0, 20, 5),
                InventoryItem("480000000263", "Matchstick Mambor Safety Matches 10s Pack", 12.0, 15.0, 50, 10),
                InventoryItem("480000000264", "Kitchen Scrub Sponge Heavy Duty 3s", 32.0, 40.0, 30, 5),
                InventoryItem("480000000265", "Trash Bag Black Medium Size 10s Pack", 35.0, 43.0, 30, 5),

                // 8. Cooking Ingredients, Dairy & Baking (266 - 285)
                InventoryItem("480000000266", "Sinag Dinorado Premium Special Rice 5kg", 280.0, 325.0, 15, 3),
                InventoryItem("480000000267", "Sinag Jasmine Fragrant Premium Rice 5kg", 290.0, 340.0, 15, 3),
                InventoryItem("480000000268", "Angel Evaporada Filled Milk Can 410ml", 28.0, 35.0, 35, 8),
                InventoryItem("480000000269", "Angel Kremdensada 2-in-1 Can 410ml", 48.0, 58.0, 30, 5),
                InventoryItem("480000000270", "Nestle All Purpose Cream Pack 250ml", 58.0, 70.0, 30, 5),
                InventoryItem("480000000271", "Eden Cheese Original Bar 165g", 52.0, 63.0, 35, 8),
                InventoryItem("480000000272", "Eden Cheese Melt Meltable Bar 165g", 58.0, 70.0, 30, 5),
                InventoryItem("480000000273", "Cheez Whiz Original Cheese Spread 220g", 78.0, 92.0, 25, 5),
                InventoryItem("480000000274", "Cheez Whiz Pimiento Cheese Spread 220g", 78.0, 92.0, 25, 5),
                InventoryItem("480000000275", "Magnolia Quickmelt Cheese Bar 165g", 62.0, 75.0, 25, 5),
                InventoryItem("480000000276", "Magnolia Gold Butter Salted Block 225g", 120.0, 145.0, 15, 3),
                InventoryItem("480000000277", "Star Margarine Sweet Blend 250g", 38.0, 46.0, 30, 5),
                InventoryItem("480000000278", "Dari Creme Classic Margarine Tub 200g", 48.0, 58.0, 25, 5),
                InventoryItem("480000000279", "Del Monte Pineapple Tidbits Can 115g", 18.0, 23.0, 35, 8),
                InventoryItem("480000000280", "Del Monte Pineapple Slices Can 234g", 32.0, 39.0, 30, 5),
                InventoryItem("480000000281", "Del Monte Pineapple Juice 100% Can 240ml", 25.0, 32.0, 35, 8),
                InventoryItem("480000000282", "Del Monte Fruit Cocktail Can 832g", 85.0, 102.0, 20, 5),
                InventoryItem("480000000283", "Todays Mixed Fruit Cocktail Can 832g", 72.0, 88.0, 20, 5),
                InventoryItem("480000000284", "Clara Ole Jam Strawberry Spread 320g", 78.0, 95.0, 20, 5),
                InventoryItem("480000000285", "Lilys Peanut Butter Jar Original 170g", 42.0, 52.0, 25, 5),

                // 9. Frozen, Chilled & Fresh (286 - 305)
                InventoryItem("480000000286", "Skippy Peanut Butter Creamy Jar 340g", 165.0, 195.0, 15, 3),
                InventoryItem("480000000287", "Nutella Hazelnut Cocoa Spread Jar 200g", 145.0, 175.0, 15, 3),
                InventoryItem("480000000288", "Maya Hotcake Mix Original Fluffy 200g", 38.0, 46.0, 30, 5),
                InventoryItem("480000000289", "White King Hotcake Mix Original 200g", 32.0, 39.0, 30, 5),
                InventoryItem("480000000290", "Crispy Fry Seasoned Mix Original 62g", 15.0, 19.0, 50, 10),
                InventoryItem("480000000291", "Crispy Fry Seasoned Mix Garlic 62g", 15.0, 19.0, 50, 10),
                InventoryItem("480000000292", "Crispy Fry Seasoned Mix Spicy 62g", 15.0, 19.0, 50, 10),
                InventoryItem("480000000293", "Selecta Fortified Milk Whole Liquid 1L", 88.0, 105.0, 20, 5),
                InventoryItem("480000000294", "Selecta Ice Cream 3-in-1 Avocado Mango 1.3L", 185.0, 215.0, 12, 3),
                InventoryItem("480000000295", "Selecta Ice Cream Double Dutch 1.3L", 195.0, 225.0, 12, 3),
                InventoryItem("480000000296", "Magnolia Fresh Milk Whole Liquid 1L", 92.0, 110.0, 20, 5),
                InventoryItem("480000000297", "Magnolia Chocolait Milk Drink 250ml", 28.0, 35.0, 30, 5),
                InventoryItem("480000000298", "Yakult Probiotic Cultured Milk 5x80ml", 48.0, 58.0, 30, 6),
                InventoryItem("480000000299", "Delight Probiotic Cultured Drink 5x100ml", 42.0, 52.0, 30, 6),
                InventoryItem("480000000300", "CDO Funtastyk Young Pork Tocino 225g", 72.0, 85.0, 25, 5),
                InventoryItem("480000000301", "Pampangas Best Original Pork Tocino 225g", 78.0, 92.0, 25, 5),
                InventoryItem("480000000302", "CDO Skinless Pork Longganisa 225g", 52.0, 63.0, 25, 5),
                InventoryItem("480000000303", "Purefoods Classic Sliced Bacon 200g", 145.0, 170.0, 15, 3),
                InventoryItem("480000000304", "San Miguel Pure Foods Tender Juicy Hotdog 1kg", 185.0, 215.0, 20, 4),
                InventoryItem("480000000305", "CDO Bibbo Hotdog Jumbo Cheesed 1kg", 165.0, 195.0, 20, 4),

                // 10. Beverages, Drinks & Liquors (306 - 350)
                InventoryItem("480000000306", "Coca-Cola Original Taste 1.5L", 65.0, 75.0, 40, 8),
                InventoryItem("480000000307", "Coca-Cola Zero Sugar 1.5L", 65.0, 75.0, 30, 5),
                InventoryItem("480000000308", "Sprite Lemon-Lime 1.5L", 65.0, 75.0, 35, 8),
                InventoryItem("480000000309", "Royal Tru Orange 1.5L", 65.0, 75.0, 35, 8),
                InventoryItem("480000000310", "Pepsi Regular 1.5L", 60.0, 70.0, 30, 5),
                InventoryItem("480000000311", "Mountain Dew Citrus 1.5L", 60.0, 70.0, 30, 5),
                InventoryItem("480000000312", "7Up Lemon Lime 1.5L", 60.0, 70.0, 25, 5),
                InventoryItem("480000000313", "Coca-Cola Original Can 320ml", 32.0, 40.0, 48, 10),
                InventoryItem("480000000314", "Sprite Can 320ml", 32.0, 40.0, 48, 10),
                InventoryItem("480000000315", "Royal Tru Orange Can 320ml", 32.0, 40.0, 48, 10),
                InventoryItem("480000000316", "C2 Cool & Clean Green Tea Apple 500ml", 22.0, 28.0, 50, 10),
                InventoryItem("480000000317", "C2 Cool & Clean Green Tea Lemon 500ml", 22.0, 28.0, 50, 10),
                InventoryItem("480000000318", "Cobra Energy Drink Original 350ml", 18.0, 23.0, 60, 12),
                InventoryItem("480000000319", "Cobra Energy Drink Smart 350ml", 18.0, 23.0, 50, 10),
                InventoryItem("480000000320", "Sting Energy Drink Strawberry 330ml", 18.0, 23.0, 60, 12),
                InventoryItem("480000000321", "Gatorade Blue Bolt Sports Drink 500ml", 38.0, 46.0, 35, 8),
                InventoryItem("480000000322", "Gatorade Citrus Quencher 500ml", 38.0, 46.0, 35, 8),
                InventoryItem("480000000323", "Pocari Sweat Ion Supply Drink 500ml", 42.0, 52.0, 30, 5),
                InventoryItem("480000000324", "Absolute Purified Drinking Water 500ml", 12.0, 16.0, 80, 15),
                InventoryItem("480000000325", "Absolute Purified Drinking Water 1L", 22.0, 28.0, 50, 10),
                InventoryItem("480000000326", "Nature Spring Mineral Water 500ml", 10.0, 14.0, 80, 15),
                InventoryItem("480000000327", "Nature Spring Mineral Water 1L", 18.0, 24.0, 50, 10),
                InventoryItem("480000000328", "Wilkins Pure Purified Water 500ml", 14.0, 18.0, 60, 12),
                InventoryItem("480000000329", "Wilkins Pure Purified Water 1L", 24.0, 30.0, 40, 8),
                InventoryItem("480000000330", "Zest-O Orange Juice Drink 200ml", 9.0, 12.0, 80, 15),
                InventoryItem("480000000331", "Zest-O Mango Juice Drink 200ml", 9.0, 12.0, 80, 15),
                InventoryItem("480000000332", "Zest-O Apple Juice Drink 200ml", 9.0, 12.0, 80, 15),
                InventoryItem("480000000333", "Tang Powdered Juice Drink Orange 20g", 12.0, 16.0, 80, 15),
                InventoryItem("480000000334", "Tang Powdered Juice Drink Pineapple 20g", 12.0, 16.0, 80, 15),
                InventoryItem("480000000335", "Eight O Clock Mango Juice Mix 25g", 11.0, 15.0, 60, 10),
                InventoryItem("480000000336", "San Miguel Pale Pilsen Beer Can 330ml", 45.0, 55.0, 48, 12),
                InventoryItem("480000000337", "San Mig Light Beer Can 330ml", 48.0, 58.0, 48, 12),
                InventoryItem("480000000338", "Red Horse Beer Extra Strong Can 330ml", 48.0, 58.0, 48, 12),
                InventoryItem("480000000339", "Red Horse Beer Stallion Bottle 500ml", 55.0, 68.0, 36, 12),
                InventoryItem("480000000340", "Emperador Light Brandy 750ml", 125.0, 148.0, 24, 6),
                InventoryItem("480000000341", "Ginebra San Miguel Gin 350ml", 52.0, 65.0, 30, 6),
                InventoryItem("480000000342", "GSM Blue Flavored Gin Mojito 700ml", 115.0, 138.0, 18, 4),
                InventoryItem("480000000343", "Fundador Light Brandy 750ml", 280.0, 330.0, 12, 3),
                InventoryItem("480000000344", "Tanduay Rhum 5 Years 750ml", 135.0, 160.0, 20, 5),
                InventoryItem("480000000345", "Carlo Rossi Red Wine 750ml", 320.0, 380.0, 10, 2),
                InventoryItem("480000000346", "Mogu Mogu Nata De Coco Strawberry 320ml", 38.0, 48.0, 30, 6),
                InventoryItem("480000000347", "Mogu Mogu Nata De Coco Lychee 320ml", 38.0, 48.0, 30, 6),
                InventoryItem("480000000348", "Milku Milk Drink Chocolate 200ml", 12.0, 16.0, 60, 12),
                InventoryItem("480000000349", "Smart C 500 Lemon Vitamin Drink 500ml", 28.0, 35.0, 30, 6),
                InventoryItem("480000000350", "Real Leaf Green Tea Honey Lemon 480ml", 26.0, 32.0, 30, 6),

                // 11. Household, Medicine & Hardware (351 - 421)
                InventoryItem("480000000351", "Biogesic Paracetamol 500mg Tablet 1s", 5.0, 8.0, 100, 20),
                InventoryItem("480000000352", "Neozep Forte Cold Medicine Tablet 1s", 6.0, 9.0, 100, 20),
                InventoryItem("480000000353", "Decolgen Forte Cold Medicine Tablet 1s", 6.0, 9.0, 100, 20),
                InventoryItem("480000000354", "Alaxan FR Muscle Pain Tablet 1s", 8.0, 12.0, 100, 20),
                InventoryItem("480000000355", "Medicol Advance 200mg Softgel 1s", 7.0, 11.0, 100, 20),
                InventoryItem("480000000356", "Kremil-S Antacid Tablet 1s", 7.0, 10.0, 100, 20),
                InventoryItem("480000000357", "Diatabs Anti Diarrhea Capsule 1s", 7.0, 10.0, 100, 20),
                InventoryItem("480000000358", "Solmux Carbocisteine 500mg Capsule 1s", 10.0, 14.0, 80, 15),
                InventoryItem("480000000359", "Tuseran Forte Cough Cold Capsule 1s", 9.0, 13.0, 80, 15),
                InventoryItem("480000000360", "Enervon-C Multivitamins Tablet 1s", 7.0, 10.0, 100, 20),
                InventoryItem("480000000361", "Conzace Softgel Multivitamins 1s", 12.0, 16.0, 80, 15),
                InventoryItem("480000000362", "Revicon Forte Multivitamins Tablet 1s", 6.0, 9.0, 100, 20),
                InventoryItem("480000000363", "Band-Aid Adhesive Strip First Aid 10s", 20.0, 28.0, 50, 10),
                InventoryItem("480000000364", "Efficascent Oil Regular Relief 50ml", 35.0, 45.0, 30, 5),
                InventoryItem("480000000365", "Efficascent Oil Extreme Relief 50ml", 42.0, 52.0, 30, 5),
                InventoryItem("480000000366", "Vicks Vaporub Ointment Jar 10g", 45.0, 55.0, 25, 5),
                InventoryItem("480000000367", "White Flower Ointment Oil 2.5ml", 38.0, 48.0, 30, 5),
                InventoryItem("480000000368", "Katinko Ointment Pain Relief 10g", 32.0, 40.0, 30, 5),
                InventoryItem("480000000369", "Salonpas Pain Relief Patch 10s Pack", 42.0, 52.0, 30, 5),
                InventoryItem("480000000370", "Omega Pain Killer Liniment 60ml", 38.0, 48.0, 25, 5),
                InventoryItem("480000000371", "Rhea Isopropyl Alcohol 70% 150ml", 28.0, 35.0, 40, 8),
                InventoryItem("480000000372", "Casino Ethyl Alcohol 70% 150ml", 30.0, 38.0, 40, 8),
                InventoryItem("480000000373", "Green Cross Isopropyl Alcohol 70% 250ml", 48.0, 58.0, 35, 8),
                InventoryItem("480000000374", "Cotton Balls Sanicare 50s Pack", 22.0, 28.0, 40, 8),
                InventoryItem("480000000375", "Sanicare Cotton Buds 108 Tips", 18.0, 24.0, 50, 10),
                InventoryItem("480000000376", "Sanicare Cleansing Wipes Unscented 80s", 78.0, 95.0, 20, 5),
                InventoryItem("480000000377", "Sanicare Facial Tissue 2-Ply 100s", 38.0, 48.0, 30, 6),
                InventoryItem("480000000378", "Joy Paper Plates 9 Inch 10s Pack", 25.0, 32.0, 40, 8),
                InventoryItem("480000000379", "Joy Plastic Cups 8oz 25s Pack", 28.0, 35.0, 40, 8),
                InventoryItem("480000000380", "Joy Plastic Spoon White 25s Pack", 22.0, 28.0, 40, 8),
                InventoryItem("480000000381", "Joy Plastic Fork White 25s Pack", 22.0, 28.0, 40, 8),
                InventoryItem("480000000382", "Drinking Straw Plastic Colorful 100s", 15.0, 20.0, 50, 10),
                InventoryItem("480000000383", "Ice Bag Plastic Transparent 100s", 18.0, 24.0, 50, 10),
                InventoryItem("480000000384", "Sando Bag White Small 100s Pack", 25.0, 32.0, 40, 8),
                InventoryItem("480000000385", "Sando Bag White Medium 100s Pack", 35.0, 44.0, 40, 8),
                InventoryItem("480000000386", "Sando Bag White Large 100s Pack", 48.0, 60.0, 30, 6),
                InventoryItem("480000000387", "Candle White Esperma No 3 20s Pack", 32.0, 40.0, 30, 5),
                InventoryItem("480000000388", "Candle White Esperma No 5 20s Pack", 45.0, 55.0, 25, 5),
                InventoryItem("480000000389", "Energizer AA Heavy Duty Battery 2s", 38.0, 48.0, 30, 6),
                InventoryItem("480000000390", "Energizer AAA Heavy Duty Battery 2s", 38.0, 48.0, 30, 6),
                InventoryItem("480000000391", "Eveready D Size Super Heavy Duty 2s", 58.0, 70.0, 20, 4),
                InventoryItem("480000000392", "Panasonic AA Battery Gold 2s", 28.0, 35.0, 35, 8),
                InventoryItem("480000000393", "Super Glue Fast Bonding Gel 3g", 15.0, 20.0, 50, 10),
                InventoryItem("480000000394", "Pioneer Epoxeastic Steel Gum 15g", 48.0, 60.0, 20, 5),
                InventoryItem("480000000395", "Electrical Tape Black Insulation 18mm", 18.0, 25.0, 40, 8),
                InventoryItem("480000000396", "Packaging Tape Transparent 2 Inch 50m", 35.0, 45.0, 30, 6),
                InventoryItem("480000000397", "Masking Tape White 1 Inch 20m", 22.0, 28.0, 35, 8),
                InventoryItem("480000000398", "Scissort Student Craft Stainless Steel 1s", 25.0, 32.0, 30, 5),
                InventoryItem("480000000399", "HB Pencil Mongol No 2 Black 12s Box", 78.0, 95.0, 20, 5),
                InventoryItem("480000000400", "Ballpen Pilot G2 Gel Black 0.7mm", 48.0, 58.0, 30, 6),
                InventoryItem("480000000401", "Ballpen Faber Castell Black 0.5mm 10s", 85.0, 105.0, 20, 5),
                InventoryItem("480000000402", "Correction Tape Paper Mate 5mmx6m", 32.0, 40.0, 30, 5),
                InventoryItem("480000000403", "Notebook Composition 80 Leaves 1s", 18.0, 24.0, 50, 10),
                InventoryItem("480000000404", "Notebook Writing 80 Leaves 1s", 18.0, 24.0, 50, 10),
                InventoryItem("480000000405", "Pad Paper Intermediate 80 Leaves 1s", 28.0, 35.0, 40, 8),
                InventoryItem("480000000406", "Crayola Crayons Regular 8 Colors Box", 28.0, 35.0, 30, 5),
                InventoryItem("480000000407", "Short Bond Paper 70gsm 50s Pack", 35.0, 44.0, 30, 6),
                InventoryItem("480000000408", "Long Bond Paper 70gsm 50s Pack", 38.0, 48.0, 30, 6),
                InventoryItem("480000000409", "Plastic Envelope Short Transparent 1s", 12.0, 16.0, 50, 10),
                InventoryItem("480000000410", "Plastic Envelope Long Transparent 1s", 14.0, 18.0, 50, 10),
                InventoryItem("480000000411", "Ruler Plastic Transparent 12 Inch 1s", 12.0, 16.0, 50, 10),
                InventoryItem("480000000412", "Eraser HB White Rubber 1s", 8.0, 12.0, 60, 12),
                InventoryItem("480000000413", "Pencil Sharpener Single Hole 1s", 10.0, 14.0, 60, 12),
                InventoryItem("480000000414", "Permanent Marker Sharpie Black Fine Point 1s", 38.0, 48.0, 30, 6),
                InventoryItem("480000000415", "Whiteboard Marker Pilot Black 1s", 35.0, 44.0, 30, 6),
                InventoryItem("480000000416", "Highlighter Stabilo Boss Yellow 1s", 42.0, 52.0, 25, 5),
                InventoryItem("480000000417", "Glue Stick Elmer Non Toxic 8g", 22.0, 28.0, 30, 6),
                InventoryItem("480000000418", "Paper Clips Gem 33mm 100s Box", 18.0, 24.0, 40, 8),
                InventoryItem("480000000419", "Thumbtacks Brass Standard 100s Box", 18.0, 24.0, 40, 8),
                InventoryItem("480000000420", "Stapler Heavy Duty No 10 With Staples 1s", 58.0, 72.0, 20, 4),
                InventoryItem("480000000421", "Staple Wire Refill No 10 1000s Box", 15.0, 20.0, 40, 8)
            )

            items.forEach { item ->
                val imgUrl = getPhGroceryImageUrl(item.barcode, item.name)
                val values = ContentValues().apply {
                    put("barcode", item.barcode)
                    put("name", item.name)
                    put("purchase_cost", item.purchaseCost)
                    put("selling_price", item.sellingPrice)
                    put("stock_quantity", item.stockQuantity)
                    put("low_stock_limit", item.lowStockLimit)
                    put("recommended_stock", item.recommendedStock)
                    put("added_at", item.addedAt.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
                    put("unit", item.unit)
                    put("category", item.effectiveCategory)
                    put("image_path", imgUrl)
                }
                db.insertWithOnConflict("inventory", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
        }

        fun seedHardwareInventory(db: SQLiteDatabase) {
            val items = listOf(
                // 1. Cement & Aggregates (501 - 510)
                InventoryItem("480000000501", "Holcim Excel Portland Cement 40kg", 215.0, 240.0, 50, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000502", "Republic Portland Cement 40kg", 210.0, 235.0, 50, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000503", "Eagle Premium Cement 40kg", 205.0, 230.0, 50, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000504", "Pozzolan Cement 40kg Bag", 195.0, 220.0, 40, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000505", "Tile Adhesive Heavy Duty 25kg", 180.0, 210.0, 30, 5, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000506", "Tile Grout Waterproof White 2kg", 55.0, 75.0, 40, 8, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000507", "Skim Coat Fine White 20kg", 320.0, 380.0, 25, 5, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000508", "Washed Sand (Screened) 1 cu.m", 850.0, 1050.0, 10, 2, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000509", "Gravel 3/4 Aggregate 1 cu.m", 950.0, 1200.0, 10, 2, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000510", "Concrete Hollow Blocks CHB 4 inch", 12.0, 16.0, 500, 100, unit = "pcs", category = "Building Materials"),

                // 2. Steel & Roofing (511 - 520)
                InventoryItem("480000000511", "Deformed Steel Bar 10mm x 6m Grade 33", 145.0, 168.0, 100, 20, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000512", "Deformed Steel Bar 12mm x 6m Grade 33", 205.0, 238.0, 80, 15, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000513", "Deformed Steel Bar 16mm x 6m Grade 40", 370.0, 425.0, 60, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000514", "Tie Wire G.I. #16 (1kg Roll)", 62.0, 78.0, 50, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000515", "Corrugated G.I. Sheet Gauge 26 x 8ft", 320.0, 380.0, 40, 8, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000516", "Corrugated G.I. Sheet Gauge 26 x 10ft", 400.0, 475.0, 30, 6, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000517", "Plain G.I. Sheet Gauge 26 x 3ft x 8ft", 330.0, 395.0, 30, 5, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000518", "Pre-painted Long Span Roof Tile Red 0.4mm (1m)", 280.0, 340.0, 30, 5, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000519", "C-Purlins Steel 2x4 x 1.2mm x 6m", 380.0, 450.0, 40, 8, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000520", "Angle Bar Steel 1.5 x 1.5 x 3/16 x 6m", 310.0, 375.0, 35, 8, unit = "pcs", category = "Building Materials"),

                // 3. Plywood & Lumber (521 - 530)
                InventoryItem("480000000521", "Phenolic Plywood 3/4 x 4ft x 8ft", 1080.0, 1280.0, 20, 5, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000522", "Ordinary Plywood 1/4 x 4ft x 8ft", 320.0, 385.0, 40, 8, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000523", "Marine Plywood 1/2 x 4ft x 8ft", 680.0, 790.0, 30, 6, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000524", "Marine Plywood 3/4 x 4ft x 8ft", 980.0, 1150.0, 20, 4, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000525", "Fibre Cement Board Hardiflex 4.5mm x 4x8", 380.0, 445.0, 35, 8, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000526", "Lumber Coco 2x2 x 12ft", 85.0, 105.0, 80, 15, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000527", "Lumber Coco 2x3 x 12ft", 125.0, 150.0, 60, 12, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000528", "Lumber Good 2x2 x 10ft S4S", 140.0, 175.0, 50, 10, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000529", "Gypsum Board 9mm x 4ft x 8ft Standard", 280.0, 340.0, 30, 5, unit = "pcs", category = "Building Materials"),
                InventoryItem("480000000530", "Metal Stud Ceiling 19mm x 50mm x 3m", 58.0, 72.0, 60, 12, unit = "pcs", category = "Building Materials"),

                // 4. Plumbing & PVC (531 - 545)
                InventoryItem("480000000531", "Neltex PVC Pipe Blue Water 1/2 inch x 3m", 72.0, 88.0, 50, 10, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000532", "Neltex PVC Pipe Blue Water 3/4 inch x 3m", 98.0, 118.0, 40, 8, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000533", "Sanitary PVC Pipe Orange 2 inch x 3m", 160.0, 195.0, 35, 8, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000534", "Sanitary PVC Pipe Orange 3 inch x 3m", 235.0, 285.0, 30, 6, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000535", "Sanitary PVC Pipe Orange 4 inch x 3m", 320.0, 385.0, 25, 5, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000536", "PPR Pipe Cold Water 20mm (1/2 inch) x 4m", 110.0, 135.0, 40, 8, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000537", "PPR Pipe Hot & Cold 25mm (3/4 inch) x 4m", 165.0, 198.0, 30, 6, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000538", "PVC Elbow 1/2 inch Blue Water 90 Deg", 12.0, 16.0, 100, 20, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000539", "PVC Tee 1/2 inch Blue Water", 14.0, 18.0, 100, 20, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000540", "PVC Solvent Cement Glue 100cc Can", 42.0, 55.0, 40, 8, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000541", "Teflon Tape Sealing 1/2 inch x 10m", 10.0, 15.0, 120, 25, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000542", "Brass Gate Valve 1/2 inch Heavy Duty", 185.0, 225.0, 25, 5, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000543", "Flexible Hose Stainless 1/2 x 1/2 x 12 inch", 75.0, 95.0, 30, 6, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000544", "Single Faucet Stainless Steel 1/2 inch", 145.0, 180.0, 25, 5, unit = "pcs", category = "Plumbing"),
                InventoryItem("480000000545", "Shower Head With Hose Set Chrome", 280.0, 350.0, 15, 3, unit = "pcs", category = "Plumbing"),

                // 5. Electrical & Lighting (546 - 565)
                InventoryItem("480000000546", "Phelps Dodge THHN Wire #12 (2.0mm) 150m", 3250.0, 3850.0, 10, 2, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000547", "Phelps Dodge THHN Wire #10 (3.5mm) 150m", 4600.0, 5450.0, 8, 2, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000548", "Flexible Electrical Conduit Hose 1/2 (50m)", 280.0, 350.0, 15, 3, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000549", "PVC Electrical Pipe Orange 1/2 inch x 3m", 38.0, 48.0, 60, 12, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000550", "Royu Circuit Breaker 20A Plug-in Type", 148.0, 185.0, 30, 6, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000551", "Royu Circuit Breaker 30A Plug-in Type", 148.0, 185.0, 30, 6, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000552", "Royu Panel Board 4-Branches Main 60A", 680.0, 820.0, 10, 2, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000553", "Omni LED Bulb 9W Daylight E27", 68.0, 85.0, 60, 12, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000554", "Omni LED Bulb 12W Daylight E27", 92.0, 115.0, 50, 10, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000555", "Omni LED T8 Tube Light 16W 1.2m Daylight", 135.0, 168.0, 40, 8, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000556", "Omni Extension Cord 3-Gang 3 Meters", 220.0, 285.0, 25, 5, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000557", "Panasonic Flush Switch 1-Gang White", 85.0, 108.0, 40, 8, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000558", "Panasonic Flush Switch 2-Gang White", 135.0, 165.0, 30, 6, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000559", "Panasonic Duplex Outlet Grounding White", 145.0, 178.0, 35, 8, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000560", "Electrical Utility Box PVC 2x4 Orange", 12.0, 16.0, 100, 20, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000561", "Electrical Junction Box PVC 4x4 Orange", 18.0, 24.0, 80, 15, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000562", "Electrical Tape Black Insulation 18mm", 18.0, 25.0, 80, 15, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000563", "Receptacle Socket Ceiling E27 White 4 Inch", 25.0, 32.0, 60, 12, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000564", "Convenience Outlet Rubber Plug Heavy Duty", 35.0, 45.0, 50, 10, unit = "pcs", category = "Electrical"),
                InventoryItem("480000000565", "Solar Flood Light LED 100W Outdoor Waterproof", 850.0, 1050.0, 12, 3, unit = "pcs", category = "Electrical"),

                // 6. Paints & Chemicals (566 - 580)
                InventoryItem("480000000566", "Boysen Permacoat Latex Paint White 16L", 2350.0, 2850.0, 12, 3, unit = "pcs", category = "Paints"),
                InventoryItem("480000000567", "Boysen Quick Drying Enamel White 4L", 610.0, 750.0, 20, 4, unit = "pcs", category = "Paints"),
                InventoryItem("480000000568", "Boysen Flat Wall Enamel White 4L", 580.0, 720.0, 20, 4, unit = "pcs", category = "Paints"),
                InventoryItem("480000000569", "Boysen Roofgard Roof Paint Dark Green 4L", 720.0, 880.0, 15, 3, unit = "pcs", category = "Paints"),
                InventoryItem("480000000570", "Boysen Paint Thinner Solvent 1L Can", 95.0, 120.0, 30, 6, unit = "pcs", category = "Paints"),
                InventoryItem("480000000571", "Vulca Seal Elastomeric Sealant 75ml Tube", 65.0, 85.0, 50, 10, unit = "pcs", category = "Paints"),
                InventoryItem("480000000572", "Pioneer Epoxy All-Purpose 1/4L Set", 145.0, 185.0, 30, 6, unit = "pcs", category = "Paints"),
                InventoryItem("480000000573", "Silicone Sealant Clear Cartridge 300ml", 125.0, 155.0, 35, 8, unit = "pcs", category = "Paints"),
                InventoryItem("480000000574", "Paint Roller With Handle 7 Inch Cotton", 65.0, 85.0, 40, 8, unit = "pcs", category = "Paints"),
                InventoryItem("480000000575", "Paint Brush Bristle 2 Inch Standard", 22.0, 30.0, 50, 10, unit = "pcs", category = "Paints"),
                InventoryItem("480000000576", "Paint Brush Bristle 3 Inch Standard", 32.0, 42.0, 50, 10, unit = "pcs", category = "Paints"),
                InventoryItem("480000000577", "Sandpaper Sheet Waterproof Grit 100", 12.0, 16.0, 100, 20, unit = "pcs", category = "Paints"),
                InventoryItem("480000000578", "Sandpaper Sheet Waterproof Grit 120", 12.0, 16.0, 100, 20, unit = "pcs", category = "Paints"),
                InventoryItem("480000000579", "Body Filler Lacquer Putty 1L", 185.0, 225.0, 20, 4, unit = "pcs", category = "Paints"),
                InventoryItem("480000000580", "Spray Paint Pylox Acrylic Black 400ml", 110.0, 138.0, 30, 6, unit = "pcs", category = "Paints"),

                // 7. Hardware, Nails & Fasteners (581 - 600)
                InventoryItem("480000000581", "Common Wire Nails 1.5 Inch (1kg Bag)", 58.0, 75.0, 40, 8, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000582", "Common Wire Nails 2 Inch (1kg Bag)", 56.0, 72.0, 40, 8, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000583", "Common Wire Nails 3 Inch (1kg Bag)", 54.0, 70.0, 40, 8, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000584", "Common Wire Nails 4 Inch (1kg Bag)", 54.0, 70.0, 40, 8, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000585", "Concrete Nails 2 Inch (1kg Box)", 75.0, 95.0, 30, 6, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000586", "Concrete Nails 3 Inch (1kg Box)", 75.0, 95.0, 30, 6, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000587", "Blind Rivets Aluminum 5/32 x 1/2 (100s)", 48.0, 65.0, 40, 8, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000588", "Tek Screw Roof Self Drilling 2 Inch (100s)", 92.0, 120.0, 35, 8, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000589", "Wood Screw Flat Head 1 Inch (100s)", 38.0, 52.0, 40, 8, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000590", "Stanley Claw Hammer Fiberglass Handle 16oz", 290.0, 380.0, 15, 3, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000591", "Stanley Measuring Tape Steel 5m/16ft", 168.0, 220.0, 20, 4, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000592", "Stanley Combination Pliers 7 Inch Heavy Duty", 210.0, 280.0, 15, 3, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000593", "Makita Angle Grinder 4 Inch 720W GA4030", 1950.0, 2450.0, 8, 2, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000594", "Bosch Impact Drill 13mm 550W GSB550", 2250.0, 2850.0, 6, 2, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000595", "Yale Cylindrical Door Lockset Stainless Steel", 520.0, 680.0, 12, 3, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000596", "Kwikset Door Knob Passage Set Satin Chrome", 450.0, 580.0, 12, 3, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000597", "Hinges Loose Pin Stainless Steel 3.5 x 3.5 (Pair)", 85.0, 115.0, 30, 6, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000598", "Padlock Heavy Duty Brass 40mm Tri-Circle", 115.0, 148.0, 25, 5, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000599", "Hacksaw Frame Steel With Blade 12 Inch", 125.0, 165.0, 20, 4, unit = "pcs", category = "Hardware"),
                InventoryItem("480000000600", "Staple Wire Refill No 10 1000s Box", 15.0, 20.0, 40, 8, unit = "pcs", category = "Hardware")
            )

            items.forEach { item ->
                val values = ContentValues().apply {
                    put("barcode", item.barcode)
                    put("name", item.name)
                    put("purchase_cost", item.purchaseCost)
                    put("selling_price", item.sellingPrice)
                    put("stock_quantity", item.stockQuantity)
                    put("low_stock_limit", item.lowStockLimit)
                    put("recommended_stock", item.recommendedStock)
                    put("added_at", item.addedAt.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
                    put("unit", item.unit)
                    put("category", item.effectiveCategory)
                    put("image_path", "drawable:img_hardware")
                }
                db.insertWithOnConflict("inventory", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 2) db.execSQL("ALTER TABLE sales ADD COLUMN discount REAL NOT NULL DEFAULT 0")
            if (oldVersion < 3) db.execSQL("CREATE TABLE cash_withdrawals (id TEXT PRIMARY KEY, amount REAL NOT NULL, note TEXT NOT NULL, withdrawn_at TEXT NOT NULL)")
            if (oldVersion < 4) db.execSQL("CREATE TABLE cash_capitals (id TEXT PRIMARY KEY, amount REAL NOT NULL, note TEXT NOT NULL, added_at TEXT NOT NULL)")
            if (oldVersion < 5) {
                db.execSQL("ALTER TABLE sales ADD COLUMN payment_type TEXT NOT NULL DEFAULT 'CASH'")
                db.execSQL("ALTER TABLE sales ADD COLUMN customer_name TEXT NOT NULL DEFAULT 'Walkin'")
                db.execSQL("ALTER TABLE sales ADD COLUMN customer_contact TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE sales ADD COLUMN signature BLOB")
            }
            if (oldVersion < 15) {
                runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN category TEXT NOT NULL DEFAULT 'General'") }
            }
            if (oldVersion < 16) {
                runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN image_path TEXT") }
            }
            if (oldVersion < 6) {
                db.execSQL("ALTER TABLE sales ADD COLUMN cash_received REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN change_amount REAL NOT NULL DEFAULT 0")
            }
            if (oldVersion < 7) db.execSQL("CREATE TABLE debt_payments (id TEXT PRIMARY KEY, debtor_name TEXT NOT NULL, contact TEXT NOT NULL, amount REAL NOT NULL, paid_at TEXT NOT NULL)")
            if (oldVersion < 8) {
                db.execSQL("ALTER TABLE debt_payments ADD COLUMN cash_received REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE debt_payments ADD COLUMN change_amount REAL NOT NULL DEFAULT 0")
                db.execSQL("UPDATE debt_payments SET cash_received = amount")
            }
            if (oldVersion < 9) {
                db.execSQL("ALTER TABLE inventory ADD COLUMN recommended_stock INTEGER NOT NULL DEFAULT 10")
            }
            if (oldVersion < 10) {
                db.execSQL("CREATE TABLE IF NOT EXISTS store_settings (`key` TEXT PRIMARY KEY, value TEXT)")
                db.execSQL("CREATE TABLE IF NOT EXISTS activity_logs (id TEXT PRIMARY KEY, `action` TEXT NOT NULL, details TEXT NOT NULL, timestamp TEXT NOT NULL)")
            }
            if (oldVersion < 11) {
                runCatching { db.execSQL("ALTER TABLE inventory ADD COLUMN unit TEXT NOT NULL DEFAULT 'pcs'") }
                runCatching { db.execSQL("ALTER TABLE sales ADD COLUMN unit TEXT NOT NULL DEFAULT 'pcs'") }
                runCatching { db.execSQL("ALTER TABLE sales ADD COLUMN grams REAL NOT NULL DEFAULT 0") }
            }
            if (oldVersion < 12) {
                runCatching { db.execSQL("ALTER TABLE sales ADD COLUMN weight_kg REAL NOT NULL DEFAULT 0") }
            }
            if (oldVersion < 13) {
                runCatching {
                    db.execSQL("UPDATE inventory SET stock_quantity = stock_quantity * 1000, low_stock_limit = low_stock_limit * 1000, recommended_stock = recommended_stock * 1000 WHERE unit = 'kg' AND stock_quantity < 1000")
                }
            }
            if (oldVersion < 14) {
                runCatching { db.execSQL("CREATE TABLE ecash_adjustments (id TEXT PRIMARY KEY, type TEXT NOT NULL, wallet TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL, adjusted_at TEXT NOT NULL)") }
            }
        }
    }

    private fun databaseFile() = File(appContext.getDatabasePath(dbName).path)

    private companion object {
        const val DEFAULT_STORE_NAME = "ALKRIS POS"
    }
}

private fun getPhGroceryImageUrl(barcode: String, name: String): String {
    val lower = name.lowercase()
    return when {
        lower.contains("noodle") || lower.contains("canton") || lower.contains("ramen") || lower.contains("spaghetti") || lower.contains("pasta") || lower.contains("macaroni") || lower.contains("bihon") || lower.contains("sotanghon") -> "drawable:img_noodle"
        lower.contains("tuna") || lower.contains("sardines") || lower.contains("corned beef") || lower.contains("meat") || lower.contains("spam") || lower.contains("luncheon") || lower.contains("sausage") || lower.contains("beans") || lower.contains("pork") -> "drawable:img_canned"
        lower.contains("coffee") || lower.contains("nescafe") || lower.contains("kopiko") -> "drawable:img_coffee"
        lower.contains("milk") || lower.contains("bear brand") || lower.contains("birch tree") || lower.contains("nido") || lower.contains("milo") || lower.contains("alaska") || lower.contains("cream") -> "drawable:img_milk"
        lower.contains("coca-cola") || lower.contains("sprite") || lower.contains("royal") || lower.contains("pepsi") || lower.contains("c2") || lower.contains("cobra") || lower.contains("sting") || lower.contains("gatorade") || lower.contains("water") || lower.contains("drink") || lower.contains("juice") -> "drawable:img_drink"
        lower.contains("beer") || lower.contains("san miguel") || lower.contains("red horse") || lower.contains("gin") || lower.contains("brandy") || lower.contains("rhum") || lower.contains("wine") -> "drawable:img_liquor"
        lower.contains("sauce") || lower.contains("toyo") || lower.contains("suka") || lower.contains("seasoning") || lower.contains("ketchup") || lower.contains("oil") || lower.contains("knorr") || lower.contains("magic sarap") || lower.contains("ajinomoto") || lower.contains("vinegar") || lower.contains("soy") -> "drawable:img_sauce"
        lower.contains("piattos") || lower.contains("chips") || lower.contains("nova") || lower.contains("vcut") || lower.contains("skyflakes") || lower.contains("fita") || lower.contains("biscuits") || lower.contains("snack") || lower.contains("fudgee") || lower.contains("chocolate") || lower.contains("candy") -> "drawable:img_snack"
        lower.contains("soap") || lower.contains("shampoo") || lower.contains("colgate") || lower.contains("safeguard") || lower.contains("conditioner") || lower.contains("toothpaste") || lower.contains("lotion") || lower.contains("tissue") || lower.contains("alcohol") -> "drawable:img_soap"
        lower.contains("surf") || lower.contains("breeze") || lower.contains("downy") || lower.contains("tide") || lower.contains("ariel") || lower.contains("detergent") || lower.contains("cleaner") || lower.contains("bleach") -> "drawable:img_laundry"
        lower.contains("medicine") || lower.contains("biogesic") || lower.contains("neozep") || lower.contains("alaxan") || lower.contains("decolgen") || lower.contains("medicol") || lower.contains("kremil") || lower.contains("diatabs") || lower.contains("solmux") -> "drawable:img_medicine"
        else -> "drawable:alkris_pos_logo"
    }
}
