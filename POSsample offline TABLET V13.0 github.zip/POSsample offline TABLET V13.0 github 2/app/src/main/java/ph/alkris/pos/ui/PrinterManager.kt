package ph.alkris.pos.ui

import android.content.Context
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import com.dantsu.escposprinter.EscPosPrinter
import com.dantsu.escposprinter.connection.bluetooth.BluetoothConnection
import com.dantsu.escposprinter.textparser.PrinterTextParserImg
import com.dantsu.escposprinter.connection.bluetooth.BluetoothPrintersConnections
import ph.alkris.pos.data.InventoryItem
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.SalesSummary
import ph.alkris.pos.data.CashCapital
import ph.alkris.pos.data.CashWithdrawal
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.DebtPayment
import ph.alkris.pos.data.ActivityLog
import ph.alkris.pos.data.EcashAdjustment
import ph.alkris.pos.data.extractEcashDetails
import ph.alkris.pos.data.formattedReceiptCode
import ph.alkris.pos.data.generateDateList
import java.text.NumberFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object ThermalPrinterManager {
    private fun handlePrintError(context: Context, e: Throwable) {
        e.printStackTrace()
        val msg = when {
            e is SecurityException || e.message?.contains("BLUETOOTH_CONNECT", ignoreCase = true) == true ->
                "Bluetooth permission required in system settings."
            else -> "No thermal printer detected. Proceeding without printer."
        }
        Handler(Looper.getMainLooper()).post {
            runCatching {
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun normalizePrintText(text: String): String =
        text.lineSequence()
            .map(String::trimStart)
            .joinToString("\n")
            .trim()

    private fun getPrinterCharsPerLine(context: Context): Int {
        val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
        val is80mm = prefs.getBoolean("is_80mm_paper", false)
        return if (is80mm) 48 else 32
    }

    private fun createEscPosPrinter(context: Context, connection: BluetoothConnection): EscPosPrinter {
        val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
        val is80mm = prefs.getBoolean("is_80mm_paper", false)
        val widthMM = if (is80mm) 72f else 48f
        val charsPerLine = getPrinterCharsPerLine(context)
        return EscPosPrinter(connection, 203, widthMM, charsPerLine)
    }

    private fun generateCodename(storeName: String, type: String): String {
        val initials = storeName.split(" ").mapNotNull { it.firstOrNull() }.joinToString("").uppercase()
        val timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
        return "$initials-$type-$timestamp"
    }

    fun print(context: Context, sale: Sale, storeName: String) {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val rows = sale.lines.joinToString("\n") { line ->
                val qtyPrice = "x${line.quantity}  ${peso.format(line.subtotal)}"
                val maxNameLen = charsPerLine - qtyPrice.length - 1
                if (line.itemName.length <= maxNameLen) {
                    "[L]${line.itemName}[R]$qtyPrice"
                } else {
                    "[L]${line.itemName}\n[R]$qtyPrice"
                }
            }
            val codename = sale.formattedReceiptCode(storeName)
            val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
            val remainingOwed = (sale.total - downPayment).coerceAtLeast(0.0)
            
            val signatureImgText = if (sale.paymentType == "CREDIT" && sale.signature != null && sale.signature.isNotEmpty()) {
                runCatching {
                    val bmp = BitmapFactory.decodeByteArray(sale.signature, 0, sale.signature.size)
                    if (bmp != null) {
                        val targetWidth = 160
                        val targetHeight = (targetWidth * bmp.height.toDouble() / bmp.width.toDouble()).toInt().coerceAtLeast(1)
                        val scaledBmp = Bitmap.createScaledBitmap(bmp, targetWidth, targetHeight, true)
                        val hexStr = PrinterTextParserImg.bitmapToHexadecimalString(printer, scaledBmp)
                        "\n[C]<img>$hexStr</img>"
                    } else ""
                }.getOrDefault("")
            } else ""

            val paymentDetails = when {
                sale.paymentType == "CREDIT" -> {
                    val discountText = if (sale.discount > 0.0) "\n[L]Less Discount[R]-${peso.format(sale.discount)}" else ""
                    val downPaymentText = if (downPayment > 0.0) "\n[L]Partial Cash[R]${peso.format(downPayment)}\n[L]Remaining Owed[R]${peso.format(remainingOwed)}" else ""
                    "[L]UTANG (Credit Transaction)$discountText\n[L]Name: ${sale.customerName}\n[L]Contact: ${sale.customerContact}$downPaymentText\n[L]Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.$signatureImgText"
                }
                sale.paymentType.equals("GCASH", ignoreCase = true) || sale.paymentType.equals("EWALLET", ignoreCase = true) -> {
                    val discountText = if (sale.discount > 0.0) "\n[L]Less Discount[R]-${peso.format(sale.discount)}" else ""
                    val refText = if (sale.customerContact.isNotBlank()) "\n[L]GCash Ref #[R]${sale.customerContact}" else ""
                    "[L]Payment Method[R]GCash$refText$discountText\n[L]Amount Paid (GCash)[R]${peso.format(sale.total)}"
                }
                else -> {
                    val discountText = if (sale.discount > 0.0) "\n[L]Less Discount[R]-${peso.format(sale.discount)}" else ""
                    "[L]Payment Method[R]Cash\n[L]Cash Received[R]${peso.format(sale.cashReceived)}$discountText\n[L]Change[R]${peso.format(sale.change)}"
                }
            }

            val isEcash = sale.lines.any { it.barcode.startsWith("ECASH_") }
            val footerText = if (isEcash) "[L]Thank you!" else "[L]Thank you for shopping!"

            val ecashDetails = sale.extractEcashDetails()
            val printText = if (isEcash && ecashDetails != null) {
                val (serviceType, customerName, address, contactNo, refNo, serviceDetails, principal, serviceFee, isPrinting, isCashOut) = ecashDetails

                val customerInfoText = buildString {
                    if (customerName.isNotBlank() && !customerName.equals("Walkin", ignoreCase = true)) {
                        append("\n[L]Customer: $customerName")
                    }
                    if (address.isNotBlank()) {
                        append("\n[L]Address: $address")
                    }
                    if (contactNo.isNotBlank()) {
                        append("\n[L]Contact #: $contactNo")
                    }
                    if (refNo.isNotBlank() && refNo != sale.id) {
                        append("\n[L]Ref #: $refNo")
                    }
                    if (serviceDetails.isNotBlank()) {
                        append("\n[L]Details: $serviceDetails")
                    }
                }

                val headerTitle = when {
                    isCashOut -> "CASH-OUT RECEIPT"
                    isPrinting -> "PRINTING RECEIPT"
                    else -> "${serviceType.uppercase()} RECEIPT"
                }

                val mainSection = if (isCashOut) {
                    val customerCash = sale.cashReceived
                    val cashToGiveCustomer = sale.change
                    """
                    [L]Principal Amount[R]${peso.format(principal)}
                    [L]Service Fee[R]${peso.format(serviceFee)}
                    [L]Customer Cash (Fee)[R]${peso.format(customerCash)}
                    [L]$divider
                    [L]<b>CASH TO GIVE CUSTOMER</b>[R]<b>${peso.format(cashToGiveCustomer)}</b>
                    """.trimIndent()
                } else if (isPrinting) {
                    """
                    [L]Service Fee / Charge[R]${peso.format(sale.total)}
                    [L]$divider
                    [L]TOTAL AMOUNT[R]<b>${peso.format(sale.total)}</b>
                    [L]Cash Received[R]${peso.format(sale.cashReceived)}
                    [L]Change[R]${peso.format(sale.change)}
                    """.trimIndent()
                } else {
                    """
                    [L]Principal Amount[R]${peso.format(principal)}
                    [L]Service Fee[R]${peso.format(serviceFee)}
                    [L]$divider
                    [L]TOTAL AMOUNT[R]<b>${peso.format(sale.total)}</b>
                    [L]Cash Received[R]${peso.format(sale.cashReceived)}
                    [L]Change[R]${peso.format(sale.change)}
                    """.trimIndent()
                }

                val utangText = if (sale.paymentType == "CREDIT") {
                    val partialCash = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                    val remainingOwed = (sale.total - partialCash).coerceAtLeast(0.0)
                    val partialDetails = if (partialCash > 0.0) "\n[L]Partial Cash[R]${peso.format(partialCash)}\n[L]Remaining Owed[R]${peso.format(remainingOwed)}" else ""
                    val displayName = customerName.ifBlank { sale.customerName }
                    val displayContact = if (contactNo.isNotBlank()) contactNo else refNo
                    "\n[L]$divider\n[L]UTANG (Credit Transaction)\n[L]Name: $displayName${if (displayContact.isNotBlank()) "\n[L]Contact: $displayContact" else ""}$partialDetails\n[L]Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.$signatureImgText"
                } else ""

                val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
                val storeAddr = prefs.getString("store_location", "Poblacion, Philippines") ?: "Poblacion, Philippines"
                val storeContact = prefs.getString("store_contact", "0912-345-6789") ?: "0912-345-6789"
                val customFooter = prefs.getString("receipt_footer", "Thank you for shopping at AlKris!") ?: "Thank you for shopping at AlKris!"

                """
                [C]<b>$storeName</b>
                [C]$storeAddr
                [C]Contact: $storeContact
                [C]<b>$headerTitle</b>
                [L]${sale.purchasedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}
                [L]Receipt #: $codename$customerInfoText
                [L]$divider
                $mainSection$utangText
                
                [C]$customFooter
                [C]NOT VALID FOR BIR CLAIMING TAX
                [C]INTERNAL STORE MONITORING PURPOSES ONLY
                
                [L]$codename
                """.trimIndent()
            } else {
                val prefs = context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE)
                val storeAddr = prefs.getString("store_location", "Poblacion, Philippines") ?: "Poblacion, Philippines"
                val storeContact = prefs.getString("store_contact", "0912-345-6789") ?: "0912-345-6789"
                val customFooter = prefs.getString("receipt_footer", "Thank you for shopping at AlKris!") ?: "Thank you for shopping at AlKris!"

                """
                [C]<b>$storeName</b>
                [C]$storeAddr
                [C]Contact: $storeContact
                [L]${sale.purchasedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}
                
                $rows
                
                [L]TOTAL[R]<b>${peso.format(sale.total)}</b>
                $paymentDetails
                
                [C]$customFooter
                [C]NOT VALID FOR BIR CLAIMING TAX
                [C]INTERNAL STORE MONITORING PURPOSES ONLY
                
                [L]$codename
                """.trimIndent()
            }

            printer.printFormattedText(normalizePrintText(printText))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printDebtPayment(context: Context, payment: DebtPayment, storeName: String) {
        runCatching {
            val connection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val printer = createEscPosPrinter(context, connection)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val text = "[C]<b>$storeName</b>\n[L]UTANG PAYMENT RECEIPT\n[L]${payment.paidAt}\n\n" +
                "[L]Name: ${payment.debtorName}\n[L]Contact: ${payment.contact}\n" +
                "[L]Previous Balance[R]${peso.format(payment.previousBalance)}\n" +
                "[L]Cash Payment[R]${peso.format(payment.amount)}\n" +
                "[L]Cash Received[R]${peso.format(payment.cashReceived)}\n" +
                "[L]Change[R]${peso.format(payment.change)}\n" +
                "[L]Remaining Balance[R]${peso.format(payment.remainingBalance)}\n\n" +
                "[L]Thank you!\n[L]${payment.formattedReceiptCode(storeName)}"
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printReport(context: Context, start: LocalDate, end: LocalDate, summary: SalesSummary, storeName: String) {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dateRange = if (start == end) start.toString() else "$start to $end"
            val codename = generateCodename(storeName, "R")
            
            val text = """
                [C]<b>$storeName</b>
                [L]SALES REPORT
                [L]$dateRange
                
                [L]Total Sales[R]<b>${peso.format(summary.totalSales)}</b>
                [L]Total Profit[R]${peso.format(summary.totalProfit)}
                [L]Items Sold[R]${summary.itemsSold}
                
                [L]$divider
                [L]Generated on ${LocalDate.now()}
                
                [L]$codename
            """.trimIndent()
            
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printReceivablesReport(
        context: Context,
        start: LocalDate,
        end: LocalDate,
        debtors: List<Debtor>,
        storeName: String
    ) {
        runCatching {
            val connection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dateRange = "As of ${LocalDate.now()}"
            val rows = debtors.joinToString("\n") {
                "[L]<b>${it.name}</b>\n[L]${it.contact} | ${it.lastTransactionAt.toLocalDate()}[R]${peso.format(it.totalOwed)}\n[L]Signature: signed agreement"
            }
            val text = """
                [C]<b>$storeName</b>
                [L]RECEIVABLES REPORT
                [L]$dateRange

                ${rows.ifBlank { "[L]No outstanding receivables" }}

                [L]$divider
                [L]TOTAL RECEIVABLES[R]<b>${peso.format(debtors.sumOf { it.totalOwed })}</b>
                [L]${generateCodename(storeName, "AR")}
            """.trimIndent()
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printInventory(context: Context, inventory: List<InventoryItem>, storeName: String, title: String = "INVENTORY REPORT") {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val codename = generateCodename(storeName, "I")
            
            val rows = inventory.joinToString("\n") { item ->
                if (title == "NEEDED RESTOCK REPORT") {
                    val neededGrams = (item.recommendedStock - item.stockQuantity).coerceAtLeast(0)
                    val neededDisplay = if (item.isKg) {
                        val kgVal = neededGrams / 1000.0
                        if (kgVal % 1.0 == 0.0) "${kgVal.toInt()} kg" else "$kgVal kg"
                    } else if (item.isGrams) {
                        "${neededGrams} grm"
                    } else {
                        "$neededGrams"
                    }
                    val curDisplay = "${item.displayStock}${if (item.isKg) " kg" else if (item.isGrams) " grm" else ""}"
                    val recDisplay = "${item.displayRecommended}${if (item.isKg) " kg" else if (item.isGrams) " grm" else ""}"
                    "[L]${item.name}\n[L]Cur: $curDisplay | Rec: $recDisplay[R]Buy: <b>$neededDisplay</b>"
                } else {
                    val stockStatus = if (item.isOutOfStock) " (OUT)" else if (item.isLowStock) " (LOW)" else ""
                    val qtyDisplay = "${item.displayStock}${if (item.isKg) " kg" else if (item.isGrams) " grm" else ""}"
                    "[L]${item.name}$stockStatus\n[L]Qty: $qtyDisplay[R]${peso.format(item.sellingPrice)}" 
                }
            }

            val text = """
                [C]<b>$storeName</b>
                [L]$title
                [L]${LocalDate.now()}
                
                $rows
                
                [L]$divider
                [L]Total Items: ${inventory.size}
                
                [L]$codename
            """.trimIndent()
            
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printSkippedBarcodes(context: Context, barcodes: List<String>, storeName: String) {
        runCatching {
            val connection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val printer = createEscPosPrinter(context, connection)
            val rows = barcodes.joinToString("\n") { "[L]$it" }
            val text = "[C]<b>$storeName</b>\n[L]SKIPPED INVENTORY BARCODES\n[L]${LocalDate.now()}\n\n" +
                rows +
                "\n\n[L]Total Skipped: ${barcodes.size}"
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printItemizedReport(
        context: Context,
        start: LocalDate,
        end: LocalDate,
        sales: List<Sale>,
        storeName: String,
        title: String = "ITEMIZED SALES"
    ) {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dateRange = if (start == end) start.toString() else "$start to $end"
            val codename = generateCodename(storeName, "IR")
            
            data class ItemizedLine(
                val name: String,
                val quantity: Int,
                val totalCost: Double,
                val subtotal: Double
            )

            val itemMap = mutableMapOf<String, ItemizedLine>()
            sales.flatMap { it.lines }.forEach { line ->
                val current = itemMap[line.barcode]
                itemMap[line.barcode] = if (current == null) {
                    ItemizedLine(
                        line.itemName,
                        line.quantity,
                        line.unitCost * line.quantity,
                        line.subtotal
                    )
                } else {
                    current.copy(
                        quantity = current.quantity + line.quantity,
                        totalCost = current.totalCost + line.unitCost * line.quantity,
                        subtotal = current.subtotal + line.subtotal
                    )
                }

            }
            
            val rows = itemMap.values.sortedByDescending { it.quantity }.joinToString("\n") {
                val averageUnitCost = it.totalCost / it.quantity
                "[L]${it.name}\n[L]Qty: ${it.quantity} Cost: ${peso.format(averageUnitCost)}[R]${peso.format(it.subtotal)}"
            }
            val totalSales = itemMap.values.sumOf { it.subtotal }
            val totalItems = itemMap.values.sumOf { it.quantity }
            
            val text = """
                [C]<b>$storeName</b>
                [L]$title
                [L]$dateRange
                
                $rows
                
                [L]$divider
                [L]Total Sales: [R]<b>${peso.format(totalSales)}</b>
                [L]Total Items Sold: $totalItems
                
                [L]$codename
            """.trimIndent()
            
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printCashHistory(
        context: Context,
        start: LocalDate,
        end: LocalDate,
        withdrawals: List<CashWithdrawal>,
        capitals: List<CashCapital>,
        sales: List<Sale>,
        debtPayments: List<DebtPayment>,
        startingCash: Double,
        endingCash: Double,
        storeName: String
    ) {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val printer = createEscPosPrinter(context, connection)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dailySales = generateDateList(start, end).joinToString("\n") { date ->
                "[L]$date[R]${peso.format(sales.filter { it.cashAmount > 0.0 && it.purchasedAt.toLocalDate() == date }.sumOf { it.cashAmount })}"
            }
            val pullouts = withdrawals.joinToString("\n") {
                "[L]${it.withdrawnAt.toLocalDate()} Pullout[R]-${peso.format(it.amount)}"
            }
            val additions = capitals.joinToString("\n") {
                "[L]${it.addedAt.toLocalDate()} Capital[R]+${peso.format(it.amount)}"
            }
            val debtPaymentsText = debtPayments.joinToString("\n") {
                "[L]${it.paidAt.toLocalDate()} Utang Payment - ${it.debtorName}[R]+${peso.format(it.amount)}"
            }
            val codename = generateCodename(storeName, "CH")
            val text = """
                [C]<b>$storeName</b>
                [L]CASH HISTORY
                [L]$start to $end
                [L]Starting Cash[R]${peso.format(startingCash)}

                [L]<b>DAILY SALES</b>
                ${dailySales.ifBlank { "[L]No dates" }}

                [L]<b>CASH PULLOUTS</b>
                ${pullouts.ifBlank { "[L]None" }}

                [L]<b>CASH CAPITAL</b>
                ${additions.ifBlank { "[L]None" }}

                [L]<b>UTANG PAYMENTS</b>
                ${debtPaymentsText.ifBlank { "[L]None" }}

                [L]Ending Cash[R]${peso.format(endingCash)}

                [L]$codename
                """.trimIndent()
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printActivityLogs(
        context: Context,
        logs: List<ActivityLog>,
        storeName: String,
        start: LocalDate,
        end: LocalDate
    ) {
        runCatching {
            val connection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val printer = createEscPosPrinter(context, connection)
            val dtf = DateTimeFormatter.ofPattern("MM-dd HH:mm")
            val rows = logs.joinToString("\n") { log ->
                "[L]${log.timestamp.format(dtf)} ${log.action}\n[L]${log.details}"
            }

            val text = "[C]<b>$storeName</b>\n[C]ACTIVITY LOGS\n[C]$start to $end\n\n$rows\n\n[C]End of Logs Report\n\n"
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printDebtorUnpaidItems(
        context: Context,
        debtor: Debtor,
        sales: List<Sale>,
        payments: List<DebtPayment>,
        storeName: String
    ) {
        runCatching {
            val connection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

            // Filter out transactions that have already been fully settled/paid off (FIFO)
            val totalDebtPayments = payments.sumOf { it.amount }
            var remainingPaidAmount = totalDebtPayments

            val activeUnpaidSales = mutableListOf<Sale>()
            val sortedSales = sales.sortedBy { it.purchasedAt }

            for (sale in sortedSales) {
                val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                val netSaleDebt = (sale.total - downPayment).coerceAtLeast(0.0)

                if (remainingPaidAmount >= netSaleDebt) {
                    remainingPaidAmount -= netSaleDebt
                } else {
                    activeUnpaidSales.add(sale)
                    remainingPaidAmount = 0.0
                }
            }

            val salesText = if (activeUnpaidSales.isEmpty()) {
                "[L]No outstanding unpaid transactions."
            } else {
                activeUnpaidSales.joinToString("\n[L]$divider\n") { sale ->
                    val linesText = sale.lines.joinToString("\n") { line ->
                        val qtyPrice = "x${line.quantity}  ${peso.format(line.subtotal)}"
                        val maxNameLen = charsPerLine - qtyPrice.length - 1
                        if (line.itemName.length <= maxNameLen) {
                            "[L]${line.itemName}[R]$qtyPrice"
                        } else {
                            "[L]${line.itemName}\n[R]$qtyPrice"
                        }
                    }
                    val downPayment = (sale.cashReceived - sale.change).coerceAtLeast(0.0)
                    val partialText = if (downPayment > 0.0) {
                        "\n[L]Down Payment[R]-${peso.format(downPayment)}"
                    } else ""

                    "[L]<b>Receipt #: ${sale.formattedReceiptCode(storeName)}</b>\n[L]Date: ${sale.purchasedAt.format(dtf)}\n$linesText\n[L]Sale Total[R]<b>${peso.format(sale.total)}</b>$partialText"
                }
            }

            val firstActiveSaleDate = activeUnpaidSales.firstOrNull()?.purchasedAt
            val currentDebtPayments = if (firstActiveSaleDate != null) {
                payments.filter { it.paidAt >= firstActiveSaleDate }.sortedBy { it.paidAt }
            } else emptyList()

            val paymentsText = if (currentDebtPayments.isEmpty()) {
                ""
            } else {
                val paymentLines = currentDebtPayments.joinToString("\n") { payment ->
                    "[L]${payment.paidAt.format(dtf)}[R]-${peso.format(payment.amount)}"
                }
                val totalPayments = currentDebtPayments.sumOf { it.amount }
                "\n[L]$divider\n[L]<b>PARTIAL UTANG PAYMENTS:</b>\n$paymentLines\n[L]Total Partial Payments[R]<b>-${peso.format(totalPayments)}</b>"
            }

            val actualBalance = debtor.totalOwed
            val codename = generateCodename(storeName, "UP")

            val text = """
                [C]<b>$storeName</b>
                [C]<b>UNPAID UTANG STATEMENT</b>
                [L]Customer: ${debtor.name}
                [L]Date: ${LocalDate.now()}
                [L]$divider
                $salesText$paymentsText
                [L]$divider
                [L]<b>OUTSTANDING UTANG BALANCE</b>[R]<b>${peso.format(actualBalance)}</b>
                
                [L]$codename
            """.trimIndent()

            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printDiscountsReport(
        context: Context,
        start: LocalDate,
        end: LocalDate,
        sales: List<Sale>,
        storeName: String
    ) {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
            val discountedSales = sales.filter { it.discount > 0.0 }.sortedBy { it.purchasedAt }
            val totalDiscounts = discountedSales.sumOf { it.discount }
            val codename = generateCodename(storeName, "D")

            val rows = if (discountedSales.isEmpty()) {
                "[L]No transactions with discounts given."
            } else {
                discountedSales.joinToString("\n[L]$divider\n") { sale ->
                    val originalTotal = sale.total + sale.discount
                    val refCode = sale.formattedReceiptCode(storeName)
                    "[L]<b>Receipt #: $refCode</b>\n[L]Date: ${sale.purchasedAt.format(dtf)}\n[L]Original Total[R]${peso.format(originalTotal)}\n[L]Less Discount[R]-${peso.format(sale.discount)}\n[L]Net Total[R]<b>${peso.format(sale.total)}</b>"
                }
            }

            val text = """
                [C]<b>$storeName</b>
                [C]<b>DISCOUNTS REPORT</b>
                [L]Period: ${if (start == end) start.toString() else "$start to $end"}
                [L]$divider
                $rows
                [L]$divider
                [L]Discounted Sales: ${discountedSales.size}
                [L]TOTAL DISCOUNTS[R]<b>${peso.format(totalDiscounts)}</b>
                
                [L]$codename
            """.trimIndent()

            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printEcashReport(
        context: Context,
        start: LocalDate,
        end: LocalDate,
        serviceStats: Map<String, Triple<Double, Double, Int>>,
        storeName: String
    ) {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dateRange = if (start == end) start.toString() else "$start to $end"
            
            var serviceLines = ""
            var totalVol = 0.0
            var totalProf = 0.0
            serviceStats.entries.forEach { (service, stats) ->
                val (vol, prof, count) = stats
                if (service == "Printing") {
                    totalProf += prof
                    serviceLines += "[L]$service\n[L]  Txns: $count | Fee: ${peso.format(prof)}\n"
                } else {
                    totalVol += vol
                    totalProf += prof
                    serviceLines += "[L]$service\n[L]  Vol: ${peso.format(vol)} | Fee: ${peso.format(prof)}\n"
                }
            }
            
            val text = """
                [C]<b>$storeName</b>
                [L]ECASH SERVICES REPORT
                [L]$dateRange
                [L]$divider
                $serviceLines
                [L]$divider
                [L]Total Money Volume[R]<b>${peso.format(totalVol)}</b>
                [L]Total Profit[R]<b>${peso.format(totalProf)}</b>
                [L]$divider
                [L]Generated on ${LocalDate.now()}
            """.trimIndent()
            
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }

    fun printWalletsHistoryReport(
        context: Context,
        start: LocalDate,
        end: LocalDate,
        adjustments: List<EcashAdjustment>,
        storeName: String
    ) {
        runCatching {
            val connection: BluetoothConnection = BluetoothPrintersConnections.selectFirstPaired()
                ?: error("No paired thermal printer")
            val charsPerLine = getPrinterCharsPerLine(context)
            val printer = createEscPosPrinter(context, connection)
            val divider = "-".repeat(charsPerLine)
            val peso = NumberFormat.getCurrencyInstance(Locale("en", "PH"))
            val dateRange = if (start == end) start.toString() else "$start to $end"
            
            val rows = adjustments.joinToString("\n[L]$divider\n") { adj ->
                "[L]<b>${adj.wallet} - ${adj.type}</b>[R]${peso.format(adj.amount)}\n[L]Note: ${adj.note}\n[L]Date: ${adj.adjustedAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}"
            }
            
            val text = """
                [C]<b>$storeName</b>
                [L]WALLETS HISTORY
                [L]$dateRange
                [L]$divider
                ${rows.ifBlank { "[L]No adjustments recorded." }}
                [L]$divider
                [L]Generated on ${LocalDate.now()}
            """.trimIndent()
            
            printer.printFormattedText(normalizePrintText(text))
        }.onFailure { handlePrintError(context, it) }
    }
}
