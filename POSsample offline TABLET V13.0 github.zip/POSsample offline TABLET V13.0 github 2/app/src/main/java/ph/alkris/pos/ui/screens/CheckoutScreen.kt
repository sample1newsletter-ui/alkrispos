package ph.alkris.pos.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Paint
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ph.alkris.pos.data.CartLine
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.InventoryItem
import ph.alkris.pos.ui.CashSoundManager
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.ReceiptImageExporter
import ph.alkris.pos.ui.components.Blue
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Green
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.ui.components.Pink
import ph.alkris.pos.ui.components.ScrollbarLazyColumn
import ph.alkris.pos.ui.dialogs.DebtorsDialog
import ph.alkris.pos.ui.printReceipt
import ph.alkris.pos.data.roundPosPrice
import java.io.ByteArrayOutputStream
import kotlin.math.round

@Composable
fun CheckoutScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier,
    onScanRequested: ((String) -> Unit) -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showPayment by rememberSaveable { mutableStateOf(false) }
    var changeToReturn by rememberSaveable { mutableStateOf<Double?>(null) }
    var itemForWeightInputBarcode by rememberSaveable { mutableStateOf<String?>(null) }
    val itemForWeightInput = state.inventory.firstOrNull { it.barcode == itemForWeightInputBarcode }
    LaunchedEffect(Unit) { viewModel.loadDebtors() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            state.lastSale?.let { printReceipt(context, it, state.storeName, viewModel) }
        } else {
            Toast.makeText(context, "Bluetooth permissions denied", Toast.LENGTH_SHORT).show()
        }
    }

    fun printLastSale() {
        state.lastSale?.let { sale ->
            val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            } else {
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            val missing = permissions.filter {
                ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
            else printReceipt(context, sale, state.storeName, viewModel)
        }
    }

    fun handleAddToCart(item: InventoryItem, grams: Double = 0.0, weightKg: Double = 0.0) {
        if (item.isWeighed && grams <= 0.0 && weightKg <= 0.0) {
            itemForWeightInputBarcode = item.barcode
        } else {
            CashSoundManager.playBeepSound()
            viewModel.addToCart(item, grams, weightKg)
        }
    }

    fun handleScan(scannedCode: String) {
        val trimmed = scannedCode.trim()
        val match = state.inventory.firstOrNull {
            it.barcode.trim().equals(trimmed, ignoreCase = true) ||
            it.barcode.trim().trimStart('0').equals(trimmed.trimStart('0'), ignoreCase = true)
        }
        if (match != null) {
            handleAddToCart(match)
            viewModel.setQuery("")
        } else {
            viewModel.setQuery(trimmed)
            Toast.makeText(context, "Item not found for barcode: $trimmed", Toast.LENGTH_SHORT).show()
        }
    }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    if (isLandscape) {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Column: Search & Products
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                OutlinedTextField(
                    value = state.query,
                    onValueChange = viewModel::setQuery,
                    label = { Text("Search item or barcode") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = ControlShape,
                    trailingIcon = {
                        IconButton(onClick = { onScanRequested { handleScan(it) } }) {
                            Icon(Icons.Default.QrCodeScanner, "Scan barcode", tint = Blue)
                        }
                    }
                )
                Spacer(Modifier.height(8.dp))
                Text("Products", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                val filteredItems = state.filteredInventory
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, Color.LightGray, ControlShape)
                        .padding(horizontal = 8.dp)
                ) {
                    ScrollbarLazyColumn {
                        items(filteredItems, key = { it.barcode }) { item ->
                            ProductRow(item) { handleAddToCart(item) }
                        }
                    }
                }
            }

            // Right Column: Cart, Total, and Pay button
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Text("Cart", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, Color.LightGray, ControlShape)
                        .padding(horizontal = 8.dp)
                ) {
                    ScrollbarLazyColumn {
                        items(state.cart, key = { it.item.barcode }) { line ->
                            CartRow(
                                line,
                                { viewModel.changeQuantity(line.item, -1) },
                                { CashSoundManager.playBeepSound(); viewModel.changeQuantity(line.item, 1) }
                            )
                        }
                    }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TOTAL", fontWeight = FontWeight.Bold)
                    Text(Peso.format(state.total), color = Green, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { showPayment = true },
                    enabled = state.cart.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = ControlShape
                ) {
                    Text("Pay Now")
                }
            }
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::setQuery,
                label = { Text("Search item or barcode") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = ControlShape,
                trailingIcon = {
                    IconButton(onClick = { onScanRequested { handleScan(it) } }) {
                        Icon(Icons.Default.QrCodeScanner, "Scan barcode", tint = Blue)
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            Text("Products", fontWeight = FontWeight.Bold)
            
            val filteredItems = state.filteredInventory
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Color.LightGray, ControlShape)
                    .padding(horizontal = 8.dp)
            ) {
                ScrollbarLazyColumn {
                    items(filteredItems, key = { it.barcode }) { item ->
                        ProductRow(item) { handleAddToCart(item) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Cart", fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.2f)
                    .border(1.dp, Color.LightGray, ControlShape)
                    .padding(horizontal = 8.dp)
            ) {
                ScrollbarLazyColumn {
                    items(state.cart, key = { it.item.barcode }) { line ->
                        CartRow(
                            line,
                            { viewModel.changeQuantity(line.item, -1) },
                            { CashSoundManager.playBeepSound(); viewModel.changeQuantity(line.item, 1) }
                        )
                    }
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TOTAL", fontWeight = FontWeight.Bold)
                Text(Peso.format(state.total), color = Green, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { showPayment = true },
                enabled = state.cart.isNotEmpty(),
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Text("Pay Now")
            }
        }
    }
        var transactionDeclinedMessage by remember { mutableStateOf<String?>(null) }

        if (showPayment) {
            PaymentDialog(
                total = state.total,
                debtors = state.debtors,
                onDismiss = { showPayment = false },
                onConfirm = { discount, change, paymentType, name, contact, signature, pin, cashReceived ->
                    viewModel.completeSale(
                        discount = discount,
                        paymentType = paymentType,
                        customerName = name,
                        customerContact = contact,
                        signature = signature,
                        pin = pin,
                        cashReceived = cashReceived,
                        change = change,
                        onSuccess = {
                            showPayment = false
                            changeToReturn = change
                            CashSoundManager.playChimeSound(context)
                        },
                        onError = { errMsg ->
                            transactionDeclinedMessage = errMsg
                        }
                    )
                }
            )
        }
        transactionDeclinedMessage?.let { msg ->
            AlertDialog(
                onDismissRequest = { transactionDeclinedMessage = null },
                icon = { Icon(Icons.Default.Warning, "Declined", tint = Pink) },
                title = { Text("Transaction Declined", fontWeight = FontWeight.Bold, color = Pink) },
                text = { Text(msg) },
                confirmButton = {
                    TextButton(onClick = { transactionDeclinedMessage = null }) {
                        Text("OK", color = Pink, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
        changeToReturn?.let { change ->
            ChangeDialog(
                change = change,
                canPrint = state.lastSale != null,
                onPrint = ::printLastSale,
                onSaveImage = {
                    state.lastSale?.let { sale ->
                        ReceiptImageExporter.saveReceiptToGallery(context, sale, state.storeName)
                    }
                },
                onDismiss = { changeToReturn = null }
            )
        }
        itemForWeightInput?.let { item ->
            WeightInputDialog(
                item = item,
                onConfirm = { grams, weightKg -> handleAddToCart(item, grams, weightKg) },
                onDismiss = { itemForWeightInputBarcode = null }
            )
        }
    }

@Composable
fun PaymentDialog(
    total: Double,
    debtors: List<Debtor>,
    onDismiss: () -> Unit,
    onConfirm: (Double, Double, String, String, String, ByteArray?, String?, Double) -> Unit
) {
        var discountText by rememberSaveable { mutableStateOf("0") }
        var buyerCashText by rememberSaveable { mutableStateOf("") }
        var partialCashText by rememberSaveable { mutableStateOf("") }
        var creditMode by rememberSaveable { mutableStateOf(false) }
        var name by rememberSaveable { mutableStateOf("") }
        var contact by rememberSaveable { mutableStateOf("") }
        var pin by rememberSaveable { mutableStateOf("") }
        var showDebtors by rememberSaveable { mutableStateOf(false) }
        val signaturePoints = remember { mutableStateOf<List<List<Offset>>>(emptyList()) }
        val discount = discountText.toDoubleOrNull()?.coerceIn(0.0, total) ?: 0.0
        val amountDue = (total - discount).coerceAtLeast(0.0)
        val buyerCash = buyerCashText.toDoubleOrNull()
        val buyerCashCents = buyerCash?.let { round(it * 100.0).toLong() }
        val amountDueCents = round(amountDue * 100.0).toLong()
        val partialCash = partialCashText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
        val creditChange = (partialCash - amountDue).coerceAtLeast(0.0)
        val effectiveReceivable = (amountDue - partialCash).coerceAtLeast(0.0)
        val canConfirm = if (creditMode) name.isNotBlank() && contact.isNotBlank() && signaturePoints.value.isNotEmpty()
            else buyerCashCents != null && buyerCashCents >= amountDueCents
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Payment") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { creditMode = false }, enabled = creditMode) { Text("Cash") }
                        Button(onClick = { creditMode = true }, enabled = !creditMode) { Text("Utang") }
                        if (creditMode) TextButton(onClick = { showDebtors = true }) { Text("Debtors") }
                    }
                    if (!creditMode) OutlinedTextField(
                        value = buyerCashText, onValueChange = {
                            if (it.matches(Regex("""\d*([.]\d{0,2})?"""))) buyerCashText = it
                        }, label = { Text("Walkin - Buyer's cash") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true, shape = ControlShape
                    ) else {
                        OutlinedTextField(name, { name = it }, label = { Text("Customer name") }, singleLine = true, shape = ControlShape)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(contact, { contact = it }, label = { Text("Contact number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, shape = ControlShape)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = partialCashText,
                            onValueChange = {
                                if (it.matches(Regex("""\d*([.]\d{0,2})?"""))) partialCashText = it
                            },
                            label = { Text("Partial Cash (Optional)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true, shape = ControlShape
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(pin, { pin = it }, label = { Text("App PIN (only if over ₱200)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = PasswordVisualTransformation(), singleLine = true, shape = ControlShape)
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { if (it.matches(Regex("""\d*([.]\d{0,2})?"""))) discountText = it },
                        label = { Text("Less discount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = ControlShape
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Amount due: ${Peso.format(amountDue)}", fontWeight = FontWeight.Bold, color = Green)
                    Spacer(Modifier.height(4.dp))
                    if (!creditMode && buyerCash != null && buyerCash < amountDue) {
                        Text("Insufficient cash", color = Pink)
                    } else if (!creditMode) {
                        Text("Change: ${Peso.format((buyerCash ?: 0.0) - amountDue)}", color = Green)
                    } else {
                        if (partialCash > 0.0) {
                            Text("Partial Cash: ${Peso.format(partialCash.coerceAtMost(amountDue))}", color = Green, fontWeight = FontWeight.Bold)
                            if (creditChange > 0.0) {
                                Text("Change: ${Peso.format(creditChange)}", color = Green)
                            }
                        }
                        Text("Remaining Utang: ${Peso.format(effectiveReceivable)}", color = Pink, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    TextButton(
                        onClick = {
                            val effectiveCash = if (creditMode) partialCash else buyerCash!!
                            val effectiveChange = if (creditMode) creditChange else buyerCash!! - amountDue
                            onConfirm(
                                discount, effectiveChange,
                                if (creditMode) "CREDIT" else "CASH",
                                if (creditMode) name else "Walkin", if (creditMode) contact else "",
                                if (creditMode) signatureToBytes(signaturePoints.value) else null,
                                pin.takeIf { creditMode },
                                effectiveCash
                            )
                        },
                        enabled = canConfirm
                    ) { Text("Confirm Payment") }
                }
            }
        )
        if (showDebtors) {
            DebtorsDialog(debtors, onDismiss = { showDebtors = false }, onSelect = { debtor ->
                name = debtor.name
                contact = debtor.contact
                showDebtors = false
            })
        }
    }

@Composable
fun SignaturePad(points: MutableState<List<List<Offset>>>) {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(100.dp)
            .border(1.dp, Color.Gray, ControlShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    var currentStroke = listOf(down.position)
                    points.value = points.value + listOf(currentStroke)
                    down.consume()

                    drag(down.id) { change ->
                        change.consume()
                        currentStroke = currentStroke + change.position
                        points.value = points.value.dropLast(1) + listOf(currentStroke)
                    }
                }
            }
    ) {
        points.value.forEach { stroke ->
            if (stroke.size == 1) {
                drawCircle(
                    color = Color.Black,
                    radius = 3f,
                    center = stroke[0]
                )
            } else if (stroke.size > 1) {
                val path = Path()
                stroke.forEachIndexed { index, point ->
                    if (index == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
                }
                drawPath(
                    path = path,
                    color = Color.Black,
                    style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

fun signatureToBytes(strokes: List<List<Offset>>): ByteArray {
    val allPoints = strokes.flatten()
    if (allPoints.isEmpty()) return ByteArray(0)

    val bitmap = Bitmap.createBitmap(600, 200, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)

    val paint = Paint().apply {
        color = android.graphics.Color.BLACK
        strokeWidth = 6f
        style = Paint.Style.STROKE
        isAntiAlias = true
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    val dotPaint = Paint().apply {
        color = android.graphics.Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    val minX = allPoints.minOf { it.x }
    val maxX = allPoints.maxOf { it.x }
    val minY = allPoints.minOf { it.y }
    val maxY = allPoints.maxOf { it.y }
    val padWidth = (maxX - minX).coerceAtLeast(1f)
    val padHeight = (maxY - minY).coerceAtLeast(1f)

    val scaleX = 560f / padWidth
    val scaleY = 160f / padHeight
    val scale = minOf(scaleX, scaleY)

    val offsetX = 20f + (560f - padWidth * scale) / 2f
    val offsetY = 20f + (160f - padHeight * scale) / 2f

    strokes.forEach { stroke ->
        if (stroke.size == 1) {
            val point = stroke[0]
            val mappedX = offsetX + (point.x - minX) * scale
            val mappedY = offsetY + (point.y - minY) * scale
            canvas.drawCircle(mappedX, mappedY, 4f, dotPaint)
        } else if (stroke.size > 1) {
            val path = android.graphics.Path()
            stroke.forEachIndexed { index, point ->
                val mappedX = offsetX + (point.x - minX) * scale
                val mappedY = offsetY + (point.y - minY) * scale
                if (index == 0) path.moveTo(mappedX, mappedY) else path.lineTo(mappedX, mappedY)
            }
            canvas.drawPath(path, paint)
        }
    }

    return ByteArrayOutputStream().use { output ->
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        output.toByteArray()
    }
}

@Composable
fun ChangeDialog(
    change: Double,
    canPrint: Boolean,
    onPrint: () -> Unit,
    onSaveImage: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Payment Complete") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("Change", fontWeight = FontWeight.Bold)
                Text(
                    Peso.format(change),
                    color = Pink,
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(enabled = canPrint, onClick = onSaveImage)
                            .padding(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Image,
                            contentDescription = "E-receipt",
                            tint = if (canPrint) Blue else Color.Gray,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("E-receipt", color = if (canPrint) Blue else Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(enabled = canPrint, onClick = onPrint)
                            .padding(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Print,
                            contentDescription = "Print",
                            tint = if (canPrint) Blue else Color.Gray,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("Print", color = if (canPrint) Blue else Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Done") }
        }
    )
}

@Composable
fun ProductRow(item: InventoryItem, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy((-1).dp)) {
            Text(item.name, fontWeight = FontWeight.SemiBold, lineHeight = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.barcode, color = Color.Gray, fontSize = 11.sp, lineHeight = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                when {
                    item.isKg -> "${Peso.format(item.sellingPrice)}/kg  |  ${item.displayStock} kg stock"
                    item.isGrams -> "${Peso.format(item.sellingPrice)}/1000g  |  ${item.displayStock} grm stock"
                    else -> "${Peso.format(item.sellingPrice)}  |  ${item.displayStock} in stock"
                },
                color = Color.Gray, lineHeight = 16.sp
            )
        }
        if (item.isOutOfStock) AssistChip({ }, label = { Text("OUT OF STOCK") }, enabled = false) else { if (item.isLowStock) Text("LOW STOCK", color = Pink, modifier = Modifier.padding(end = 8.dp)); IconButton(onAdd) { Icon(Icons.Default.Add, "Add", tint = Blue) } }
    }
}

@Composable
fun CartRow(line: CartLine, onRemove: () -> Unit, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            when {
                line.item.isKg -> "${line.item.name} (${line.weightKg} kg)"
                line.item.isGrams -> "${line.item.name} (${line.grams.toInt()} grm)"
                else -> line.item.name
            },
            Modifier.weight(1f),
            fontWeight = FontWeight.Normal,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
                    .clickable { onRemove() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = Color.White, modifier = Modifier.size(12.dp))
            }

            if (!line.item.isWeighed) {
                Text(line.quantity.toString(), fontWeight = FontWeight.Normal, fontSize = 14.sp)

                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Blue)
                        .clickable { onAdd() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Increase", tint = Color.White, modifier = Modifier.size(12.dp))
                }
            }
        }
        Text(Peso.format(line.subtotal), modifier = Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold)
    }
}

@Composable
fun WeightInputDialog(
    item: InventoryItem,
    onConfirm: (Double, Double) -> Unit,
    onDismiss: () -> Unit
) {
    var inputText by remember { mutableStateOf(if (item.isKg) "1" else "50") }
    val inputVal = inputText.toDoubleOrNull() ?: 0.0
    val calculatedPrice = when {
        item.isKg -> roundPosPrice(inputVal * item.sellingPrice)
        item.isGrams -> roundPosPrice((inputVal / 1000.0) * item.sellingPrice)
        else -> 0.0
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Checkout Weight - ${item.name}", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    if (item.isKg) "Price: ${Peso.format(item.sellingPrice)} per kg"
                    else "Price: ${Peso.format(item.sellingPrice)} per 1000g (1kg)",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Text(
                    if (item.isKg) "Stock Available: ${item.displayStock} kg"
                    else "Stock Available: ${item.displayStock} grm",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { if (it.matches(Regex("""\d*([.]\d{0,2})?"""))) inputText = it },
                    label = { Text(if (item.isKg) "Weight (in kg)" else "Weight (in grams)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = ControlShape
                )
                Spacer(Modifier.height(8.dp))
                if (inputVal > 0.0) {
                    Text("Computed Price: ${Peso.format(calculatedPrice)}", fontWeight = FontWeight.Bold, color = Green, style = MaterialTheme.typography.titleMedium)
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                TextButton(
                    onClick = {
                        if (item.isKg) onConfirm(0.0, inputVal)
                        else onConfirm(inputVal, 0.0)
                        onDismiss()
                    },
                    enabled = inputVal > 0.0 && inputVal <= (if (item.isKg) item.stockQuantity / 1000.0 else item.stockQuantity.toDouble())
                ) {
                    Text("Add to Cart")
                }
            }
        }
    )
}
