package ph.alkris.pos.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ph.alkris.pos.ui.PdfExporter
import ph.alkris.pos.ui.components.ControlShape

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserManualScreen(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var currentPage by remember { mutableIntStateOf(1) }

    val totalPages = 4

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Alkris POS User Manual", fontWeight = FontWeight.Bold)
                        Text("PDF Document • In-App Guide", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = onDismiss) {
                        Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { if (currentPage > 1) currentPage-- },
                        enabled = currentPage > 1
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Page")
                    }

                    Text("Page $currentPage of $totalPages", fontWeight = FontWeight.Bold)

                    IconButton(
                        onClick = { if (currentPage < totalPages) currentPage++ },
                        enabled = currentPage < totalPages
                    ) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Page")
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    PdfExporter.downloadUserManualToDownloads(context)
                    Toast.makeText(context, "Downloaded AlKris_POS_User_Manual.pdf to Downloads", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth(),
                shape = ControlShape
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Download User Manual (PDF)")
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    when (currentPage) {
                        1 -> {
                            Text("ALKRIS POS - USER MANUAL", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                            Text("Offline Edition v8.3.2 • Point of Sale", fontWeight = FontWeight.Bold, color = Color.Gray)
                            HorizontalDivider()
                            Text("1. Getting Started & Sign-In", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("• Enter 4-digit PIN or use Fingerprint / Touch ID to sign in.")
                            Text("• Offline Core: Store sales, inventory stock, receipt printing, and customer debt tracking work 100% offline without internet connection.")
                            Text("• Auto-Logout: Terminal automatically locks after configurable minutes of inactivity to protect store transactions.")
                        }

                        2 -> {
                            Text("2. POS & Checkout Operations", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                            HorizontalDivider()
                            Text("• Barcode Scanning: Tap scanner icon to use built-in camera or pair Bluetooth HID scanner.")
                            Text("• Active Cart: Tap bottom floating cart bar to view items, modify quantities, apply discounts, or proceed to Checkout.")
                            Text("• Payment Methods: Supports Cash (with change calculator), GCash, Maya, Bank Transfer, and Credit (Utang).")
                            Text("• Thermal Printing: Prints receipts to connected 58mm/80mm Bluetooth thermal printers (PT-210 / MTP-II).")
                        }

                        3 -> {
                            Text("3. E-Services & Customer Credit Ledger", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                            HorizontalDivider()
                            Text("• E-Cash Services: Process Cash-In, Cash-Out, Buy-Load, and Bills Payment with real-time fee and commission tracking.")
                            Text("• Utang Ledger: Track customer credit accounts, record credit sales with customer signatures, partial down payments, and debt repayments.")
                            Text("• Debt Statements: Generate itemized Utang statements and export PDF/thermal receipts.")
                        }

                        else -> {
                            Text("4. Cash Drawer, Reports & Backups", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                            HorizontalDivider()
                            Text("• Cash Shifts & Drawer: Track opening starting float, cash additions/expenses, collections, and expected cash in drawer.")
                            Text("• Sales Analytics: View gross sales, cost of goods, discounts given, net profit, top selling items, and receipts history.")
                            Text("• Cloud & File Backups: Automatic Google Drive cloud backup sync when connected, plus instant SQLite (.db) export/import.")
                        }
                    }
                }
            }
        }
    }
}
