package ph.alkris.pos.ui.screens

import ph.alkris.pos.ui.components.CustomDateRangeDialog
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.CalendarToday
import android.content.Context
import android.content.res.Configuration
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import ph.alkris.pos.ui.ReceiptImageExporter
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.SaleLine
import ph.alkris.pos.data.AppMode
import androidx.compose.foundation.verticalScroll
import ph.alkris.pos.data.formattedReceiptCode
import ph.alkris.pos.ui.PdfExporter
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.components.*
import ph.alkris.pos.ui.printReceipt
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionsScreen(viewModel: PosViewModel, modifier: Modifier = Modifier, mode: AppMode = AppMode.MART) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val dateFormatter = remember { DateTimeFormatter.ofPattern("MMM dd, yyyy") }
    val timeFormatter = remember { DateTimeFormatter.ofPattern("hh:mm a") }
    var editingSaleId by rememberSaveable { mutableStateOf<String?>(null) }
    val editingSale = state.transactions.firstOrNull { it.id == editingSaleId }
    var voidingSale by remember { mutableStateOf<Sale?>(null) }
    var pinToConfirm by rememberSaveable { mutableStateOf("") }
    var historyStart by rememberSaveable { mutableStateOf(LocalDate.now().minusDays(30)) }
    var historyEnd by rememberSaveable { mutableStateOf(LocalDate.now()) }
    var historyPresetMenuExpanded by remember { mutableStateOf(false) }
    var showCustomDateRangeDialog by remember { mutableStateOf(false) }

    val dateRangeText = remember(historyStart, historyEnd) {
        val dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy")
        if (historyStart == historyEnd) {
            if (historyStart == LocalDate.now()) "Today (${historyStart.format(dtf)})"
            else if (historyStart == LocalDate.now().minusDays(1)) "Yesterday (${historyStart.format(dtf)})"
            else historyStart.format(dtf)
        } else {
            "${historyStart.format(dtf)} – ${historyEnd.format(dtf)}"
        }
    }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var sortMode by remember { mutableIntStateOf(0) }
    var historySearch by remember { mutableStateOf("") }
    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { output ->
                PdfExporter.exportSalesHistory(
                    output,
                    state.storeName,
                    historyStart,
                    historyEnd,
                    state.transactions
                )
            }
            viewModel.logActivity("PRINT", "Saved/Exported ${if (mode == AppMode.ECASH) "Ecash" else "Sales"} History PDF for $historyStart to $historyEnd")
        }
    }

    var showSearchField by remember { mutableStateOf(false) }
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    LaunchedEffect(Unit, mode) {
        viewModel.loadTransactions(historyStart, historyEnd)
    }

    Column(modifier = modifier.padding(horizontal = 16.dp, vertical = if (isLandscape) 4.dp else 16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Top) {
                InventoryAction(Icons.Default.PictureAsPdf, "Save PDF", if (isDark) Color.White else Blue) {
                    pdfLauncher.launch(if (mode == AppMode.ECASH) "ecash_history_${historyStart}_to_${historyEnd}.pdf" else "sales_history_${historyStart}_to_${historyEnd}.pdf")
                }

                Box {
                    InventoryAction(Icons.Default.DateRange, "Date Range", if (isDark) Color.White else Color.Unspecified) {
                        historyPresetMenuExpanded = true
                    }
                    DropdownMenu(
                        expanded = historyPresetMenuExpanded,
                        onDismissRequest = { historyPresetMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Today", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                historyStart = LocalDate.now()
                                historyEnd = historyStart
                                historyPresetMenuExpanded = false
                                viewModel.loadTransactions(historyStart, historyEnd)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Yesterday", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                historyStart = LocalDate.now().minusDays(1)
                                historyEnd = historyStart
                                historyPresetMenuExpanded = false
                                viewModel.loadTransactions(historyStart, historyEnd)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("This Week", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                historyStart = LocalDate.now().minusDays((LocalDate.now().dayOfWeek.value - 1).toLong())
                                historyEnd = LocalDate.now()
                                historyPresetMenuExpanded = false
                                viewModel.loadTransactions(historyStart, historyEnd)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("This Month", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                historyStart = LocalDate.now().withDayOfMonth(1)
                                historyEnd = LocalDate.now()
                                historyPresetMenuExpanded = false
                                viewModel.loadTransactions(historyStart, historyEnd)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Last Month", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                val currentMonth = LocalDate.now().withDayOfMonth(1)
                                historyEnd = currentMonth.minusDays(1)
                                historyStart = historyEnd.withDayOfMonth(1)
                                historyPresetMenuExpanded = false
                                viewModel.loadTransactions(historyStart, historyEnd)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Last 30 Days", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                historyStart = LocalDate.now().minusDays(30)
                                historyEnd = LocalDate.now()
                                historyPresetMenuExpanded = false
                                viewModel.loadTransactions(historyStart, historyEnd)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("All Time", fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                historyStart = LocalDate.of(2000, 1, 1)
                                historyEnd = LocalDate.now()
                                historyPresetMenuExpanded = false
                                viewModel.loadTransactions(historyStart, historyEnd)
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Custom Date Range...", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
                            onClick = {
                                historyPresetMenuExpanded = false
                                showCustomDateRangeDialog = true
                            }
                        )
                    }
                }
            }
            if (showSearchField || historySearch.isNotEmpty()) {
                OutlinedTextField(
                    value = historySearch,
                    onValueChange = { historySearch = it },
                    placeholder = { Text("Search", fontSize = 12.sp) },
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    textStyle = MaterialTheme.typography.bodySmall,
                    trailingIcon = {
                        IconButton(onClick = {
                            historySearch = ""
                            showSearchField = false
                        }) {
                            Icon(Icons.Default.Close, "Clear search")
                        }
                    }
                )
            } else {
                val dateTextColor = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface
                OutlinedButton(
                    onClick = { showCustomDateRangeDialog = true },
                    modifier = Modifier.weight(1f).height(40.dp),
                    shape = ControlShape,
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date Range", tint = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Text(
                            text = dateRangeText,
                            color = dateTextColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                InventoryAction(Icons.Default.Search, "Search", if (isDark) Color.White else Blue) {
                    showSearchField = true
                }
            }
            Box {
                InventoryAction(Icons.AutoMirrored.Filled.Sort, "Sort", if (isDark) Color.White else Color.Unspecified) {
                    sortMenuExpanded = true
                }
                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Newest first") },
                        onClick = { sortMode = 0; sortMenuExpanded = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Oldest first") },
                        onClick = { sortMode = 1; sortMode = 1; sortMenuExpanded = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Highest amount") },
                        onClick = { sortMode = 2; sortMenuExpanded = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Lowest amount") },
                        onClick = { sortMode = 3; sortMenuExpanded = false }
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        val search = historySearch.trim()
        val filteredTransactions = state.transactions.filter { sale ->
            search.isEmpty() ||
                sale.id.contains(search, ignoreCase = true) ||
                sale.customerName.contains(search, ignoreCase = true) ||
                sale.customerContact.contains(search, ignoreCase = true) ||
                sale.lines.any { it.itemName.contains(search, ignoreCase = true) }
        }
        val sortedTransactions = when (sortMode) {
            1 -> filteredTransactions.sortedBy { it.purchasedAt }
            2 -> filteredTransactions.sortedByDescending { it.total }
            3 -> filteredTransactions.sortedBy { it.total }
            else -> filteredTransactions.sortedByDescending { it.purchasedAt }
        }
        if (sortedTransactions.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("No transactions found.", color = Color.Gray, fontSize = 12.sp)
            }
        } else if (isLandscape && mode == AppMode.ECASH) {
            val chunkedTxns = remember(sortedTransactions) { sortedTransactions.chunked(2) }
            ScrollbarLazyColumn(Modifier.weight(1f)) {
                items(chunkedTxns.size) { rowIndex ->
                    val rowItems = chunkedTxns[rowIndex]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { sale ->
                            TransactionItemCard(
                                sale = sale,
                                storeName = state.storeName,
                                context = context,
                                viewModel = viewModel,
                                dateFormatter = dateFormatter,
                                timeFormatter = timeFormatter,
                                mode = mode,
                                onEdit = { editingSaleId = sale.id },
                                onVoidClick = { voidingSale = sale },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (rowItems.size == 1) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            ScrollbarLazyColumn(Modifier.weight(1f)) {
                items(sortedTransactions, key = { it.id }) { sale ->
                    TransactionItemCard(
                        sale = sale,
                        storeName = state.storeName,
                        context = context,
                        viewModel = viewModel,
                        dateFormatter = dateFormatter,
                        timeFormatter = timeFormatter,
                        mode = mode,
                        onEdit = { editingSaleId = sale.id },
                        onVoidClick = { voidingSale = sale },
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }
    }

    if (showCustomDateRangeDialog) {
        CustomDateRangeDialog(
            initialStart = historyStart,
            initialEnd = historyEnd,
            onConfirm = { newStart, newEnd ->
                historyStart = newStart
                historyEnd = newEnd
                viewModel.loadTransactions(historyStart, historyEnd)
            },
            onDismiss = { showCustomDateRangeDialog = false }
        )
    }

    if (editingSale != null) {
        val isEcash = editingSale.lines.any { it.barcode.startsWith("ECASH_") }
        AlertDialog(
            onDismissRequest = { editingSaleId = null; pinToConfirm = "" },
            title = { Text(if (isEcash) "Void / Cancel Ecash Transaction" else "Edit Transaction") },
            text = {
                Column {
                    Text(
                        if (isEcash) "Confirm with PIN to void/cancel this Ecash transaction. Funds will be returned to their respective wallets."
                        else "Confirm with PIN to load this sale back to cart for editing. The original sale will be voided."
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pinToConfirm,
                        onValueChange = { pinToConfirm = it },
                        label = { Text("PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { editingSaleId = null; pinToConfirm = "" }) { Text("Cancel") }
                    TextButton(
                        onClick = {
                            viewModel.editSale(editingSale, pinToConfirm)
                            editingSaleId = null
                            pinToConfirm = ""
                        }
                    ) { Text(if (isEcash) "Void Transaction" else "Confirm") }
                }
            }
        )
    }

    if (voidingSale != null) {
        VoidReceiptModal(
            sale = voidingSale!!,
            viewModel = viewModel,
            onDismiss = { voidingSale = null }
        )
    }
}

@Composable
private fun TransactionItemCard(
    sale: Sale,
    storeName: String,
    context: Context,
    viewModel: PosViewModel,
    dateFormatter: DateTimeFormatter,
    timeFormatter: DateTimeFormatter,
    mode: AppMode = AppMode.MART,
    onEdit: () -> Unit,
    onVoidClick: (Sale) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    Text(sale.purchasedAt.format(dateFormatter), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(sale.purchasedAt.format(timeFormatter), fontSize = 10.sp, color = Color.Gray)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Column(
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(Peso.format(sale.total), color = if (sale.paymentType == "CREDIT") Pink else Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        val isEcashSale = sale.lines.any { it.barcode.startsWith("ECASH_") }
                        if (mode != AppMode.ECASH && !isEcashSale) {
                            Text(
                                text = "Void",
                                color = Pink,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .clickable { onVoidClick(sale) }
                                    .padding(top = 2.dp, bottom = 2.dp)
                            )
                        }
                    }
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Edit, "Edit Transaction", tint = Blue, modifier = Modifier.size(20.dp))
                    }
                    IconButton(
                        onClick = {
                            ReceiptImageExporter.saveReceiptToGallery(context, sale, storeName)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            Icons.Default.Image,
                            contentDescription = "Save Receipt Image",
                            tint = Blue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = { printReceipt(context, sale, storeName, viewModel) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Print, "Reprint Receipt", modifier = Modifier.size(20.dp))
                    }
                }
            }
            Spacer(Modifier.height(2.dp))

            // PAYMENT TYPE BADGE (CASH, UTANG, or GCASH) ABOVE CONTROL NUMBER
            val paymentBadgeText = when {
                sale.paymentType == "CREDIT" -> "UTANG"
                sale.paymentType.equals("GCASH", ignoreCase = true) -> "GCASH"
                sale.paymentType.equals("EWALLET", ignoreCase = true) -> "GCASH"
                else -> "CASH"
            }
            val paymentBadgeColor = when (paymentBadgeText) {
                "UTANG" -> Pink
                "GCASH" -> Blue
                else -> Green
            }

            Surface(
                color = paymentBadgeColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.padding(bottom = 2.dp)
            ) {
                Text(
                    text = paymentBadgeText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = paymentBadgeColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Text(
                "Receipt #: ${sale.formattedReceiptCode(storeName)}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(4.dp))
            val isEcash = sale.lines.any { it.barcode.startsWith("ECASH_") }
            if (isEcash) {
                Text(sale.lines.firstOrNull()?.itemName ?: "Ecash Service", fontSize = 12.sp)
            } else {
                Text("${sale.itemCount} items sold", color = Color.Gray, fontSize = 10.sp)
                if (sale.paymentType == "CREDIT") {
                    Text("UTANG - ${sale.customerName}", color = Pink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Spacer(Modifier.height(4.dp))
                sale.lines.forEach { line ->
                    Text("${line.itemName} x${line.quantity}", fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun VoidReceiptModal(
    sale: Sale,
    viewModel: PosViewModel,
    onDismiss: () -> Unit
) {
    var pinToConfirm by remember { mutableStateOf("") }
    var selectedLineToVoid by remember { mutableStateOf<SaleLine?>(null) }
    var voidMode by remember { mutableStateOf("WHOLE") }

    val isEcash = sale.lines.any { it.barcode.startsWith("ECASH_") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Void Receipt / Item", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Receipt #: ${sale.id} • Total: ${Peso.format(sale.total)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (!isEcash && sale.lines.size > 1) {
                    Text("Select Void Option:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = voidMode == "WHOLE",
                            onClick = { voidMode = "WHOLE"; selectedLineToVoid = null },
                            label = { Text("Void Whole Receipt") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = voidMode == "LINE",
                            onClick = { voidMode = "LINE" },
                            label = { Text("Void Item Line") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (voidMode == "LINE" && !isEcash && sale.lines.size > 1) {
                    Text("Select Item to Void:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 140.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        sale.lines.forEach { line ->
                            Surface(
                                onClick = { selectedLineToVoid = line },
                                shape = ControlShape,
                                color = if (selectedLineToVoid?.barcode == line.barcode) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${line.itemName} x${line.quantity}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    Text(Peso.format(line.subtotal), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Pink)
                                }
                            }
                        }
                    }
                } else if (voidMode == "WHOLE") {
                    Text(
                        text = if (isEcash) "Voiding will cancel this Ecash transaction and return funds to respective balances."
                               else "Voiding will cancel the receipt, return stock to inventory, and reverse sales.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }

                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = pinToConfirm,
                    onValueChange = { pinToConfirm = it },
                    label = { Text("Confirm PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                Button(
                    onClick = {
                        if (voidMode == "LINE" && selectedLineToVoid != null) {
                            viewModel.voidLineItem(sale, selectedLineToVoid!!, pinToConfirm)
                        } else {
                            viewModel.editSale(sale, pinToConfirm)
                        }
                        onDismiss()
                    },
                    enabled = pinToConfirm.isNotBlank() && (voidMode == "WHOLE" || selectedLineToVoid != null),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink),
                    shape = ControlShape
                ) {
                    Text(if (voidMode == "LINE") "Confirm Void Item" else "Confirm Void Receipt")
                }
            }
        }
    )
}
