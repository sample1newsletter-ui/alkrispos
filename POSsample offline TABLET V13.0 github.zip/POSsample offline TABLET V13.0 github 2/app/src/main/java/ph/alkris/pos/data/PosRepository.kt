package ph.alkris.pos.data

import java.time.LocalDate
import java.io.InputStream
import java.io.OutputStream

interface PosRepository {
    suspend fun authenticate(pin: String): Boolean
    suspend fun updatePin(newPin: String)
    suspend fun getStoreName(): String
    suspend fun updateStoreName(name: String)
    suspend fun inventory(): List<InventoryItem>
    suspend fun saveItem(item: InventoryItem)
    suspend fun deleteItem(barcode: String)
    suspend fun completeSale(sale: Sale)
    suspend fun customerReceivable(contact: String): Double
    suspend fun debtors(): List<Debtor>
    suspend fun saveCustomer(name: String, phone: String, address: String = "", creditLimit: Double = 0.0, signature: ByteArray? = null)
    suspend fun recordDebtPayment(payment: DebtPayment)
    suspend fun debtPayments(): List<DebtPayment>
    suspend fun voidSale(saleId: String)
    suspend fun salesBetween(start: LocalDate, end: LocalDate): List<Sale>
    suspend fun totalCash(): Double
    suspend fun cashBalanceAt(date: LocalDate): Double
    suspend fun recordCashWithdrawal(withdrawal: CashWithdrawal)
    suspend fun cashWithdrawals(): List<CashWithdrawal>
    suspend fun recordCashCapital(capital: CashCapital)
    suspend fun cashCapitals(): List<CashCapital>
    suspend fun exportDatabase(output: OutputStream, format: String = "db")
    suspend fun importDatabase(input: InputStream)
    suspend fun importDatabaseTarget(input: InputStream, target: String = "BOTH")
    suspend fun resetDatabase(preset: String = "400+")
    suspend fun logActivity(action: String, details: String)
    suspend fun activityLogs(start: LocalDate, end: LocalDate): List<ActivityLog>
    suspend fun getStoreLogoBase64(): String?
    suspend fun saveStoreLogoBase64(base64: String?)
    suspend fun recordEcashAdjustment(adjustment: EcashAdjustment)
    suspend fun ecashAdjustmentsBetween(start: LocalDate, end: LocalDate): List<EcashAdjustment>
    suspend fun totalEwalletBalance(): Double
    suspend fun updateItemImage(barcode: String, imagePath: String)
}
