package ph.alkris.pos.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.ui.platform.LocalContext
import ph.alkris.pos.ui.ReceiptImageExporter
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.widget.Toast
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.input.PasswordVisualTransformation
import java.time.LocalDateTime
import ph.alkris.pos.ui.PosViewModel
import ph.alkris.pos.ui.screens.SignaturePad
import ph.alkris.pos.ui.screens.signatureToBytes
import ph.alkris.pos.data.DebtPayment
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.AppMode
import ph.alkris.pos.ui.components.Blue
import ph.alkris.pos.ui.components.ControlShape
import ph.alkris.pos.ui.components.Green
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.ui.components.Pink
import ph.alkris.pos.ui.components.ScrollbarLazyColumn
import java.util.Locale
import kotlin.math.round

@Composable
fun DebtorsDialog(debtors: List<Debtor>, onDismiss: () -> Unit, onSelect: (Debtor) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Debtor Customer", fontWeight = FontWeight.Bold) },
        text = {
            if (debtors.isEmpty()) Text("Walang nakatalang may utang.")
            else ScrollbarLazyColumn(Modifier.height(240.dp)) {
                items(debtors, key = { it.contact }) { debtor ->
                    TextButton(onClick = { onSelect(debtor) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(debtor.name, fontWeight = FontWeight.Bold)
                            Text("${debtor.contact}  ${Peso.format(debtor.totalOwed)}", color = Pink)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun UtangDialog(
    debtors: List<Debtor>,
    debtPayments: List<DebtPayment>,
    initialDebtor: Debtor?,
    onPay: (Debtor, Double, Double) -> Unit,
    onPrintItems: (Debtor) -> Unit,
    onPrintPayment: (DebtPayment) -> Unit,
    onSavePdf: () -> Unit,
    onPrint: () -> Unit,
    onDismiss: () -> Unit,
    mode: AppMode = AppMode.MART,
    onSaveDebtorPdf: ((Debtor) -> Unit)? = null
) {
    val debtor = initialDebtor ?: return
    var amountText by rememberSaveable { mutableStateOf("") }
    var cashReceivedText by rememberSaveable { mutableStateOf("") }

    val paymentAmount = amountText.toDoubleOrNull() ?: 0.0
    val cashReceived = cashReceivedText.toDoubleOrNull() ?: 0.0
    val payCents = round(paymentAmount * 100.0).toLong()
    val cashCents = round(cashReceived * 100.0).toLong()
    val owedCents = round(debtor.totalOwed * 100.0).toLong()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("${debtor.name.substringBefore(" ").ifBlank { debtor.name }} Utang", fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text("Current balance: ${Peso.format(debtor.totalOwed)}", color = Pink, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { input ->
                        val sanitized = input.replace(',', '.')
                        if (sanitized.matches(Regex("""\d*([.]\d{0,2})?"""))) amountText = sanitized
                    },
                    label = { Text("Payment amount") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = cashReceivedText,
                    onValueChange = { input ->
                        val sanitized = input.replace(',', '.')
                        if (sanitized.matches(Regex("""\d*([.]\d{0,2})?"""))) cashReceivedText = sanitized
                    },
                    label = { Text("Cash received") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )

                if (cashCents >= payCents && payCents > 0L) {
                    Spacer(Modifier.height(4.dp))
                    Text("Change: ${Peso.format((cashCents - payCents) / 100.0)}", color = Green, fontWeight = FontWeight.Bold)
                }
                val payments = debtPayments
                    .filter { it.contact == debtor.contact || it.debtorName == debtor.name }
                    .sortedByDescending { it.paidAt }
                if (payments.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Previous Utang Receipts", fontWeight = FontWeight.Bold)
                    ScrollbarLazyColumn(Modifier.height(110.dp)) {
                        items(payments, key = { it.id }) { payment ->
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${payment.paidAt.toLocalDate()}  ${Peso.format(payment.amount)}",
                                    fontSize = 12.sp
                                )
                                TextButton(onClick = { onPrintPayment(payment) }) {
                                    Icon(Icons.Default.Print, contentDescription = "Reprint Utang payment receipt")
                                    Text(" Reprint", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { onPrintItems(debtor) }) {
                        Icon(Icons.Default.Print, contentDescription = "Print purchased items")
                        Text(" Items")
                    }
                    TextButton(
                        onClick = {
                            if (payCents > 0L && payCents <= owedCents && cashCents >= payCents) {
                                val finalAmount = if (payCents == owedCents) debtor.totalOwed else (payCents / 100.0)
                                val finalCash = cashCents / 100.0
                                onPay(debtor, finalAmount, finalCash)
                                amountText = ""
                                cashReceivedText = ""
                                onDismiss()
                            }
                        },
                        enabled = payCents > 0L && payCents <= owedCents && cashCents >= payCents
                    ) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Pay Utang", tint = Green)
                        Text(" Pay")
                    }
                }
            }
        }
    )
}

@Composable
fun DebtPaymentReceiptDialog(
    payment: DebtPayment,
    storeName: String = "ALKRIS POS",
    onPrint: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Payment Receipt") },
        text = {
            Column {
                Text("Debtor: ${payment.debtorName}", fontWeight = FontWeight.Bold)
                Text("Contact: ${payment.contact}")
                Text("Previous balance: ${Peso.format(payment.previousBalance)}")
                Text("Cash payment: ${Peso.format(payment.amount)}", color = Green, fontWeight = FontWeight.Bold)
                Text("Cash received: ${Peso.format(payment.cashReceived)}")
                Text("Change: ${Peso.format(payment.change)}", color = Blue)
                Text("Remaining balance: ${Peso.format(payment.remainingBalance)}", color = if (payment.remainingBalance == 0.0) Green else Pink)
                Spacer(Modifier.height(16.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { ReceiptImageExporter.saveDebtPaymentReceiptToGallery(context, payment, storeName) }
                            .padding(8.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = "E-receipt", tint = Blue, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.height(4.dp))
                        Text("E-receipt", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable(onClick = onPrint)
                            .padding(8.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = "Print", tint = Blue, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.height(4.dp))
                        Text("Print", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
fun AddCustomerProfileDialog(
    viewModel: PosViewModel,
    initialDebtor: Debtor? = null,
    onDismiss: () -> Unit,
    onCustomerSaved: ((Debtor) -> Unit)? = null
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initialDebtor?.name ?: "") }
    var phone by remember { mutableStateOf(initialDebtor?.contact ?: "") }
    var address by remember { mutableStateOf(initialDebtor?.address ?: "") }
    var creditLimitText by remember { mutableStateOf(if ((initialDebtor?.creditLimit ?: 0.0) > 0.0) initialDebtor!!.creditLimit.toInt().toString() else "") }
    val custSignaturePoints = remember { mutableStateOf<List<List<Offset>>>(emptyList()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialDebtor == null) "Add New Customer Profile" else "Edit Customer Profile", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Customer Name *") },
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Contact Number *") },
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address (Optional)") },
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = creditLimitText,
                    onValueChange = { creditLimitText = it },
                    label = { Text("Credit Limit (₱) (0 for unlimited)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = ControlShape,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Customer Agreement Signature *", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    if (custSignaturePoints.value.isNotEmpty()) {
                        TextButton(
                            onClick = { custSignaturePoints.value = emptyList() },
                            modifier = Modifier.height(28.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                        ) {
                            Text("Clear", color = Pink, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                if (initialDebtor?.signature != null && initialDebtor.signature.isNotEmpty() && custSignaturePoints.value.isEmpty()) {
                    Surface(
                        color = Green.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("✓ Saved Signature On File (Sign below to update)", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(8.dp))
                    }
                }

                SignaturePad(custSignaturePoints)
                Text("Statement: I understand and agree to pay the total owed balance of all transactions made under my account within 10 days from the date of each transaction, and that I may receive an SMS or call on the 10th day after the transaction.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) {
                    Text("Cancel")
                }
                Button(
                    onClick = {
                        val nameClean = name.trim()
                        val phoneClean = phone.trim()
                        if (nameClean.isNotBlank() && phoneClean.isNotBlank()) {
                            val hasExistingSig = initialDebtor?.signature != null && initialDebtor.signature.isNotEmpty()
                            if (!hasExistingSig && custSignaturePoints.value.isEmpty()) {
                                Toast.makeText(context, "Please sign customer agreement before saving profile", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val limitVal = creditLimitText.toDoubleOrNull() ?: 0.0
                            val sigBytes = if (custSignaturePoints.value.isNotEmpty()) signatureToBytes(custSignaturePoints.value) else initialDebtor?.signature

                            val createdDebtor = Debtor(
                                name = nameClean,
                                contact = phoneClean,
                                totalOwed = initialDebtor?.totalOwed ?: 0.0,
                                lastTransactionAt = initialDebtor?.lastTransactionAt ?: LocalDateTime.now(),
                                signature = sigBytes,
                                address = address.trim(),
                                creditLimit = limitVal
                            )

                            viewModel.saveCustomer(nameClean, phoneClean, address.trim(), limitVal, sigBytes)
                            viewModel.loadDebtors()
                            onCustomerSaved?.invoke(createdDebtor)
                            onDismiss()
                            Toast.makeText(context, "Customer profile saved: $nameClean", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Name and contact number are required", Toast.LENGTH_SHORT).show()
                        }
                    },
                    shape = ControlShape
                ) {
                    Text(if (initialDebtor == null) "Save Profile" else "Save Changes")
                }
            }
        }
    )
}