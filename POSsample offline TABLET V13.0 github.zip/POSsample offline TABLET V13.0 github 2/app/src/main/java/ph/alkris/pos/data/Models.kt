package ph.alkris.pos.data

import androidx.compose.runtime.Immutable
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

enum class AppMode {
    MART,
    ECASH
}

fun generateReceiptCode(storeName: String = "ALKRIS POS", timestamp: LocalDateTime = LocalDateTime.now(), type: String = "CS"): String {
    val initials = storeName.split(" ").mapNotNull { it.firstOrNull() }.joinToString("").uppercase().ifBlank { "POS" }
    val timeStr = timestamp.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
    return "$initials-$type-$timeStr"
}

fun Sale.formattedReceiptCode(storeName: String = "ALKRIS POS"): String {
    // If it's an Ecash transaction with our new prefixes, keep it as is
    if (id.contains("-CI-") || id.contains("-CO-") || id.contains("-L-") || id.contains("-B-") || id.contains("-P-") || id.contains("-EC-")) {
        return id
    }
    
    val expectedType = if (paymentType == "CREDIT") "US" else "CS"
    if (id.contains("-CS-") || id.contains("-US-")) {
        return id
    }
    if (id.contains("-S-")) {
        return id.replace("-S-", "-$expectedType-")
    }
    return generateReceiptCode(storeName, purchasedAt, expectedType)
}

fun DebtPayment.formattedReceiptCode(storeName: String = "ALKRIS POS"): String {
    if (id.contains("-UP-")) {
        return id
    }
    if (id.contains("-U-")) {
        return id.replace("-U-", "-UP-")
    }
    return generateReceiptCode(storeName, paidAt, "UP")
}

fun roundPosPrice(amount: Double): Double {
    if (amount <= 0.0) return 0.0
    return Math.round(amount).toDouble()
}

fun generateDateList(start: LocalDate, end: LocalDate): List<LocalDate> {
    if (start.isAfter(end)) return listOf(start)
    val list = mutableListOf<LocalDate>()
    var curr = start
    while (!curr.isAfter(end)) {
        list.add(curr)
        curr = curr.plusDays(1)
    }
    return list
}

@Immutable
data class InventoryItem(
    val barcode: String,
    val name: String,
    val purchaseCost: Double,
    val sellingPrice: Double,
    val stockQuantity: Int,
    val lowStockLimit: Int,
    val recommendedStock: Int = 10,
    val addedAt: LocalDateTime = LocalDateTime.now(),
    val unit: String = "pcs",
    val category: String = "General",
    val imagePath: String? = null,
    val expiryDate: LocalDate = LocalDate.now().plusYears(1)
) {
    val isExpired: Boolean get() = expiryDate.isBefore(LocalDate.now())
    val isExpiringSoon: Boolean get() = !isExpired && expiryDate.isBefore(LocalDate.now().plusDays(30))
    val displayExpiryDate: String get() = expiryDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))

    val effectiveCategory: String
        get() {
            if (category.isNotBlank() && category != "General") return category
            val lower = name.lowercase()
            return when {
                lower.contains("noodle") || lower.contains("canton") || lower.contains("ramen") || lower.contains("spaghetti") || lower.contains("pasta") || lower.contains("macaroni") || lower.contains("bihon") || lower.contains("sotanghon") -> "Noodles & Pasta"
                lower.contains("tuna") || lower.contains("sardines") || lower.contains("corned beef") || lower.contains("meat loaf") || lower.contains("beef loaf") || lower.contains("spam") || lower.contains("luncheon") || lower.contains("sausage") || lower.contains("pork & beans") || lower.contains("liver spread") || lower.contains("hotdog") -> "Canned Goods & Meat"
                lower.contains("coffee") || lower.contains("nescafe") || lower.contains("kopiko") || lower.contains("milk") || lower.contains("bear brand") || lower.contains("alaska") || lower.contains("milo") || lower.contains("coca-cola") || lower.contains("royal") || lower.contains("sprite") || lower.contains("pepsi") || lower.contains("c2") || lower.contains("cobra") || lower.contains("sting") || lower.contains("gatorade") || lower.contains("tea") || lower.contains("drink") || lower.contains("water") -> "Coffee, Milk & Beverages"
                lower.contains("soy sauce") || lower.contains("toyo") || lower.contains("vinegar") || lower.contains("suka") || lower.contains("sauce") || lower.contains("seasoning") || lower.contains("ketchup") || lower.contains("magic sarap") || lower.contains("cubes") || lower.contains("oil") || lower.contains("oyster") || lower.contains("salt") || lower.contains("pepper") -> "Condiments & Seasonings"
                lower.contains("piattos") || lower.contains("chips") || lower.contains("cornick") || lower.contains("crackers") || lower.contains("skyflakes") || lower.contains("biscuits") || lower.contains("fudgee") || lower.contains("pillows") || lower.contains("chocolate") || lower.contains("choc") || lower.contains("candy") || lower.contains("mentos") || lower.contains("wafer") || lower.contains("snack") -> "Snacks, Biscuits & Sweets"
                lower.contains("soap") || lower.contains("safeguard") || lower.contains("shampoo") || lower.contains("conditioner") || lower.contains("toothpaste") || lower.contains("colgate") || lower.contains("close-up") || lower.contains("deodorant") || lower.contains("rexona") || lower.contains("cleanser") || lower.contains("lotion") || lower.contains("powder") || lower.contains("sanitary") || lower.contains("tissue") || lower.contains("alcohol") -> "Personal Care & Hygiene"
                lower.contains("detergent") || lower.contains("surf") || lower.contains("breeze") || lower.contains("tide") || lower.contains("ariel") || lower.contains("champion") || lower.contains("fabric") || lower.contains("downy") || lower.contains("dishwashing") || lower.contains("joy") || lower.contains("bleach") || lower.contains("zonrox") || lower.contains("domex") || lower.contains("lysol") || lower.contains("baygon") || lower.contains("cleaner") -> "Laundry & Household"
                lower.contains("rice") || lower.contains("cream") || lower.contains("cheese") || lower.contains("butter") || lower.contains("margarine") || lower.contains("jam") || lower.contains("peanut butter") || lower.contains("hotcake") || lower.contains("flour") || lower.contains("baking") -> "Cooking Ingredients & Dairy"
                lower.contains("ice cream") || lower.contains("tocino") || lower.contains("longganisa") || lower.contains("bacon") || lower.contains("nuggets") || lower.contains("bangus") || lower.contains("squid") || lower.contains("fish ball") -> "Frozen & Chilled"
                else -> "General"
            }
        }
    val isOutOfStock: Boolean get() = stockQuantity <= 0
    val isLowStock: Boolean get() = !isOutOfStock && stockQuantity <= lowStockLimit
    val isGrams: Boolean get() = unit.equals("grm", ignoreCase = true) || unit.equals("grams", ignoreCase = true)
    val isKg: Boolean get() = unit.equals("kg", ignoreCase = true) || unit.equals("kilograms", ignoreCase = true)
    val isMeters: Boolean get() = unit.equals("m", ignoreCase = true) || unit.equals("meters", ignoreCase = true) || unit.equals("meter", ignoreCase = true)
    val isWeighed: Boolean get() = isGrams || isKg
    val displayStock: String
        get() = if (isKg) {
            val kgVal = stockQuantity / 1000.0
            if (kgVal % 1.0 == 0.0) "${kgVal.toInt()}" else "$kgVal"
        } else if (isMeters) {
            "$stockQuantity m"
        } else {
            "$stockQuantity"
        }
    val displayLowLimit: String
        get() = if (isKg) {
            val kgVal = lowStockLimit / 1000.0
            if (kgVal % 1.0 == 0.0) "${kgVal.toInt()}" else "$kgVal"
        } else if (isMeters) {
            "$lowStockLimit m"
        } else {
            "$lowStockLimit"
        }
    val displayRecommended: String
        get() = if (isKg) {
            val kgVal = recommendedStock / 1000.0
            if (kgVal % 1.0 == 0.0) "${kgVal.toInt()}" else "$kgVal"
        } else if (isMeters) {
            "$recommendedStock m"
        } else {
            "$recommendedStock"
        }
}

@Immutable
data class CartLine(
    val item: InventoryItem,
    val quantity: Int = 1,
    val grams: Double = 0.0,
    val weightKg: Double = 0.0
) {
    val subtotal: Double
        get() = when {
            item.isKg -> roundPosPrice(weightKg * item.sellingPrice)
            item.isGrams -> roundPosPrice((grams.coerceAtLeast(1.0) / 1000.0) * item.sellingPrice)
            else -> roundPosPrice(item.sellingPrice * quantity)
        }

    val profit: Double
        get() = when {
            item.isKg -> (subtotal - weightKg * item.purchaseCost).coerceAtLeast(0.0)
            item.isGrams -> (subtotal - (grams.coerceAtLeast(1.0) / 1000.0) * item.purchaseCost).coerceAtLeast(0.0)
            else -> ((item.sellingPrice - item.purchaseCost) * quantity).coerceAtLeast(0.0)
        }
}

@Immutable
data class SaleLine(
    val barcode: String,
    val itemName: String,
    val quantity: Int,
    val unitPrice: Double,
    val unitCost: Double,
    val unit: String = "pcs",
    val grams: Double = 0.0,
    val weightKg: Double = 0.0
) {
    val subtotal: Double
        get() = when {
            unit.equals("kg", ignoreCase = true) || unit.equals("kilograms", ignoreCase = true) -> roundPosPrice(weightKg * unitPrice)
            unit.equals("grm", ignoreCase = true) || unit.equals("grams", ignoreCase = true) -> roundPosPrice((grams.coerceAtLeast(1.0) / 1000.0) * unitPrice)
            else -> roundPosPrice(unitPrice * quantity)
        }

    val costTotal: Double
        get() = when {
            unit.equals("kg", ignoreCase = true) || unit.equals("kilograms", ignoreCase = true) -> weightKg * unitCost
            unit.equals("grm", ignoreCase = true) || unit.equals("grams", ignoreCase = true) -> (grams.coerceAtLeast(1.0) / 1000.0) * unitCost
            else -> unitCost * quantity
        }
}

@Immutable
data class Sale(
    val id: String = generateReceiptCode("ALKRIS POS", LocalDateTime.now(), "CS"),
    val purchasedAt: LocalDateTime = LocalDateTime.now(),
    val lines: List<SaleLine>,
    val discount: Double = 0.0,
    val paymentType: String = "CASH",
    val customerName: String = "Walkin",
    val customerContact: String = "",
    val signature: ByteArray? = null,
    val cashReceived: Double = 0.0,
    val change: Double = 0.0
) {
    val total: Double get() = (lines.sumOf { it.subtotal } - discount).coerceAtLeast(0.0)
    val profit: Double get() = (total - lines.sumOf { it.costTotal }).coerceAtLeast(0.0)
    val itemCount: Int get() = lines.sumOf { it.quantity }
    val cashAmount: Double get() = if (paymentType == "CASH") total else (cashReceived - change).coerceAtLeast(0.0)
}

@Immutable
data class Debtor(
    val name: String,
    val contact: String,
    val totalOwed: Double,
    val lastTransactionAt: LocalDateTime,
    val signature: ByteArray? = null,
    val address: String = "",
    val creditLimit: Double = 0.0
)

@Immutable
data class DebtPayment(
    val id: String = generateReceiptCode("ALKRIS POS", LocalDateTime.now(), "UP"),
    val debtorName: String,
    val contact: String,
    val amount: Double,
    val cashReceived: Double = amount,
    val change: Double = (cashReceived - amount).coerceAtLeast(0.0),
    val paidAt: LocalDateTime = LocalDateTime.now(),
    val previousBalance: Double = 0.0,
    val remainingBalance: Double = 0.0
)

@Immutable
data class SalesSummary(val totalSales: Double = 0.0, val totalProfit: Double = 0.0, val itemsSold: Int = 0)

@Immutable
data class CashWithdrawal(
    val id: String = UUID.randomUUID().toString(),
    val amount: Double,
    val note: String = "",
    val withdrawnAt: LocalDateTime = LocalDateTime.now()
)

@Immutable
data class CashCapital(
    val id: String = UUID.randomUUID().toString(),
    val amount: Double,
    val note: String = "",
    val addedAt: LocalDateTime = LocalDateTime.now()
)

@Immutable
data class ActivityLog(
    val id: String = UUID.randomUUID().toString(),
    val action: String,
    val details: String,
    val timestamp: LocalDateTime = LocalDateTime.now()
)

@Immutable
data class EcashAdjustment(
    val id: String = UUID.randomUUID().toString(),
    val type: String, // "ADD" or "MINUS"
    val wallet: String, // "EWALLET" or "CASH"
    val amount: Double,
    val note: String = "",
    val adjustedAt: LocalDateTime = LocalDateTime.now()
)

@Immutable
data class EcashDetails(
    val serviceType: String,
    val customerName: String,
    val address: String,
    val contactNumber: String,
    val referenceNumber: String,
    val serviceDetails: String,
    val principal: Double,
    val serviceFee: Double,
    val isPrinting: Boolean,
    val isCashOut: Boolean
)

fun Sale.extractEcashDetails(): EcashDetails? {
    val ecashLine = lines.firstOrNull { it.barcode.startsWith("ECASH_") } ?: return null
    val rawItemName = ecashLine.itemName
    val serviceType = rawItemName.substringBefore(" (").ifBlank { "Ecash Service" }
    val isPrinting = serviceType.equals("Printing", ignoreCase = true) || serviceType.equals("Print", ignoreCase = true)
    val isCashOut = serviceType.equals("Cash-Out", ignoreCase = true)

    val principalStr = rawItemName.substringAfter(" - ₱", "").substringBefore(" [", "").substringBefore("]", "")
    val principal = if (isPrinting) 0.0 else (principalStr.toDoubleOrNull() ?: ecashLine.unitCost)
    val serviceFee = if (isPrinting || isCashOut) total else (total - principal).coerceAtLeast(0.0)

    var contactNo = ""
    var refNo = ""
    if (customerContact.contains(" | Ref: ")) {
        contactNo = customerContact.substringBefore(" | Ref: ").trim()
        refNo = customerContact.substringAfter(" | Ref: ").trim()
    } else if (customerContact.startsWith("Ref: ")) {
        refNo = customerContact.removePrefix("Ref: ").trim()
    } else {
        if (customerContact.isNotBlank() && customerContact != id) {
            if (rawItemName.contains("[Ref: ")) {
                refNo = rawItemName.substringAfter("[Ref: ").substringBefore("]").trim()
                contactNo = customerContact.trim()
            } else {
                refNo = customerContact.trim()
            }
        } else if (rawItemName.contains("[Ref: ")) {
            refNo = rawItemName.substringAfter("[Ref: ").substringBefore("]").trim()
        }
    }

    var serviceDetails = ""
    if (rawItemName.contains("[Details: ")) {
        serviceDetails = rawItemName.substringAfter("[Details: ").substringBefore("]").trim()
    }

    var custName = customerName.trim()
    var address = ""

    if (custName.contains(" [Addr: ")) {
        address = custName.substringAfter(" [Addr: ").substringBefore("]").trim()
        custName = custName.substringBefore(" [Addr: ").trim()
    } else if (custName.contains(" (Addr: ")) {
        address = custName.substringAfter(" (Addr: ").substringBefore(")").trim()
        custName = custName.substringBefore(" (Addr: ").trim()
    } else if (isPrinting && custName.contains(" - ")) {
        val possibleDetails = custName.substringAfter(" - ").trim()
        if (serviceDetails.isBlank()) serviceDetails = possibleDetails
        custName = custName.substringBefore(" - ").trim()
    }

    if (custName.contains(" (") && custName.endsWith(")")) {
        val possibleAddr = custName.substringAfter(" (").removeSuffix(")").trim()
        custName = custName.substringBefore(" (").trim()
        if (address.isBlank()) address = possibleAddr
    }

    if (custName.equals("Walkin", ignoreCase = true)) {
        custName = ""
    }

    return EcashDetails(
        serviceType = serviceType,
        customerName = custName,
        address = address,
        contactNumber = contactNo,
        referenceNumber = refNo,
        serviceDetails = serviceDetails,
        principal = principal,
        serviceFee = serviceFee,
        isPrinting = isPrinting,
        isCashOut = isCashOut
    )
}
