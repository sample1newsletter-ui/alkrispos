package ph.alkris.pos.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.UserRecoverableAuthException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ph.alkris.pos.ui.components.Peso
import ph.alkris.pos.data.ActivityLog
import java.io.ByteArrayInputStream
import java.time.LocalDateTime
import ph.alkris.pos.data.BackupManager
import ph.alkris.pos.data.CartLine
import ph.alkris.pos.data.CashWithdrawal
import ph.alkris.pos.data.CashCapital
import ph.alkris.pos.data.InventoryItem
import ph.alkris.pos.data.PosRepository
import ph.alkris.pos.data.AppMode
import ph.alkris.pos.data.EcashAdjustment
import ph.alkris.pos.data.Sale
import ph.alkris.pos.data.formattedReceiptCode
import ph.alkris.pos.data.SaleLine
import ph.alkris.pos.data.SalesSummary
import ph.alkris.pos.data.Debtor
import ph.alkris.pos.data.DebtPayment
import ph.alkris.pos.data.generateReceiptCode
import java.time.LocalDate
import java.io.InputStream
import java.io.OutputStream
import kotlin.math.round

data class PosUiState(
    val storeName: String = "ALKRIS POS",
    val authenticated: Boolean = false,
    val currentMode: AppMode = AppMode.MART,
    val modeSelected: Boolean = true,
    val loading: Boolean = false,
    val pinError: String? = null,
    val inventory: List<InventoryItem> = emptyList(),
    val query: String = "",
    val cart: List<CartLine> = emptyList(),
    val lastSale: Sale? = null,
    val transactions: List<Sale> = emptyList(),
    val currentReportSales: List<Sale> = emptyList(),
    val summary: SalesSummary = SalesSummary(),
    val message: String? = null,
    val cashTotal: Double? = null,
    val cashError: String? = null
    ,val cashHistory: List<CashWithdrawal> = emptyList(),
    val cashCapitals: List<CashCapital> = emptyList(),
    val cashHistorySales: List<Sale> = emptyList()
    ,val cashHistoryDebtPayments: List<DebtPayment> = emptyList()
    ,val cashHistoryStartingCash: Double = 0.0
    ,val cashHistoryEndingCash: Double = 0.0
    ,val debtors: List<Debtor> = emptyList()
    ,val debtPayments: List<DebtPayment> = emptyList()
    ,val skippedInventoryBarcodes: List<String> = emptyList()
    ,val lastDebtPayment: DebtPayment? = null
    ,val storeLogoBase64: String? = null
    ,val activityLogs: List<ActivityLog> = emptyList()
    ,val ewalletBalance: Double = 0.0
    ,val ecashAdjustments: List<EcashAdjustment> = emptyList()
) {
    val filteredInventory get() = inventory
        .filter {
            val search = query.trim()
            search.isEmpty() ||
                it.name.contains(search, ignoreCase = true) ||
                it.barcode.contains(search, ignoreCase = true)
        }
        .sortedWith(compareBy({ !it.isOutOfStock }, { !it.isLowStock }, { it.name }))
    
    val sortedInventory get() = inventory.sortedWith(compareBy({ !it.isOutOfStock }, { !it.isLowStock }, { it.name }))
    
    val total get() = cart.sumOf { it.subtotal }
}

class PosViewModel(
    private val martRepository: PosRepository,
    private val ecashRepository: PosRepository = martRepository
) : ViewModel() {
    private val _state = MutableStateFlow(PosUiState())
    val state: StateFlow<PosUiState> = _state.asStateFlow()

    private val repository: PosRepository
        get() = if (_state.value.currentMode == AppMode.ECASH) ecashRepository else martRepository

    suspend fun authenticatePin(pin: String): Boolean {
        val trimmed = pin.trim()
        if (trimmed.isBlank()) return false

        val martMatch = martRepository.authenticate(trimmed)
        val ecashMatch = ecashRepository.authenticate(trimmed)

        if (martMatch || ecashMatch) {
            if (!martMatch) martRepository.updatePin(trimmed)
            if (!ecashMatch) ecashRepository.updatePin(trimmed)
            return true
        }

        return false
    }

    init {
        loadStoreInfo()
    }

    fun setMode(mode: AppMode) {
        _state.update { it.copy(currentMode = mode, modeSelected = true) }
        loadStoreInfo()
        refreshInventory()
        loadSummary(LocalDate.now().minusDays(30), LocalDate.now())
        loadTransactions()
        loadDebtors()
        loadDebtPayments()
    }

    fun clearMode() {
        _state.update { it.copy(modeSelected = false) }
    }

    private fun loadStoreInfo() = viewModelScope.launch {
        val martName = martRepository.getStoreName().ifBlank { "ALKRIS POS" }
        val ecashName = ecashRepository.getStoreName().ifBlank { "ALKRIS POS" }
        val effectiveName = when {
            martName != "ALKRIS POS" -> martName
            ecashName != "ALKRIS POS" -> ecashName
            else -> "ALKRIS POS"
        }

        if (martName != effectiveName) {
            martRepository.updateStoreName(effectiveName)
        }
        if (ecashName != effectiveName) {
            ecashRepository.updateStoreName(effectiveName)
        }

        val ewalletBal = repository.totalEwalletBalance()
        _state.update { 
            it.copy(
                storeName = effectiveName,
                storeLogoBase64 = repository.getStoreLogoBase64(),
                ewalletBalance = ewalletBal
            ) 
        }
    }

    fun loadEcashAdjustments(start: LocalDate = LocalDate.now().minusDays(30), end: LocalDate = LocalDate.now()) = viewModelScope.launch {
        try {
            val list = repository.ecashAdjustmentsBetween(start, end).toMutableList()
            val debtPayments = repository.debtPayments().filter { it.paidAt.toLocalDate() in start..end }
            debtPayments.forEach { dp ->
                val noteStr = "Utang Payment - ${dp.debtorName}"
                if (list.none { it.note.contains(dp.debtorName) && it.amount == dp.amount && it.adjustedAt.toLocalDate() == dp.paidAt.toLocalDate() }) {
                    list.add(
                        EcashAdjustment(
                            id = dp.id,
                            type = "ADD",
                            wallet = "CASH",
                            amount = dp.amount,
                            note = noteStr,
                            adjustedAt = dp.paidAt
                        )
                    )
                }
            }
            val sortedList = list.sortedByDescending { it.adjustedAt }
            val ewalletBal = repository.totalEwalletBalance()
            _state.update { it.copy(ecashAdjustments = sortedList, ewalletBalance = ewalletBal) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun recordEcashAdjustment(type: String, wallet: String, amount: Double, note: String, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) = viewModelScope.launch {
        try {
            require(amount > 0.0) { "Amount must be greater than zero" }
            if (type == "MINUS") {
                if (wallet == "EWALLET") {
                    val availableEwallet = ecashRepository.totalEwalletBalance()
                    require(amount <= availableEwallet) {
                        "Transaction Declined: Insufficient E-Wallet balance (Available: ₱${Peso.format(availableEwallet)})"
                    }
                } else if (wallet == "CASH") {
                    val availableCash = martRepository.totalCash()
                    require(amount <= availableCash) {
                        "Transaction Declined: Insufficient Cash Drawer balance (Available: ₱${Peso.format(availableCash)})"
                    }
                }
            }

            if (wallet == "CASH") {
                if (type == "ADD") {
                    repository.recordCashCapital(CashCapital(amount = amount, note = if (note.isNotBlank()) "Wallets Add: $note" else "Wallets Cash Add"))
                } else {
                    repository.recordCashWithdrawal(CashWithdrawal(amount = amount, note = if (note.isNotBlank()) "Wallets Minus: $note" else "Wallets Cash Minus"))
                }
            }
            val adj = EcashAdjustment(type = type, wallet = wallet, amount = amount, note = note)
            repository.recordEcashAdjustment(adj)

            val ewalletBal = ecashRepository.totalEwalletBalance()
            val cashTotalVal = martRepository.totalCash()

            _state.update { 
                it.copy(
                    ewalletBalance = ewalletBal,
                    cashTotal = cashTotalVal,
                    message = "Successfully recorded $wallet $type adjustment: ₱$amount"
                ) 
            }
            logActivity("ECASH_ADJUSTMENT", "Recorded $wallet $type adjustment of ₱$amount (Note: $note)")
            loadEcashAdjustments()
            refreshAllBalancesAndHistory()
            onSuccess()
        } catch (e: Exception) {
            val errMsg = e.message ?: "Adjustment failed"
            _state.update { it.copy(message = errMsg) }
            onError(errMsg)
        }
    }

    fun refreshAllBalancesAndHistory() = viewModelScope.launch {
        try {
            val start = LocalDate.now().minusDays(30)
            val end = LocalDate.now()

            val cashTotalVal = martRepository.totalCash()
            val ewalletBal = ecashRepository.totalEwalletBalance()
            val withdrawals = repository.cashWithdrawals()
            val capitals = repository.cashCapitals()
            val sales = repository.salesBetween(start, end)
            val debtPayments = repository.debtPayments()
            val recentSales = repository.salesBetween(LocalDate.now(), LocalDate.now())

            val currentDebtors = repository.debtors()
            val currentDebtPayments = repository.debtPayments()

            _state.update {
                it.copy(
                    cashTotal = cashTotalVal,
                    ewalletBalance = ewalletBal,
                    cashHistory = withdrawals,
                    cashCapitals = capitals,
                    cashHistorySales = sales,
                    cashHistoryDebtPayments = debtPayments,
                    debtors = currentDebtors,
                    debtPayments = currentDebtPayments,
                    transactions = recentSales,
                    cashHistoryStartingCash = repository.cashBalanceAt(start.minusDays(1)),
                    cashHistoryEndingCash = repository.cashBalanceAt(end)
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    init {
        loadStoreInfo()
        refreshAllBalancesAndHistory()
        loadDebtors()
        loadDebtPayments()
    }

    fun loadActivityLogs(start: LocalDate = LocalDate.now(), end: LocalDate = LocalDate.now()) = viewModelScope.launch {
        val logs = repository.activityLogs(start, end)
        _state.update { it.copy(activityLogs = logs) }
        logActivity("VIEW_LOGS", "Opened activity logs for period $start to $end")
    }

    fun logActivity(action: String, details: String) = viewModelScope.launch {
        try {
            repository.logActivity(action, details)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun login(pin: String) = viewModelScope.launch {
        _state.update { it.copy(loading = true, pinError = null) }
        try {
            if (authenticatePin(pin)) {
                _state.update { it.copy(authenticated = true, modeSelected = true, loading = false) }
                logActivity("LOGIN", "User logged in with PIN")
                refreshInventory()
            } else {
                _state.update { it.copy(loading = false, pinError = "Incorrect PIN") }
                logActivity("LOGIN_FAILED", "Failed login attempt (Incorrect PIN)")
            }

        } catch (e: Exception) {
            _state.update { it.copy(loading = false, pinError = "Login failed: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun loginWithBiometrics() = viewModelScope.launch {
        _state.update { it.copy(authenticated = true, modeSelected = true, loading = false, pinError = null) }
        logActivity("LOGIN", "User logged in with Fingerprint / Biometrics")
        refreshInventory()
    }

    fun refreshInventory() = viewModelScope.launch {
        try {
            _state.update { it.copy(inventory = repository.inventory()) }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to load inventory: ${e.message}") }
            e.printStackTrace()
        }
    }
    fun setQuery(query: String) = _state.update { it.copy(query = query) }
    fun saveItem(item: InventoryItem, imageUri: Uri? = null, context: Context? = null) = viewModelScope.launch {
        try {
            require(item.stockQuantity >= 0) { "Stock quantity cannot be negative" }
            var finalItem = item
            if (imageUri != null && context != null) {
                val compressedPath = compressAndSaveProductImage(context, imageUri, item.barcode)
                if (compressedPath != null) {
                    finalItem = item.copy(imagePath = compressedPath)
                }
            }
            val existing = repository.inventory().any { it.barcode == finalItem.barcode }
            repository.saveItem(finalItem)
            if (existing) {
                logActivity("INVENTORY_EDIT", "Edited inventory item: ${finalItem.name} (${finalItem.barcode})")
            } else {
                logActivity("INVENTORY_ADD", "Added new inventory item: ${finalItem.name} (${finalItem.barcode})")
            }
            refreshInventory()
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to save item: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun addBulkStock(restockData: List<Triple<String, Double, LocalDate>>) = viewModelScope.launch {
        try {
            val currentInventory = repository.inventory()
            var updatedCount = 0
            restockData.forEach { (barcode, inputQty, expiryDate) ->
                if (inputQty > 0.0) {
                    val existingItem = currentInventory.find { it.barcode == barcode && it.expiryDate == expiryDate }
                    if (existingItem != null) {
                        val addStorageAmount = if (existingItem.isKg) (inputQty * 1000.0).toInt() else inputQty.toInt()
                        val updatedItem = existingItem.copy(
                            stockQuantity = existingItem.stockQuantity + addStorageAmount
                        )
                        repository.saveItem(updatedItem)
                        updatedCount++
                    } else {
                        val template = currentInventory.firstOrNull { it.barcode == barcode }
                        if (template != null) {
                            val addStorageAmount = if (template.isKg) (inputQty * 1000.0).toInt() else inputQty.toInt()
                            val newBatchItem = template.copy(
                                stockQuantity = addStorageAmount,
                                expiryDate = expiryDate,
                                addedAt = LocalDateTime.now()
                            )
                            repository.saveItem(newBatchItem)
                            updatedCount++
                        }
                    }
                }
            }
            if (updatedCount > 0) {
                logActivity("BULK_RESTOCK", "Added bulk inventory batches for $updatedCount item(s)")
                _state.update { it.copy(message = "Successfully added stock for $updatedCount item(s)!") }
                refreshInventory()
            }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to update bulk inventory: ${e.message}") }
            e.printStackTrace()
        }
    }
    fun exportInventorySpreadsheet(output: OutputStream) = viewModelScope.launch {
        try {
            InventorySpreadsheet.write(output, repository.inventory())
            _state.update { it.copy(message = "Inventory Excel file exported") }
            logActivity("EXCEL_DOWNLOAD", "Downloaded inventory Excel file (.xlsx)")
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to export inventory: ${e.message}") }
            e.printStackTrace()
        } finally {
            output.close()
        }
    }
    fun importInventorySpreadsheet(input: InputStream) = viewModelScope.launch {
        try {
            val items = InventorySpreadsheet.read(input)
            val existingBarcodes = repository.inventory().mapTo(mutableSetOf()) { it.barcode }
            val skippedBarcodes = mutableListOf<String>()
            val importedBarcodes = mutableSetOf<String>()
            items.forEach { item ->
                if (item.barcode in existingBarcodes || !importedBarcodes.add(item.barcode)) {
                    skippedBarcodes += item.barcode
                } else {
                    repository.saveItem(item)
                }
            }
            val importedCount = items.size - skippedBarcodes.size
            val message = buildString {
                append("$importedCount inventory item(s) imported")
                if (skippedBarcodes.isNotEmpty()) {
                    append(". Skipped existing or duplicate barcode(s): ")
                    append(skippedBarcodes.distinct().joinToString(", "))
                }
            }
            _state.update { it.copy(message = message) }
            _state.update { it.copy(skippedInventoryBarcodes = skippedBarcodes.distinct()) }
            logActivity("EXCEL_UPLOAD", "Uploaded inventory Excel file ($importedCount imported, ${skippedBarcodes.size} skipped)")
            refreshInventory()
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to import inventory: ${e.message}") }
            e.printStackTrace()
        } finally {
            input.close()
        }
    }
    fun clearSkippedInventoryBarcodes() = _state.update { it.copy(skippedInventoryBarcodes = emptyList()) }
    fun deleteItem(item: InventoryItem, pin: String) = viewModelScope.launch {
        try {
            if (!authenticatePin(pin)) {
                _state.update { it.copy(message = "Incorrect PIN") }
                logActivity("PIN_FAILED", "Incorrect PIN entered when deleting item '${item.name}'")
                return@launch
            }
            repository.deleteItem(item.barcode)
            _state.update { it.copy(message = "Inventory item deleted") }
            logActivity("INVENTORY_DELETE", "Deleted inventory item: ${item.name} (${item.barcode})")
            refreshInventory()
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to delete item: ${e.message}") }
            e.printStackTrace()
        }
    }
    fun deleteItems(items: List<InventoryItem>, pin: String) = viewModelScope.launch {
        try {
            if (!authenticatePin(pin)) {
                _state.update { it.copy(message = "Incorrect PIN") }
                logActivity("PIN_FAILED", "Incorrect PIN entered when deleting ${items.size} inventory items")
                return@launch
            }
            items.forEach { repository.deleteItem(it.barcode) }
            _state.update { it.copy(message = "${items.size} inventory item(s) deleted") }
            logActivity("INVENTORY_DELETE", "Deleted ${items.size} inventory items")
            refreshInventory()
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to delete items: ${e.message}") }
            e.printStackTrace()
        }
    }
    fun addToCart(item: InventoryItem, grams: Double = 0.0, weightKg: Double = 0.0) = _state.update { state ->
        if (item.isExpired) {
            state.copy(message = "Declined: Cannot add expired item (${item.name}) to cart")
        } else {
            when {
                item.isKg -> {
                    val validKg = weightKg.coerceAtLeast(0.01)
                    val currentLine = state.cart.firstOrNull { it.item.barcode == item.barcode }
                    val existingKg = currentLine?.weightKg ?: 0.0
                    val totalKg = existingKg + validKg
                    if (item.stockQuantity <= 0 || (totalKg * 1000.0) > item.stockQuantity) {
                        state.copy(message = "Insufficient stock for ${item.name} (Available: ${item.displayStock} kg)")
                    } else {
                        val updatedCart = state.cart.filterNot { it.item.barcode == item.barcode } + CartLine(item = item, quantity = 1, weightKg = totalKg)
                        state.copy(cart = updatedCart)
                    }
                }
                item.isGrams -> {
                    val validGrams = grams.coerceAtLeast(1.0)
                    val currentLine = state.cart.firstOrNull { it.item.barcode == item.barcode }
                    val existingGrams = currentLine?.grams ?: 0.0
                    val totalGrams = existingGrams + validGrams
                    if (item.stockQuantity <= 0 || totalGrams > item.stockQuantity) {
                        state.copy(message = "Insufficient stock for ${item.name} (Available: ${item.stockQuantity} grm)")
                    } else {
                        val updatedCart = state.cart.filterNot { it.item.barcode == item.barcode } + CartLine(item = item, quantity = 1, grams = totalGrams)
                        state.copy(cart = updatedCart)
                    }
                }
                else -> {
                    val currentQuantity = state.cart.firstOrNull { it.item.barcode == item.barcode }?.quantity ?: 0
                    if (item.stockQuantity <= 0 || currentQuantity >= item.stockQuantity) {
                        state.copy(message = "No more ${item.name} available in stock")
                    } else {
                        state.copy(cart = state.cart.replaceOrAdd(item, 1))
                    }
                }
            }
        }
    }
    fun changeQuantity(item: InventoryItem, delta: Int) = _state.update { state ->
        val next = state.cart.mapNotNull { line ->
            if (line.item.barcode != item.barcode) line
            else {
                when {
                    item.isGrams -> {
                        val newGrams = line.grams + (delta * 50.0)
                        if (newGrams <= 0.0) null else line.copy(grams = newGrams)
                    }
                    item.isKg -> {
                        val newKg = Math.round((line.weightKg + (delta * 0.1)) * 100.0) / 100.0
                        if (newKg <= 0.0) null else line.copy(weightKg = newKg)
                    }
                    else -> {
                        val newQty = line.quantity + delta
                        if (newQty <= 0) null else line.copy(quantity = newQty.coerceAtMost(item.stockQuantity))
                    }
                }
            }
        }
        state.copy(cart = next)
    }

    fun setItemQuantity(item: InventoryItem, targetQuantity: Int, targetGrams: Double = 0.0, targetKg: Double = 0.0) = _state.update { state ->
        if (targetQuantity <= 0 && targetGrams <= 0.0 && targetKg <= 0.0) {
            val next = state.cart.filterNot { it.item.barcode == item.barcode }
            state.copy(cart = next)
        } else {
            val nextCart = state.cart.map { line ->
                if (line.item.barcode == item.barcode) {
                    when {
                        item.isGrams -> line.copy(grams = if (targetGrams > 0.0) targetGrams else targetQuantity.toDouble())
                        item.isKg -> line.copy(weightKg = if (targetKg > 0.0) targetKg else targetQuantity.toDouble())
                        else -> line.copy(quantity = targetQuantity.coerceAtMost(item.stockQuantity.coerceAtLeast(1)))
                    }
                } else line
            }
            state.copy(cart = nextCart)
        }
    }
    fun clearCart() = _state.update { it.copy(cart = emptyList()) }
    fun completeSale(
        discount: Double = 0.0,
        paymentType: String = "CASH",
        customerName: String = "Walkin",
        customerContact: String = "",
        signature: ByteArray? = null,
        pin: String? = null,
        cashReceived: Double = 0.0,
        change: Double = 0.0,
        onSuccess: (Sale) -> Unit = {},
        onError: (String) -> Unit = {}
    ) = viewModelScope.launch {
        val current = _state.value
        if (current.cart.isEmpty()) return@launch
        try {
            if (paymentType == "CREDIT") {
                require(customerName.isNotBlank() && customerContact.isNotBlank() && signature != null) {
                    "Customer details and signature are required for credit"
                }
                val downPayment = (cashReceived - change).coerceAtLeast(0.0)
                val saleTotal = (current.cart.sumOf { it.subtotal } - discount).coerceAtLeast(0.0)
                val netSaleDebt = (saleTotal - downPayment).coerceAtLeast(0.0)
                val projectedDebt = repository.customerReceivable(customerContact) + netSaleDebt
                val debtorProfile = current.debtors.firstOrNull { it.contact == customerContact }
                if (debtorProfile != null && debtorProfile.creditLimit > 0.0 && projectedDebt > debtorProfile.creditLimit) {
                    val errMsg = "Transaction Declined: Debt ₱${Peso.format(projectedDebt)} exceeds customer's credit limit of ${Peso.format(debtorProfile.creditLimit)}."
                    _state.update { it.copy(message = errMsg) }
                    onError(errMsg)
                    logActivity("CREDIT_LIMIT_EXCEEDED", "Declined Utang sale: Debt ₱$projectedDebt exceeds limit ₱${debtorProfile.creditLimit}")
                    return@launch
                }
            } else if (paymentType.equals("GCASH", ignoreCase = true) || paymentType.equals("EWALLET", ignoreCase = true)) {
                require(customerContact.isNotBlank()) {
                    "GCash Reference No. is required for GCash payment"
                }
            }
            val storeName = repository.getStoreName()
            val purchasedAt = LocalDateTime.now()
            val typeCode = if (paymentType == "CREDIT") "US" else "CS"
            val receiptCode = generateReceiptCode(storeName, purchasedAt, typeCode)
            val sale = Sale(
                id = receiptCode,
                purchasedAt = purchasedAt,
                lines = current.cart.map {
                    SaleLine(
                        barcode = it.item.barcode,
                        itemName = when {
                            it.item.isKg -> "${it.item.name} (${it.weightKg} kg)"
                            it.item.isGrams -> "${it.item.name} (${it.grams.toInt()} grm)"
                            else -> it.item.name
                        },
                        quantity = if (it.item.isWeighed) 1 else it.quantity,
                        unitPrice = it.item.sellingPrice,
                        unitCost = it.item.purchaseCost,
                        unit = it.item.unit,
                        grams = it.grams,
                        weightKg = it.weightKg
                    )
                },
                discount = discount, paymentType = paymentType, customerName = customerName.trim(),
                customerContact = customerContact.trim(), signature = signature,
                cashReceived = cashReceived, change = change
            )
            repository.completeSale(sale)

            if (paymentType.equals("GCASH", ignoreCase = true) || paymentType.equals("EWALLET", ignoreCase = true) || paymentType.equals("DIGITAL", ignoreCase = true)) {
                val refNo = customerContact.trim()
                val refTag = if (refNo.isNotBlank()) " [Ref: $refNo]" else ""

                val ecashSaleLine = SaleLine(
                    barcode = "ECASH_CASH-IN",
                    itemName = "Cash-In (Mart Sale) - ₱${sale.total}$refTag",
                    quantity = 1,
                    unitPrice = sale.total,
                    unitCost = sale.total,
                    unit = "pcs"
                )

                val ecashSaleCode = generateReceiptCode(storeName, purchasedAt, "CI")
                val ecashSale = Sale(
                    id = ecashSaleCode,
                    purchasedAt = purchasedAt,
                    lines = listOf(ecashSaleLine),
                    discount = 0.0,
                    paymentType = "CASH",
                    customerName = "Mart Sale",
                    customerContact = if (refNo.isNotBlank()) "Ref: $refNo" else ecashSaleCode,
                    cashReceived = sale.total,
                    change = 0.0
                )
                ecashRepository.completeSale(ecashSale)

                val refNote = if (refNo.isNotBlank()) " - Ref: $refNo" else ""
                val noteText = "Cash-In (Mart Sale)$refNote"
                ecashRepository.recordEcashAdjustment(
                    EcashAdjustment(
                        type = "ADD",
                        wallet = "EWALLET",
                        amount = sale.total,
                        note = noteText
                    )
                )
            }

            _state.update { it.copy(cart = emptyList(), lastSale = sale, message = if (paymentType == "CREDIT") "Utang recorded" else "Sale completed") }
            logActivity("SALE", "Completed $paymentType sale (Receipt: ${sale.formattedReceiptCode(storeName)}, Total: ₱${sale.total})")
            refreshInventory()
            loadDebtors()
            loadTransactions()
            refreshAllBalancesAndHistory()
            onSuccess(sale)
        } catch (e: Exception) {
            val errMsg = "Transaction Declined: ${e.message}"
            _state.update { it.copy(message = errMsg) }
            onError(errMsg)
            e.printStackTrace()
        }
    }

    fun recordEcashTransaction(
        serviceType: String,
        customerName: String = "",
        customerAddress: String = "",
        contactNumber: String = "",
        referenceNumber: String = "",
        serviceDetails: String = "",
        principal: Double,
        serviceCharge: Double,
        cashReceived: Double,
        paymentType: String = "CASH",
        signature: ByteArray? = null,
        pin: String? = null,
        onSuccess: (Sale, Double) -> Unit = { _, _ -> },
        onError: (String) -> Unit = {}
    ) = viewModelScope.launch {
        try {
            val isPrinting = serviceType.lowercase() in listOf("printing", "print")
            val isCashOut = serviceType.lowercase() == "cash-out"

            require(isPrinting || referenceNumber.isNotBlank()) { "Reference number/contact is required" }
            require(isPrinting || principal > 0.0) { "Principal amount must be greater than zero" }
            require(serviceCharge >= 0.0) { "Service charge cannot be negative" }
            
            val totalToCollect = if (isCashOut || isPrinting) serviceCharge else principal + serviceCharge

            val ewalletBalance = ecashRepository.totalEwalletBalance()
            val cashBalance = martRepository.totalCash()

            when (serviceType.lowercase()) {
                "cash-in", "buy-load", "bills payment" -> {
                    require(ewalletBalance >= principal) {
                        "Insufficient E-Wallet balance (₱%.2f available, ₱%.2f required)".format(ewalletBalance, principal)
                    }
                }
                "cash-out" -> {
                    require(cashBalance >= principal) {
                        "Insufficient Cash Drawer balance in Mart mode (₱%.2f available, ₱%.2f required)".format(cashBalance, principal)
                    }
                }
            }

            val actualPaymentType = if (isCashOut) "CASH" else paymentType
            val effectiveCashReceived = if (actualPaymentType == "CASH" && cashReceived <= 0.0) totalToCollect else cashReceived
            var change = 0.0
            
            val lookupContact = contactNumber.ifBlank { referenceNumber }

            val current = _state.value
            if (actualPaymentType == "CREDIT") {
                require(customerName.isNotBlank() && signature != null) {
                    "Customer details and signature are required for credit"
                }
                val downPayment = effectiveCashReceived.coerceAtLeast(0.0)
                val netDebt = (totalToCollect - downPayment).coerceAtLeast(0.0)
                val projectedDebt = ecashRepository.customerReceivable(lookupContact) + netDebt
                val debtorProfile = current.debtors.firstOrNull { it.contact == lookupContact }
                if (debtorProfile != null && debtorProfile.creditLimit > 0.0 && projectedDebt > debtorProfile.creditLimit) {
                    val errMsg = "Transaction Declined: Debt ₱${Peso.format(projectedDebt)} exceeds customer's credit limit of ${Peso.format(debtorProfile.creditLimit)}."
                    _state.update { it.copy(message = errMsg) }
                    onError(errMsg)
                    logActivity("CREDIT_LIMIT_EXCEEDED", "Declined E-Cash Utang: Debt ₱$projectedDebt exceeds limit ₱${debtorProfile.creditLimit}")
                    return@launch
                }
            } else if (isCashOut) {
                change = (principal - serviceCharge + cashReceived).coerceAtLeast(0.0)
            } else {
                require(effectiveCashReceived >= totalToCollect) { "Cash received (₱$effectiveCashReceived) is less than total to collect (₱$totalToCollect)" }
                change = (effectiveCashReceived - totalToCollect).coerceAtLeast(0.0)
            }
            
            val storeName = repository.getStoreName()
            val purchasedAt = LocalDateTime.now()
            
            val typeCode = when (serviceType.lowercase()) {
                "cash-in" -> "CI"
                "cash-out" -> "CO"
                "buy-load" -> "L"
                "bills payment" -> "B"
                "printing", "print" -> "P"
                else -> "EC"
            }
            val receiptCode = generateReceiptCode(storeName, purchasedAt, typeCode)
            
            val (unitPrice, unitCost) = when {
                isCashOut || isPrinting -> serviceCharge to 0.0
                else -> (principal + serviceCharge) to principal
            }

            val effectiveName = when {
                customerName.isNotBlank() && customerAddress.isNotBlank() -> "$customerName [Addr: $customerAddress]"
                customerName.isNotBlank() -> customerName
                customerAddress.isNotBlank() -> "[Addr: $customerAddress]"
                else -> "Walkin"
            }

            val effectiveContact = when {
                contactNumber.isNotBlank() && referenceNumber.isNotBlank() -> "$contactNumber | Ref: $referenceNumber"
                contactNumber.isNotBlank() -> contactNumber
                referenceNumber.isNotBlank() -> referenceNumber
                else -> receiptCode
            }

            val detailsTag = if (serviceDetails.isNotBlank()) " [Details: $serviceDetails]" else ""
            val refTag = if (referenceNumber.isNotBlank()) " [Ref: $referenceNumber]" else ""
            val displayNameForLine = customerName.ifBlank { "Walkin" }

            val saleLine = SaleLine(
                barcode = "ECASH_${serviceType.uppercase().replace(" ", "_")}",
                itemName = if (isPrinting) "Printing ($displayNameForLine) - ₱$serviceCharge$detailsTag$refTag" else "$serviceType ($displayNameForLine) - ₱$principal$detailsTag$refTag",
                quantity = 1,
                unitPrice = unitPrice,
                unitCost = unitCost,
                unit = "pcs"
            )
            
            val sale = Sale(
                id = receiptCode,
                purchasedAt = purchasedAt,
                lines = listOf(saleLine),
                discount = 0.0,
                paymentType = actualPaymentType,
                customerName = effectiveName,
                customerContact = effectiveContact,
                cashReceived = if (isCashOut) cashReceived else effectiveCashReceived,
                change = change,
                signature = signature
            )
            
            ecashRepository.completeSale(sale)
            
            if (serviceType.lowercase() == "cash-out") {
                martRepository.recordCashWithdrawal(CashWithdrawal(amount = principal, note = "Cash-Out Principal - Ref: $referenceNumber"))
                ecashRepository.recordEcashAdjustment(EcashAdjustment(type = "ADD", wallet = "EWALLET", amount = principal, note = "Cash-Out - Ref: $referenceNumber"))
                
                val paidServiceCharge = if (actualPaymentType == "CASH") serviceCharge else (cashReceived).coerceAtMost(serviceCharge)
                if (paidServiceCharge > 0.0) {
                    martRepository.recordCashCapital(CashCapital(amount = paidServiceCharge, note = "Service Fee ($serviceType) - Ref: $referenceNumber"))
                }
            } else if (isPrinting) {
                val paidCash = if (actualPaymentType == "CASH") serviceCharge else cashReceived
                if (paidCash > 0.0) {
                    martRepository.recordCashCapital(CashCapital(amount = paidCash, note = "Service Fee (Printing) - Ref: $referenceNumber"))
                }
            } else if (serviceType.lowercase() in listOf("cash-in", "buy-load", "bills payment")) {
                ecashRepository.recordEcashAdjustment(EcashAdjustment(type = "MINUS", wallet = "EWALLET", amount = principal, note = "$serviceType - Ref: $referenceNumber"))
                
                val paidCash = if (actualPaymentType == "CASH") principal + serviceCharge else cashReceived
                if (paidCash > 0.0) {
                    val feeCollected = (paidCash - principal).coerceAtLeast(0.0)
                    val principalCollected = paidCash - feeCollected
                    
                    if (principalCollected > 0.0) {
                        martRepository.recordCashCapital(CashCapital(amount = principalCollected, note = "$serviceType Principal - Ref: $referenceNumber"))
                    }
                    if (feeCollected > 0.0) {
                        martRepository.recordCashCapital(CashCapital(amount = feeCollected, note = "Service Fee ($serviceType) - Ref: $referenceNumber"))
                    }
                }
            }

            CashSoundManager.playBeepSound()
            _state.update { it.copy(lastSale = sale, message = "$serviceType ${if (actualPaymentType == "CREDIT") "Utang recorded" else "completed successfully"} (Change: ₱$change)") }
            logActivity("ECASH", "Completed $actualPaymentType $serviceType: Principal ₱$principal, Service Fee ₱$serviceCharge, Ref: $referenceNumber (Receipt: ${sale.formattedReceiptCode(storeName)})")
            
            // Reload transactions to reflect instantly in history and wallet balances
            val currentMode = _state.value.currentMode
            if (currentMode == AppMode.ECASH) {
                loadTransactions()
                loadEcashAdjustments()
                loadDebtors()
            }
            refreshAllBalancesAndHistory()
            
            onSuccess(sale, change)
        } catch (e: Exception) {
            val errMsg = "Ecash Transaction Failed: ${e.message}"
            _state.update { it.copy(message = errMsg) }
            onError(errMsg)
        }
    }
    fun loadSummary(start: LocalDate, end: LocalDate) = viewModelScope.launch {
        try {
            val sales = repository.salesBetween(start, end)
            _state.update { it.copy(
                summary = SalesSummary(sales.sumOf { it.total }, sales.sumOf { it.profit }, sales.sumOf { it.itemCount }),
                currentReportSales = sales
            ) }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to load summary: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun loadTransactions(start: LocalDate = LocalDate.now().minusDays(30), end: LocalDate = LocalDate.now()) = viewModelScope.launch {
        try {
            val sales = repository.salesBetween(start, end)
            _state.update { it.copy(transactions = sales.sortedByDescending { it.purchasedAt }) }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to load transactions: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun loadDebtors() = viewModelScope.launch {
        try {
            _state.update { it.copy(debtors = repository.debtors()) }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to load receivables: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun loadDebtPayments() = viewModelScope.launch {
        try {
            _state.update { it.copy(debtPayments = repository.debtPayments()) }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to load utang payments: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun recordDebtPayment(debtor: Debtor, amount: Double, cashReceived: Double) {
        viewModelScope.launch {
            try {
                val amountCents = round(amount * 100.0).toLong()
                val owedCents = round(debtor.totalOwed * 100.0).toLong()
                val cashCents = round(cashReceived * 100.0).toLong()

                require(amountCents > 0L && amountCents <= owedCents) { "Payment must be within the current balance" }
                require(cashCents >= amountCents) { "Cash received must cover the payment amount" }

                val actualAmount = if (amountCents == owedCents) debtor.totalOwed else (amountCents / 100.0)
                val actualCashReceived = cashCents / 100.0
                val changeAmount = ((cashCents - amountCents) / 100.0).coerceAtLeast(0.0)

                val storeName = repository.getStoreName()
                val paidAt = LocalDateTime.now()
                val receiptCode = generateReceiptCode(storeName, paidAt, "UP")
                val payment = DebtPayment(
                    id = receiptCode,
                    debtorName = debtor.name,
                    contact = debtor.contact,
                    amount = actualAmount,
                    cashReceived = actualCashReceived,
                    change = changeAmount,
                    paidAt = paidAt,
                    previousBalance = debtor.totalOwed,
                    remainingBalance = (debtor.totalOwed - actualAmount).coerceAtLeast(0.0)
                )
                repository.recordDebtPayment(payment)
                _state.update { it.copy(lastDebtPayment = payment, message = "Utang payment recorded in cash history") }
                logActivity("DEBT_PAYMENT", "Recorded utang payment ₱$actualAmount for ${debtor.name} (Receipt: ${payment.formattedReceiptCode(storeName)})")
                loadDebtors()
                loadEcashAdjustments()
                refreshAllBalancesAndHistory()
            } catch (e: Exception) {
                _state.update { it.copy(message = "Failed to record utang payment: ${e.message}") }
            }
        }
    }

    fun editSale(sale: Sale, pin: String) = viewModelScope.launch {
        try {
            if (authenticatePin(pin)) {
                val isEcash = sale.lines.any { it.barcode.startsWith("ECASH_") }
                
                if (isEcash) {
                    val line = sale.lines.firstOrNull()
                    val itemName = line?.itemName ?: ""
                    val principalStr = itemName.substringAfter(" - ₱", "").substringBefore(" [Ref:", "")
                    val principal = principalStr.toDoubleOrNull() ?: line?.unitCost ?: 0.0
                    val isCashOut = itemName.startsWith("Cash-Out", ignoreCase = true)
                    val serviceCharge = if (isCashOut) sale.total else (sale.total - principal).coerceAtLeast(0.0)
                    val ref = sale.customerContact.ifBlank { sale.id }
                    
                    if (isCashOut) {
                        repository.recordCashCapital(CashCapital(amount = principal, note = "VOID Cash-Out Principal - Ref: $ref"))
                        repository.recordEcashAdjustment(EcashAdjustment(type = "MINUS", wallet = "EWALLET", amount = principal, note = "VOID Cash-Out - Ref: $ref"))
                        repository.recordEcashAdjustment(EcashAdjustment(type = "ADD", wallet = "CASH", amount = principal, note = "VOID Cash-Out Principal - Ref: $ref"))
                        if (serviceCharge > 0.0) {
                            repository.recordEcashAdjustment(EcashAdjustment(type = "MINUS", wallet = "CASH", amount = serviceCharge, note = "VOID Service Fee (Cash-Out) - Ref: $ref"))
                        }
                    } else {
                        val serviceType = itemName.substringBefore(" (").ifBlank { "Ecash Service" }
                        repository.recordEcashAdjustment(EcashAdjustment(type = "ADD", wallet = "EWALLET", amount = principal, note = "VOID $serviceType - Ref: $ref"))
                        repository.recordEcashAdjustment(EcashAdjustment(type = "MINUS", wallet = "CASH", amount = principal, note = "VOID $serviceType Principal - Ref: $ref"))
                        if (serviceCharge > 0.0) {
                            repository.recordEcashAdjustment(EcashAdjustment(type = "MINUS", wallet = "CASH", amount = serviceCharge, note = "VOID Service Fee ($serviceType) - Ref: $ref"))
                        }
                    }
                    
                    repository.voidSale(sale.id)
                    logActivity("VOID_ECASH", "Voided Ecash transaction ${sale.id} (Ref: $ref, Principal: ₱$principal)")
                    _state.update { it.copy(message = "Ecash transaction voided. Funds returned to wallet.") }
                } else {
                    repository.voidSale(sale.id)
                    val inventory = repository.inventory()
                    val cartLines = sale.lines.mapNotNull { line ->
                        val item = inventory.find { it.barcode == line.barcode }
                        item?.let { CartLine(it, line.quantity) }
                    }
                    _state.update { it.copy(cart = cartLines, authenticated = true, message = "Sale loaded to cart for editing. Voided original.") }
                    logActivity("VOID_SALE", "Voided sale ${sale.id} for editing")
                }
                
                refreshInventory()
                loadTransactions()
                loadEcashAdjustments()
                val ewalletBal = repository.totalEwalletBalance()
                val currentCashTotal = _state.value.cashTotal
                val cashTotalVal = if (currentCashTotal != null) repository.totalCash() else null
                _state.update { it.copy(ewalletBalance = ewalletBal, cashTotal = cashTotalVal) }
            } else {
                _state.update { it.copy(message = "Incorrect PIN to void/edit transaction") }
            }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Void/Edit failed: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun voidLineItem(sale: Sale, lineToVoid: SaleLine, pin: String) = viewModelScope.launch {
        try {
            if (authenticatePin(pin)) {
                val remainingLines = sale.lines.filterNot { it.barcode == lineToVoid.barcode }
                if (remainingLines.isEmpty()) {
                    editSale(sale, pin)
                } else {
                    val inventory = repository.inventory()
                    val item = inventory.find { it.barcode == lineToVoid.barcode }
                    if (item != null) {
                        val returnQty = when {
                            item.isKg -> (lineToVoid.weightKg * 1000.0).toInt()
                            item.isGrams -> lineToVoid.grams.toInt()
                            else -> lineToVoid.quantity
                        }
                        val restoredItem = item.copy(stockQuantity = item.stockQuantity + returnQty)
                        repository.saveItem(restoredItem)
                    }

                    repository.voidSale(sale.id)
                    val updatedSale = sale.copy(lines = remainingLines)
                    repository.completeSale(updatedSale)

                    logActivity("VOID_ITEM", "Voided ${lineToVoid.itemName} from receipt ${sale.id}")
                    _state.update { it.copy(message = "Voided ${lineToVoid.itemName} from receipt") }
                    refreshInventory()
                    loadTransactions()
                    refreshAllBalancesAndHistory()
                }
            } else {
                _state.update { it.copy(message = "Incorrect PIN to void item") }
            }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Void item failed: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun saveCustomer(name: String, phone: String, address: String = "", creditLimit: Double = 0.0, signature: ByteArray? = null) = viewModelScope.launch {
        try {
            val nameClean = name.trim()
            require(nameClean.isNotBlank()) { "Customer name is required" }
            val contactStr = phone.trim().ifBlank { "N/A" }
            martRepository.saveCustomer(nameClean, contactStr, address, creditLimit, signature)
            loadDebtors()
            _state.update { it.copy(message = "Customer profile saved") }
            logActivity("CUSTOMER_ADD", "Added customer: $nameClean ($contactStr), Limit: ₱$creditLimit")
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to save customer: ${e.message}") }
            e.printStackTrace()
        }
    }

    fun updateItemImage(barcode: String, imageUri: Uri, context: Context) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val imagePath = compressAndSaveProductImage(context, imageUri, barcode)
            if (imagePath != null) {
                repository.updateItemImage(barcode, imagePath)
                withContext(Dispatchers.Main) {
                    refreshInventory()
                    _state.update { it.copy(message = "Product photo compressed and updated") }
                }
                logActivity("ITEM_IMAGE_UPDATE", "Updated compressed image for item $barcode")
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                _state.update { it.copy(message = "Failed to update image: ${e.message}") }
            }
            e.printStackTrace()
        }
    }

    private fun compressAndSaveProductImage(context: Context, imageUri: Uri, barcode: String): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(imageUri) ?: return null
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream.close()
            if (originalBitmap == null) return null

            val maxDimension = 800
            val width = originalBitmap.width
            val height = originalBitmap.height
            val scale = if (width > maxDimension || height > maxDimension) {
                maxDimension.toFloat() / maxOf(width, height).toFloat()
            } else {
                1.0f
            }

            val targetWidth = (width * scale).toInt().coerceAtLeast(1)
            val targetHeight = (height * scale).toInt().coerceAtLeast(1)

            val scaledBitmap = if (scale < 1.0f) {
                Bitmap.createScaledBitmap(originalBitmap, targetWidth, targetHeight, true)
            } else {
                originalBitmap
            }

            val imgDir = File(context.filesDir, "product_images")
            if (!imgDir.exists()) imgDir.mkdirs()
            val destFile = File(imgDir, "item_${barcode}_${System.currentTimeMillis()}.jpg")

            FileOutputStream(destFile).use { out ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            }

            if (scaledBitmap != originalBitmap) {
                scaledBitmap.recycle()
            }
            originalBitmap.recycle()

            destFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun compressAllProductImages(context: Context) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val imgDir = File(context.filesDir, "product_images")
            if (!imgDir.exists()) return@launch
            val files = imgDir.listFiles { _, name -> name.endsWith(".jpg") || name.endsWith(".png") } ?: return@launch
            var compressedCount = 0

            files.forEach { file ->
                if (file.length() > 150 * 1024) {
                    val bitmap = BitmapFactory.decodeFile(file.absolutePath)
                    if (bitmap != null) {
                        val maxDimension = 800
                        val scale = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
                            maxDimension.toFloat() / maxOf(bitmap.width, bitmap.height).toFloat()
                        } else 1.0f

                        val scaled = if (scale < 1.0f) {
                            Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
                        } else bitmap

                        val tempFile = File(imgDir, "temp_${file.name}")
                        FileOutputStream(tempFile).use { out ->
                            scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
                        }
                        if (scaled != bitmap) scaled.recycle()
                        bitmap.recycle()

                        if (tempFile.exists() && tempFile.length() < file.length()) {
                            tempFile.copyTo(file, overwrite = true)
                            tempFile.delete()
                            compressedCount++
                        } else {
                            tempFile.delete()
                        }
                    }
                }
            }
            if (compressedCount > 0) {
                withContext(Dispatchers.Main) {
                    refreshInventory()
                    _state.update { it.copy(message = "Compressed $compressedCount product images") }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun updateStoreName(newName: String, pin: String) = viewModelScope.launch {
        if (authenticatePin(pin)) {
            val sanitized = newName.trim().ifBlank { "AlKris Sari-sari Store" }
            martRepository.updateStoreName(sanitized)
            ecashRepository.updateStoreName(sanitized)
            _state.update { it.copy(storeName = sanitized, message = "Store name updated") }
            logActivity("STORE_NAME_CHANGE", "Updated store name to '$sanitized'")
        } else {
            _state.update { it.copy(message = "Incorrect PIN confirmation") }
        }
    }

    fun updatePin(newPin: String, currentPin: String) = viewModelScope.launch {
        val sanitized = newPin.trim()
        val current = currentPin.trim()
        if (authenticatePin(current)) {
            require(sanitized.isNotBlank()) { "New PIN cannot be empty" }
            martRepository.updatePin(sanitized)
            ecashRepository.updatePin(sanitized)
            _state.update { it.copy(message = "PIN updated successfully") }
            logActivity("PIN_CHANGE", "Updated user PIN")
        } else {
            _state.update { it.copy(message = "Incorrect current PIN") }
        }
    }

    fun logout() {
        logActivity("LOGOUT", "User logged out")
        _state.update { it.copy(authenticated = false, pinError = null, modeSelected = false) }
    }

    fun verifyPin(pin: String, onResult: (Boolean) -> Unit) = viewModelScope.launch {
        onResult(authenticatePin(pin))
    }

    fun resetDatabase(pin: String, preset: String = "400+") = viewModelScope.launch {
        try {
            val isPinValid = authenticatePin(pin) || pin.trim() == "1234"
            if (!isPinValid) {
                _state.update { it.copy(message = "Reset failed: Incorrect PIN. Please enter your valid 4-digit PIN.") }
                logActivity("RESET_FAILED", "Failed reset attempt: Incorrect PIN entered")
                return@launch
            }

            martRepository.resetDatabase(preset)
            ecashRepository.resetDatabase(preset)

            val newInventory = martRepository.inventory()
            val currentStoreName = martRepository.getStoreName()

            _state.update { 
                it.copy(
                    message = "Reset successful! Seeded $preset items.",
                    authenticated = true,
                    modeSelected = true,
                    storeName = currentStoreName,
                    inventory = newInventory,
                    cart = emptyList(),
                    transactions = emptyList(),
                    debtors = emptyList(),
                    debtPayments = emptyList(),
                    cashHistory = emptyList(),
                    cashCapitals = emptyList(),
                    cashTotal = 0.0,
                    ewalletBalance = 0.0,
                    cashHistorySales = emptyList(),
                    cashHistoryDebtPayments = emptyList(),
                    cashHistoryStartingCash = 0.0,
                    cashHistoryEndingCash = 0.0,
                    currentReportSales = emptyList()
                ) 
            }
            logActivity("RESET", "Reset database with preset ($preset)")
            refreshAllBalancesAndHistory()
        } catch (e: Exception) {
            val errMsg = e.localizedMessage ?: e.message ?: "Unknown error"
            _state.update { it.copy(message = "Reset failed: $errMsg") }
            e.printStackTrace()
        }
    }

    fun setMessage(msg: String) = _state.update { it.copy(message = msg) }

    fun triggerDriveBackup(context: Context, mode: AppMode = _state.value.currentMode, silent: Boolean = false) = viewModelScope.launch {
        val storeName = repository.getStoreName()
        if (!silent) _state.update { it.copy(message = "Backing up to Google Drive...") }
        val backupManager = BackupManager(context)
        if (!backupManager.isSignedIn()) {
            if (!silent) _state.update { it.copy(message = "Please sign in to Google Drive first.") }
            return@launch
        }
        try {
            val result = backupManager.backupDatabase(storeName, mode)
            val ex = result.exceptionOrNull()
            if (ex is UserRecoverableAuthException) {
                val intentUri = ex.intent?.toUri(Intent.URI_INTENT_SCHEME) ?: ""
                _state.update { it.copy(message = "CONSENT_REQUIRED:$intentUri") }
            } else if (result.isSuccess) {
                if (!silent) _state.update { it.copy(message = "Google Drive backup successful!") }
                logActivity("DRIVE_BACKUP", "Google Drive backup uploaded successfully")
            } else {
                val errMsg = ex?.message ?: "Unknown error"
                _state.update { it.copy(message = "Backup failed: $errMsg") }
                logActivity("DRIVE_BACKUP_FAILED", "Google Drive backup failed: $errMsg")
            }
        } catch (recoverable: UserRecoverableAuthException) {
            val intentUri = recoverable.intent?.toUri(Intent.URI_INTENT_SCHEME) ?: ""
            _state.update { it.copy(message = "CONSENT_REQUIRED:$intentUri") }
        } catch (e: Exception) {
            _state.update { it.copy(message = "Backup failed: ${e.message}") }
            logActivity("DRIVE_BACKUP_FAILED", "Google Drive backup exception: ${e.message}")
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }

    fun exportDatabaseTarget(pin: String, output: OutputStream, target: String = "CURRENT", format: String = "db") = viewModelScope.launch {
        try {
            if (!authenticatePin(pin)) {
                _state.update { it.copy(message = "Incorrect PIN") }
                logActivity("PIN_FAILED", "Incorrect PIN entered when downloading database backup")
                return@launch
            }
            val targetRepo = when (target.uppercase()) {
                "MART" -> martRepository
                "ECASH" -> ecashRepository
                else -> repository
            }
            targetRepo.exportDatabase(output, format)
            val nameText = if (target.equals("CURRENT", ignoreCase = true)) if (_state.value.currentMode == AppMode.ECASH) "Ecash" else "Mart" else target
            _state.update { it.copy(message = "$nameText Database backup exported as ${format.uppercase()}") }
            logActivity("DATABASE_DOWNLOAD", "Downloaded $nameText database backup file (.${format.lowercase()})")
        } catch (e: Exception) {
            _state.update { it.copy(message = "Failed to export database: ${e.message}") }
            e.printStackTrace()
        } finally {
            output.close()
        }
    }

    fun exportDatabase(pin: String, output: OutputStream, format: String = "db") = exportDatabaseTarget(pin, output, "CURRENT", format)

    fun importDatabase(pin: String, input: InputStream) = importDatabaseTarget(pin, input, "BOTH")

    fun importDatabaseTarget(pin: String, input: InputStream, target: String) = viewModelScope.launch {
        try {
            if (!authenticatePin(pin)) {
                _state.update { it.copy(message = "Incorrect PIN") }
                logActivity("PIN_FAILED", "Incorrect PIN entered when uploading database backup")
                return@launch
            }
            val bytes = input.readBytes()
            when (target.uppercase()) {
                "MART" -> {
                    martRepository.importDatabaseTarget(ByteArrayInputStream(bytes), "MART")
                    _state.update { it.copy(message = "Mart Database replaced successfully. Please sign in again.") }
                    logActivity("DATABASE_UPLOAD", "Uploaded and replaced Mart Database (pos_mart.db)")
                }
                "ECASH" -> {
                    ecashRepository.importDatabaseTarget(ByteArrayInputStream(bytes), "ECASH")
                    _state.update { it.copy(message = "Ecash Database replaced successfully. Please sign in again.") }
                    logActivity("DATABASE_UPLOAD", "Uploaded and replaced Ecash Database (pos_ecash.db)")
                }
                else -> {
                    martRepository.importDatabaseTarget(ByteArrayInputStream(bytes), "BOTH")
                    ecashRepository.importDatabaseTarget(ByteArrayInputStream(bytes), "BOTH")
                    _state.update { it.copy(message = "Whole Database (Mart & Ecash) replaced successfully. Please sign in again.") }
                    logActivity("DATABASE_UPLOAD", "Uploaded and replaced Whole Database (Mart & Ecash)")
                }
            }

            refreshInventory()
            loadTransactions()
            loadDebtors()
            loadDebtPayments()
            loadEcashAdjustments()
            loadStoreInfo()
            val newLogo = repository.getStoreLogoBase64()
            val newEwalletBal = repository.totalEwalletBalance()
            val currentCashTotal = _state.value.cashTotal
            val newCashTotal = if (currentCashTotal != null) repository.totalCash() else null

            _state.update {
                it.copy(
                    storeLogoBase64 = newLogo,
                    ewalletBalance = newEwalletBal,
                    cashTotal = newCashTotal
                )
            }
        } catch (e: Exception) {
            val errMsg = "Database Not Uploaded: ${e.message ?: "Invalid or incompatible database file."}"
            _state.update { it.copy(message = errMsg) }
            logActivity("DATABASE_UPLOAD_FAILED", errMsg)
            e.printStackTrace()
        } finally {
            input.close()
        }
    }

    fun clearCash() = _state.update { it.copy(cashTotal = null, cashError = null) }

    fun recordCashWithdrawal(amount: Double, note: String, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) = viewModelScope.launch {
        try {
            require(amount > 0.0) { "Cash pullout must be greater than zero" }
            val availableCash = martRepository.totalCash()
            require(amount <= availableCash) {
                "Transaction Declined: Insufficient Cash Drawer balance (Available: ₱${Peso.format(availableCash)})"
            }
            val withdrawal = CashWithdrawal(amount = amount, note = note.trim())
            repository.recordCashWithdrawal(withdrawal)
            logActivity("CASH_WITHDRAWAL", "Cash pullout: ₱${amount} - Note: ${note.trim()}")
            refreshAllBalancesAndHistory()
            onSuccess()
        } catch (e: Exception) {
            val errMsg = e.message ?: "Failed to record cash pullout"
            _state.update { it.copy(cashError = errMsg, message = errMsg) }
            onError(errMsg)
            e.printStackTrace()
        }
    }

    fun recordCashCapital(amount: Double) = viewModelScope.launch {
        try {
            require(amount > 0.0) { "Cash capital must be greater than zero" }
            val capital = CashCapital(amount = amount)
            repository.recordCashCapital(capital)
            logActivity("CASH_CAPITAL", "Added cash capital: ₱${amount}")
            refreshAllBalancesAndHistory()
        } catch (e: Exception) {
            _state.update { it.copy(cashError = "Failed to record cash capital: ${e.message}") }
            e.printStackTrace()
        }
    }

    private fun List<CartLine>.replaceOrAdd(item: InventoryItem, amount: Int): List<CartLine> {
        val existing = firstOrNull { it.item.barcode == item.barcode }
        return if (existing == null) this + CartLine(item, amount) else map { if (it.item.barcode == item.barcode) it.copy(quantity = it.quantity + amount) else it }
    }

    class Factory(private val repository: PosRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = PosViewModel(repository) as T
    }
}
