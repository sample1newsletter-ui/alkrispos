package ph.alkris.pos.ui

import ph.alkris.pos.data.*
import ph.alkris.pos.ui.screens.*
import ph.alkris.pos.ui.components.*
import ph.alkris.pos.ui.dialogs.*

import java.time.LocalTime
import ph.alkris.pos.R
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import android.Manifest
import androidx.compose.foundation.BorderStroke
import android.annotation.SuppressLint
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableFloatStateOf
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.DisposableEffect
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.HorizontalDivider
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import android.util.Size
import android.view.MotionEvent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import java.util.concurrent.TimeUnit
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import ph.alkris.pos.data.ActivityLog
import ph.alkris.pos.data.generateDateList
import ph.alkris.pos.data.roundPosPrice
import androidx.compose.material3.FilterChip
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.text.ClickableText
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import com.dantsu.escposprinter.connection.bluetooth.BluetoothPrintersConnections
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarDefaults
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.time.LocalDate
import java.time.LocalDateTime
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.fragment.app.FragmentActivity
import java.time.format.DateTimeFormatter
import java.time.ZoneOffset
import java.util.Locale
import ph.alkris.pos.data.*
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.round

@Composable
fun AspectScaleContainer(
    content: @Composable () -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val configuration = LocalConfiguration.current
        val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val isTablet = configuration.smallestScreenWidthDp >= 600

        val currentDensity = LocalDensity.current
        val screenWidth = this.maxWidth
        val screenHeight = this.maxHeight

        val targetWidth = if (isLandscape) 844.dp else 390.dp
        val targetHeight = if (isLandscape) 390.dp else 844.dp

        val scaleX = if (targetWidth > 0.dp) screenWidth / targetWidth else 1f
        val scaleY = if (targetHeight > 0.dp) screenHeight / targetHeight else 1f

        val baseScale = minOf(scaleX, scaleY, 1f)
        val tabletMultiplier = if (isTablet) 1.15f else 1.0f

        val finalDensity = Density(
            density = currentDensity.density * baseScale * tabletMultiplier,
            fontScale = currentDensity.fontScale * baseScale * tabletMultiplier
        )

        CompositionLocalProvider(LocalDensity provides finalDensity) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                content()
            }
        }
    }
}

private val posLightColorScheme = lightColorScheme(
    primary = Color(0xFF10498E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3EDFB),
    onPrimaryContainer = Color(0xFF10498E),
    secondary = Color(0xFF10498E),
    onSecondary = Color.White,
    background = Color.White,
    onBackground = Color(0xFF1C1B1F),
    surface = Color.White,
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFF0F4F8),
    onSurfaceVariant = Color(0xFF44474E),
    outline = Color(0xFF74777F),
    outlineVariant = Color(0xFFC4C6CF)
)

private val posDarkColorScheme = darkColorScheme(
    primary = Color(0xFF10498E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF10498E),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFF10498E),
    onSecondary = Color.White,
    background = Color(0xFF121316),
    onBackground = Color(0xFFE2E2E6),
    surface = Color(0xFF1E1F24),
    onSurface = Color(0xFFE2E2E6),
    surfaceVariant = Color(0xFF282A30),
    onSurfaceVariant = Color(0xFFC4C6CF),
    outline = Color(0xFF8E9099),
    outlineVariant = Color(0xFF44474E)
)

@Composable
fun PosApp(viewModel: PosViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }
    var themeMode by remember { mutableStateOf(prefs.getString("theme_mode", "System") ?: "System") }

    DisposableEffect(prefs) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
            if (key == "theme_mode") {
                themeMode = p.getString("theme_mode", "System") ?: "System"
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    val systemInDark = isSystemInDarkTheme()
    val isDarkTheme = when (themeMode) {
        "Dark" -> true
        "Light" -> false
        else -> systemInDark
    }

    val colorScheme = if (isDarkTheme) posDarkColorScheme else posLightColorScheme
    val isTablet = LocalContext.current.resources.configuration.smallestScreenWidthDp >= 600

    LaunchedEffect(state.message) {
        state.message?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearMessage()
        }
    }

    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val autoLogoutMins = remember(state.authenticated) { prefs.getInt("auto_logout_minutes", 5) }

    LaunchedEffect(state.authenticated, lastInteractionTime, autoLogoutMins) {
        if (state.authenticated && autoLogoutMins > 0) {
            val timeoutMillis = autoLogoutMins * 60 * 1000L
            while (isActive) {
                delay(5000L)
                val elapsed = System.currentTimeMillis() - lastInteractionTime
                if (elapsed >= timeoutMillis) {
                    viewModel.logout()
                    Toast.makeText(context, "Auto-logged out due to $autoLogoutMins minutes of inactivity", Toast.LENGTH_SHORT).show()
                    break
                }
            }
        }
    }

    MaterialTheme(colorScheme = colorScheme) { 
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            awaitPointerEvent()
                            lastInteractionTime = System.currentTimeMillis()
                        }
                    }
                },
            color = MaterialTheme.colorScheme.background
        ) { 
            AspectScaleContainer {
                if (state.authenticated) {
                    MainShell(viewModel, mode = state.currentMode, onSwitchMode = { viewModel.clearMode() })
                } else {
                    Box(contentAlignment = Alignment.Center) {
                        Box(Modifier.fillMaxSize(if (isTablet) 0.85f else 1f)) {
                            LoginScreen(
                                viewModel = viewModel,
                                pinError = state.pinError,
                                storeName = state.storeName,
                                onTriggerBiometrics = {
                                    val isBioEnabled = prefs.getBoolean("enable_biometrics", true)
                                    if (!isBioEnabled) {
                                        Toast.makeText(context, "Face ID / Touch ID is disabled in Settings", Toast.LENGTH_SHORT).show()
                                    } else {
                                        triggerBiometricAuth(
                                            context = context,
                                            onSuccess = { viewModel.loginWithBiometrics() },
                                            onError = { viewModel.setMessage(it) }
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }
        } 
    }
}

private fun triggerBiometricAuth(
    context: Context,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    runCatching {
        val activity = context as? FragmentActivity
        if (activity == null) {
            onError("Biometric authentication requires FragmentActivity")
            return
        }

        val executor = ContextCompat.getMainExecutor(context)
        val biometricPrompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                        onError(errString.toString())
                    }
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    onError("Fingerprint / Face ID not recognized. Try again.")
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Sign in to AlKris POS")
            .setSubtitle("Touch sensor or use Face ID to sign in")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            .build()

        biometricPrompt.authenticate(promptInfo)
    }.onFailure { e ->
        Log.e("PosApp", "Biometric authentication failed to trigger", e)
        onError("Biometric error: ${e.message}")
    }
}

private fun scanBarcode(
    context: Context,
    continuous: Boolean = false,
    onFallback: (() -> Unit)? = null,
    onScan: (String) -> Unit
) {
    val options = GmsBarcodeScannerOptions.Builder()
        .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
        .enableAutoZoom()
        .build()

    val scanner = GmsBarcodeScanning.getClient(context, options)

    fun doScan() {
        runCatching {
            scanner.startScan()
                .addOnSuccessListener { barcode ->
                    val raw = barcode.rawValue
                    if (!raw.isNullOrBlank()) {
                        onScan(raw)
                        if (continuous) {
                            // Continuous scanning loop ONLY for POS tab
                            doScan()
                        }
                    }
                }
                .addOnFailureListener { e ->
                    val isUserCanceled = e.message?.contains("cancel", ignoreCase = true) == true ||
                            e.message?.contains("user", ignoreCase = true) == true ||
                            e.message?.contains("16", ignoreCase = true) == true
                    if (!isUserCanceled) {
                        onFallback?.invoke()
                    }
                }
        }.onFailure {
            onFallback?.invoke()
        }
    }

    doScan()
}

fun printReceipt(context: Context, sale: Sale, storeName: String, viewModel: PosViewModel) {
    ThermalPrinterManager.print(context, sale, storeName)
    viewModel.logActivity("PRINT", "Printed sale receipt for sale ID ${sale.id} (₱${sale.total})")
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainShell(
    viewModel: PosViewModel,
    mode: AppMode = AppMode.MART,
    onSwitchMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pos_prefs", Context.MODE_PRIVATE) }
    val state by viewModel.state.collectAsStateWithLifecycle()

    var userFontDeltaSp by remember { mutableFloatStateOf(prefs.getFloat("user_font_delta_sp", 0f)) }
    var fontSizeMenuExpanded by remember { mutableStateOf(false) }

    val baseDensity = LocalDensity.current
    val customDensity = remember(baseDensity, userFontDeltaSp) {
        Density(
            density = baseDensity.density,
            fontScale = (baseDensity.fontScale + (userFontDeltaSp / 14f)).coerceIn(0.7f, 1.8f)
        )
    }

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val pageCount = if (mode == AppMode.ECASH) 4 else 5
    val pagerState = rememberPagerState(initialPage = selectedTab, pageCount = { pageCount })
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(mode) {
        val maxIndex = if (mode == AppMode.ECASH) 3 else 4
        if (selectedTab > maxIndex) {
            selectedTab = maxIndex
            coroutineScope.launch {
                pagerState.scrollToPage(maxIndex)
            }
        }
    }

    var showSettingsScreen by remember { mutableStateOf(false) }
    var showAutoBackupScreen by remember { mutableStateOf(false) }
    var showUserManualScreen by remember { mutableStateOf(false) }
    var cameraScannerCallback by remember { mutableStateOf<((String) -> Unit)?>(null) }
    var isPosTabForScanner by remember { mutableStateOf(true) }
    var isPrinterConnected by remember { mutableStateOf(false) }

    val checkPrinterConnection: () -> Unit = {
        try {
            val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            val hasPaired = if (bluetoothAdapter != null && bluetoothAdapter.isEnabled) {
                val pairedDevices = try { bluetoothAdapter.bondedDevices } catch (_: Exception) { null }
                !pairedDevices.isNullOrEmpty()
            } else false
            val firstPaired = try { BluetoothPrintersConnections.selectFirstPaired() } catch (_: Exception) { null }
            isPrinterConnected = hasPaired || firstPaired != null
        } catch (_: Exception) {
            isPrinterConnected = false
        }
    }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            checkPrinterConnection()
        }
    }

    val isTablet = LocalContext.current.resources.configuration.smallestScreenWidthDp >= 600
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val showFullLabels = isTablet || isLandscape

    var currentTimeText by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val dtf = DateTimeFormatter.ofPattern("hh:mm:ss a")
        while (isActive) {
            currentTimeText = LocalTime.now().format(dtf)
            delay(1000L)
        }
    }

    LaunchedEffect(pagerState.currentPage) {
        if (selectedTab != pagerState.currentPage) {
            selectedTab = pagerState.currentPage
        }
    }

    fun onScanRequested(continuous: Boolean = false, onResult: (String) -> Unit) {
        scanBarcode(
            context = context,
            continuous = continuous,
            onFallback = { cameraScannerCallback = onResult },
            onScan = onResult
        )
    }

    if (showSettingsScreen) {
        SettingsScreen(
            viewModel = viewModel,
            onDismiss = { showSettingsScreen = false },
            onOpenAutoBackup = { showAutoBackupScreen = true },
            onOpenManual = { showUserManualScreen = true }
        )
    } else if (showAutoBackupScreen) {
        AutoBackupScreen(
            viewModel = viewModel,
            onDismiss = { showAutoBackupScreen = false }
        )
    } else if (showUserManualScreen) {
        UserManualScreen(
            onDismiss = { showUserManualScreen = false }
        )
    } else {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        // Middle: Overlapping Mart / E-Cash Mode Button
                        Surface(
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, Blue.copy(alpha = 0.5f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxHeight().padding(2.dp)
                            ) {
                                if (showFullLabels) {
                                    // TABLET / LANDSCAPE: SHOW BOTH ICONS AND TEXT IN OVERLAPPING SEGMENTED BUTTON
                                    Surface(
                                        onClick = { viewModel.setMode(AppMode.MART) },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (mode == AppMode.MART) Blue else Color.Transparent,
                                        modifier = Modifier.fillMaxHeight()
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier.fillMaxHeight().padding(horizontal = 10.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
                                            ) {
                                                Icon(
                                                    Icons.Default.ShoppingCart,
                                                    contentDescription = "Mart",
                                                    tint = if (mode == AppMode.MART) Color.White else Color.Gray,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Text(
                                                    "Mart",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    lineHeight = 12.sp,
                                                    color = if (mode == AppMode.MART) Color.White else Color.Gray
                                                )
                                            }
                                        }
                                    }

                                    Surface(
                                        onClick = { viewModel.setMode(AppMode.ECASH) },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (mode == AppMode.ECASH) Blue else Color.Transparent,
                                        modifier = Modifier.fillMaxHeight()
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier.fillMaxHeight().padding(horizontal = 10.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
                                            ) {
                                                Icon(
                                                    Icons.Default.Smartphone,
                                                    contentDescription = "E-Cash",
                                                    tint = if (mode == AppMode.ECASH) Color.White else Color.Gray,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Text(
                                                    "E-Cash",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    lineHeight = 12.sp,
                                                    color = if (mode == AppMode.ECASH) Color.White else Color.Gray
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    // PHONE PORTRAIT: COMPACT SLIDING OVERLAP
                                    if (mode == AppMode.MART) {
                                        Surface(
                                            onClick = { viewModel.setMode(AppMode.MART) },
                                            shape = RoundedCornerShape(14.dp),
                                            color = Blue,
                                            modifier = Modifier.fillMaxHeight()
                                        ) {
                                            Box(
                                                contentAlignment = Alignment.Center,
                                                modifier = Modifier.fillMaxHeight().padding(horizontal = 10.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
                                                ) {
                                                    Icon(
                                                        Icons.Default.ShoppingCart,
                                                        contentDescription = "Mart",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                    Text(
                                                        "Mart",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp,
                                                        lineHeight = 12.sp,
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        }

                                        Box(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .padding(horizontal = 8.dp)
                                                .clickable { viewModel.setMode(AppMode.ECASH) },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.Smartphone,
                                                contentDescription = "Switch to E-Cash",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .padding(horizontal = 8.dp)
                                                .clickable { viewModel.setMode(AppMode.MART) },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.ShoppingCart,
                                                contentDescription = "Switch to Mart",
                                                tint = Color.Gray,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Surface(
                                            onClick = { viewModel.setMode(AppMode.ECASH) },
                                            shape = RoundedCornerShape(14.dp),
                                            color = Blue,
                                            modifier = Modifier.fillMaxHeight()
                                        ) {
                                            Box(
                                                contentAlignment = Alignment.Center,
                                                modifier = Modifier.fillMaxHeight().padding(horizontal = 10.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
                                                ) {
                                                    Icon(
                                                        Icons.Default.Smartphone,
                                                        contentDescription = "E-Cash",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                    Text(
                                                        "E-Cash",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp,
                                                        lineHeight = 12.sp,
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        // Left: Logo + Store Name in 2 lines
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(start = 12.dp)
                        ) {
                            Image(
                                painter = painterResource(R.drawable.alkris_pos_logo),
                                contentDescription = "ALKRIS LOGO",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )

                            val rawName = state.storeName.ifBlank { "AlKris Sari-sari Store" }
                            val twoLineName = remember(rawName) {
                                if (rawName.contains("\n")) rawName
                                else {
                                    val words = rawName.split(" ")
                                    if (words.size > 1) {
                                        val mid = (words.size + 1) / 2
                                        words.take(mid).joinToString(" ") + "\n" + words.drop(mid).joinToString(" ")
                                    } else rawName
                                }
                            }

                            Text(
                                text = twoLineName,
                                fontSize = 10.sp,
                                lineHeight = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )

                            if (isLandscape && currentTimeText.isNotEmpty()) {
                                Spacer(Modifier.width(16.dp))
                                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                                Text(
                                    text = currentTimeText,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) SkyBlue else MaterialTheme.colorScheme.primary,
                                    lineHeight = 32.sp
                                )
                            }
                        }
                    },
                    actions = {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(0.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box {
                                IconButton(
                                    onClick = { fontSizeMenuExpanded = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Text(
                                        text = "A",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) Color.White else MaterialTheme.colorScheme.primary
                                    )
                                }

                                DropdownMenu(
                                    expanded = fontSizeMenuExpanded,
                                    onDismissRequest = { fontSizeMenuExpanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("— (Smaller)", fontWeight = FontWeight.Bold) },
                                        onClick = {
                                            userFontDeltaSp = (userFontDeltaSp - 1f).coerceAtLeast(-4f)
                                            prefs.edit().putFloat("user_font_delta_sp", userFontDeltaSp).apply()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("+ (Larger)", fontWeight = FontWeight.Bold) },
                                        onClick = {
                                            userFontDeltaSp = (userFontDeltaSp + 1f).coerceAtMost(8f)
                                            prefs.edit().putFloat("user_font_delta_sp", userFontDeltaSp).apply()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("100% (Default)", fontWeight = FontWeight.Bold) },
                                        onClick = {
                                            userFontDeltaSp = 0f
                                            prefs.edit().putFloat("user_font_delta_sp", 0f).apply()
                                            fontSizeMenuExpanded = false
                                        }
                                    )
                                }
                            }

                            IconButton(
                                onClick = { showSettingsScreen = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Settings,
                                    contentDescription = "Settings",
                                    tint = if (MaterialTheme.colorScheme.surface.luminance() < 0.5f) Color.White else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            IconButton(
                                onClick = { viewModel.logout() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = "Logout",
                                    tint = Pink,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    },
                    modifier = if (isLandscape) Modifier.padding(top = 4.dp) else Modifier,
                    windowInsets = TopAppBarDefaults.windowInsets
                )
            },
            bottomBar = {
                if (!isLandscape) {
                    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                    val solidNavBg = if (isDark) Color(0xFF282A36) else Color.White
                    val solidNavBorder = if (isDark) Color(0xFF383A46) else Color(0xFFE0E0E0)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .windowInsetsPadding(NavigationBarDefaults.windowInsets)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = solidNavBg,
                            border = BorderStroke(1.dp, solidNavBorder),
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(if (isTablet) 68.dp else 58.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                val tabItems = if (mode == AppMode.ECASH) {
                                    listOf(
                                        Icons.Default.PointOfSale to "Services",
                                        Icons.Default.Assessment to "Reports",
                                        Icons.Default.History to "History",
                                        Icons.Default.AccountBalanceWallet to "E-Cash\nDrawer"
                                    )
                                } else {
                                    listOf(
                                        Icons.Default.PointOfSale to "POS",
                                        Icons.Default.Inventory to "Inventory",
                                        Icons.Default.People to "Utang\nLedger",
                                        Icons.Default.Assessment to "Reports",
                                        Icons.Default.AccountBalanceWallet to "Cash\nDrawer"
                                    )
                                }

                                tabItems.forEachIndexed { index, pair ->
                                    val (icon, title) = pair
                                    val selected = selectedTab == index
                                    val tabContentColor = if (selected) Color.White else if (isDark) Color.White else Color.Black

                                    Surface(
                                        onClick = { selectedTab = index },
                                        shape = CircleShape,
                                        color = if (selected) Blue else Color.Transparent,
                                        border = if (selected) BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)) else null,
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(horizontal = 2.dp, vertical = 2.dp)
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = icon,
                                                    contentDescription = title,
                                                    tint = tabContentColor,
                                                    modifier = Modifier.size(if (isTablet) 24.dp else 18.dp)
                                                )
                                                Text(
                                                    text = title,
                                                    fontSize = if (isTablet) 12.sp else 10.sp,
                                                    lineHeight = if (isTablet) 13.sp else 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = tabContentColor,
                                                    textAlign = TextAlign.Center,
                                                    maxLines = 2
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        ) { padding ->
            val contentBlock = @Composable {
                CompositionLocalProvider(LocalDensity provides customDensity) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        when (selectedTab) {
                            0 -> if (mode == AppMode.ECASH) {
                                EcashServicesScreen(viewModel, Modifier)
                            } else {
                                PosScreen(viewModel, Modifier, onScanRequested = { callback -> isPosTabForScanner = true; onScanRequested(true, callback) })
                            }
                            1 -> if (mode == AppMode.ECASH) {
                                EcashReportsScreen(viewModel, Modifier)
                            } else {
                                InventoryScreen(viewModel, Modifier, onScanRequested = { callback -> isPosTabForScanner = false; onScanRequested(false, callback) })
                            }
                            2 -> if (mode == AppMode.ECASH) {
                                TransactionsScreen(viewModel, Modifier, mode = AppMode.ECASH)
                            } else {
                                UtangLedgerScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier,
                                    onSelectDebtor = { debtor ->
                                        viewModel.loadDebtors()
                                        viewModel.loadDebtPayments()
                                    }
                                )
                            }
                            3 -> if (mode == AppMode.ECASH) {
                                CashDrawerScreen(viewModel, Modifier, mode = AppMode.ECASH)
                            } else {
                                ReportsScreen(
                                    viewModel = viewModel,
                                    modifier = Modifier,
                                    onDebtorClick = {}
                                )
                            }
                            4 -> CashDrawerScreen(
                                viewModel = viewModel,
                                modifier = Modifier,
                                mode = AppMode.MART
                            )
                            else -> CashDrawerScreen(
                                viewModel = viewModel,
                                modifier = Modifier,
                                mode = mode
                            )
                        }
                    }
                }
            }

            if (isLandscape) {
                val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f
                val solidNavBg = if (isDark) Color(0xFF282A36) else Color.White
                val solidNavBorder = if (isDark) Color(0xFF383A46) else Color(0xFFE0E0E0)

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    // LEFT SIDE FLOATING SOLID NAVIGATION BAR IN LANDSCAPE MODE
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .padding(start = 8.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = solidNavBg,
                            border = BorderStroke(1.dp, solidNavBorder),
                            shadowElevation = 8.dp,
                            modifier = Modifier
                                .width(if (isTablet) 110.dp else 98.dp)
                                .fillMaxHeight()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(vertical = 10.dp, horizontal = 6.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val tabItems = if (mode == AppMode.ECASH) {
                                    listOf(
                                        Icons.Default.PointOfSale to "Services",
                                        Icons.Default.Assessment to "Reports",
                                        Icons.Default.History to "History",
                                        Icons.Default.AccountBalanceWallet to "E-Cash\nDrawer"
                                    )
                                } else {
                                    listOf(
                                        Icons.Default.PointOfSale to "POS",
                                        Icons.Default.Inventory to "Inventory",
                                        Icons.Default.People to "Utang\nLedger",
                                        Icons.Default.Assessment to "Reports",
                                        Icons.Default.AccountBalanceWallet to "Cash\nDrawer"
                                    )
                                }

                                tabItems.forEachIndexed { index, pair ->
                                    val (icon, title) = pair
                                    val selected = selectedTab == index
                                    val tabContentColor = if (selected) Color.White else if (isDark) Color.White else Color.Black

                                    Surface(
                                        onClick = { selectedTab = index },
                                        shape = RoundedCornerShape(20.dp),
                                        color = if (selected) Blue else Color.Transparent,
                                        border = if (selected) BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)) else null,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f)
                                    ) {
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(horizontal = 2.dp, vertical = 2.dp)
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = icon,
                                                    contentDescription = title,
                                                    tint = tabContentColor,
                                                    modifier = Modifier.size(if (isTablet) 28.dp else 24.dp)
                                                )
                                                Text(
                                                    text = title,
                                                    fontSize = if (isTablet) 13.sp else 10.sp,
                                                    lineHeight = if (isTablet) 14.sp else 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = tabContentColor,
                                                    textAlign = TextAlign.Center,
                                                    maxLines = 2
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // MAIN CONTENT PAGER (RIGHT SIDE)
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        contentBlock()
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = padding.calculateTopPadding())
                ) {
                    contentBlock()
                }
            }

            cameraScannerCallback?.let { callback ->
                CameraBarcodeScannerDialog(
                    isPosTab = isPosTabForScanner,
                    onScan = { barcode -> callback(barcode) },
                    onDismiss = { cameraScannerCallback = null }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.annotation.OptIn(ExperimentalGetImage::class)
@Composable
private fun CameraBarcodeScannerDialog(
    isPosTab: Boolean = true,
    onScan: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var lastScannedCode by remember { mutableStateOf<String?>(null) }
    var scanCount by remember { mutableIntStateOf(0) }
    var isContinuous by remember { mutableStateOf(isPosTab) }
    var triggerSingleScan by remember { mutableStateOf(false) }
    var isScanProcessing by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            Toast.makeText(context, "Camera permission required for scanner", Toast.LENGTH_SHORT).show()
            onDismiss()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    if (hasCameraPermission) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Barcode scanner", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        if (isPosTab) {
                            Text(
                                text = if (isContinuous) "Point at barcodes — auto-scanning is on." else "Position the barcode inside the frame and tap Scan.",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        } else {
                            Text(if (scanCount > 0) "$scanCount item scanned" else "Position barcode inside the window", fontSize = 11.sp, color = Green)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close Scanner")
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // CAMERA PREVIEW CONTAINER
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                val previewView = PreviewView(ctx).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                }
                                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                cameraProviderFuture.addListener({
                                    try {
                                        val cameraProvider = cameraProviderFuture.get()
                                        val preview = Preview.Builder().build().also {
                                            it.surfaceProvider = previewView.surfaceProvider
                                        }

                                        val options = BarcodeScannerOptions.Builder()
                                            .setBarcodeFormats(
                                                Barcode.FORMAT_EAN_13,
                                                Barcode.FORMAT_EAN_8,
                                                Barcode.FORMAT_UPC_A,
                                                Barcode.FORMAT_UPC_E,
                                                Barcode.FORMAT_CODE_128,
                                                Barcode.FORMAT_CODE_39,
                                                Barcode.FORMAT_QR_CODE
                                            )
                                            .build()
                                        val scanner = BarcodeScanning.getClient(options)

                                        val imageAnalysis = ImageAnalysis.Builder()
                                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                            .build()

                                        val executor = Executors.newSingleThreadExecutor()
                                        var isProcessing = false
                                        var lastScanTime = 0L
                                        var lastCode = ""

                                        imageAnalysis.setAnalyzer(executor) { imageProxy ->
                                            val mediaImage = imageProxy.image
                                            val now = System.currentTimeMillis()
                                            val shouldProcess = if (isContinuous) {
                                                mediaImage != null && !isProcessing
                                            } else {
                                                mediaImage != null && !isProcessing && triggerSingleScan
                                            }

                                            if (shouldProcess) {
                                                isProcessing = true
                                                if (!isContinuous) {
                                                    (ctx as? Activity)?.runOnUiThread { isScanProcessing = true }
                                                }

                                                val image = InputImage.fromMediaImage(
                                                    mediaImage!!,
                                                    imageProxy.imageInfo.rotationDegrees
                                                )
                                                scanner.process(image)
                                                    .addOnSuccessListener { barcodes ->
                                                        val raw = barcodes.firstOrNull()?.rawValue
                                                        if (!raw.isNullOrBlank()) {
                                                            if (isContinuous) {
                                                                if (raw != lastCode || (now - lastScanTime > 800L)) {
                                                                    lastScanTime = System.currentTimeMillis()
                                                                    lastCode = raw
                                                                    (ctx as? Activity)?.runOnUiThread {
                                                                        CashSoundManager.playBeepSound()
                                                                        lastScannedCode = raw
                                                                        scanCount++
                                                                        onScan(raw)
                                                                    }
                                                                }
                                                            } else {
                                                                (ctx as? Activity)?.runOnUiThread {
                                                                    CashSoundManager.playBeepSound()
                                                                    lastScannedCode = raw
                                                                    scanCount++
                                                                    triggerSingleScan = false
                                                                    isScanProcessing = false
                                                                    onScan(raw)
                                                                }
                                                            }
                                                        }
                                                    }
                                                    .addOnCompleteListener {
                                                        isProcessing = false
                                                        imageProxy.close()
                                                    }
                                            } else {
                                                imageProxy.close()
                                            }
                                        }

                                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                                        cameraProvider.unbindAll()
                                        val camera = cameraProvider.bindToLifecycle(
                                            lifecycleOwner,
                                            cameraSelector,
                                            preview,
                                            imageAnalysis
                                        )

                                        val factory = previewView.meteringPointFactory
                                        val point = factory.createPoint(previewView.width / 2f, previewView.height / 2f)
                                        val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF)
                                            .setAutoCancelDuration(2, TimeUnit.SECONDS)
                                            .build()
                                        camera.cameraControl.startFocusAndMetering(action)

                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }, ContextCompat.getMainExecutor(ctx))
                                previewView
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        // VIEWFINDER FRAME (WHITE ROUNDED RECTANGLE)
                        Box(
                            modifier = Modifier
                                .fillMaxSize(0.68f)
                                .border(2.dp, Color.White, RoundedCornerShape(16.dp))
                        )

                        lastScannedCode?.let { code ->
                            Surface(
                                color = Green,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 10.dp)
                            ) {
                                Text(
                                    text = "✓ Scanned: $code",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // POS TAB ONLY: MODE TOGGLE BUTTONS & NOTIFICATION CARD
                    if (isPosTab) {
                        // SEGMENTED MODE TOGGLE PILL
                        Surface(
                            color = Color(0xFF1E1F24),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // TAP TO SCAN BUTTON
                                Surface(
                                    onClick = { isContinuous = false },
                                    shape = RoundedCornerShape(20.dp),
                                    color = if (!isContinuous) Color.White else Color.Transparent
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.TouchApp,
                                            contentDescription = null,
                                            tint = if (!isContinuous) Color(0xFF004D40) else Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            "Tap to scan",
                                            fontWeight = if (!isContinuous) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp,
                                            color = if (!isContinuous) Color(0xFF004D40) else Color.White
                                        )
                                    }
                                }

                                // CONTINUOUS BUTTON
                                Surface(
                                    onClick = { isContinuous = true },
                                    shape = RoundedCornerShape(20.dp),
                                    color = if (isContinuous) Color.White else Color.Transparent
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.SwapHoriz,
                                            contentDescription = null,
                                            tint = if (isContinuous) Color(0xFF004D40) else Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            "Continuous",
                                            fontWeight = if (isContinuous) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp,
                                            color = if (isContinuous) Color(0xFF004D40) else Color.White
                                        )
                                    }
                                }
                            }
                        }

                        // NOTIFICATION CARD (MATCHING USER SCREENSHOTS)
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1F24)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (isContinuous) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Green)
                                        )
                                        Text(
                                            "Auto-scanning",
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 15.sp
                                        )
                                    }
                                    Text(
                                        "Point the camera at each barcode — items are added automatically.",
                                        color = Color.LightGray,
                                        fontSize = 11.sp,
                                        lineHeight = 14.sp
                                    )
                                } else {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color.White)
                                        )
                                        Text(
                                            "Ready to scan",
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 15.sp
                                        )
                                    }
                                    Text(
                                        "Tap Scan when the barcode is visible in the window.",
                                        color = Color.LightGray,
                                        fontSize = 11.sp,
                                        lineHeight = 14.sp
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Button(
                                        onClick = { triggerSingleScan = true },
                                        enabled = !isScanProcessing,
                                        modifier = Modifier.fillMaxWidth().height(42.dp),
                                        shape = ControlShape,
                                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                                    ) {
                                        Text(
                                            if (isScanProcessing) "Scanning..." else "Scan",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = onDismiss, shape = ControlShape) {
                        Text("Done ($scanCount)")
                    }
                }
            }
        )
    }
}
